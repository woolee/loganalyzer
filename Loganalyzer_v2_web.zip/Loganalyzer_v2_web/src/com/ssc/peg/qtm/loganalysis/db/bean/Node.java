package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class Node implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3423897899055537700L;
	private int nodeId;
//	private int parentNodeId;
	private String uuid;
	private String parentNodeUUID;
	public int getNodeId() {
		return nodeId;
	}
	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}
//	public int getParentNodeId() {
//		return parentNodeId;
//	}
//	public void setParentNodeId(int parentNodeId) {
//		this.parentNodeId = parentNodeId;
//	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getParentNodeUUID() {
		return parentNodeUUID;
	}
	public void setParentNodeUUID(String parentNodeUUID) {
		this.parentNodeUUID = parentNodeUUID;
	}
	
}

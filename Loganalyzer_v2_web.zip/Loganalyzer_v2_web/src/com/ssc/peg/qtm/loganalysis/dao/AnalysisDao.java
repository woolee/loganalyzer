package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface AnalysisDao<T> {
	public boolean addAnalysis(T entity) throws DataAccessException;
	public T getAnalysisById(int id)throws DataAccessException;
	public T getAnalysisByUUID(String uuid) throws DataAccessException;
	public List<T> getAnalysis();
	public boolean deleteAnalysis(int analysisId);
}

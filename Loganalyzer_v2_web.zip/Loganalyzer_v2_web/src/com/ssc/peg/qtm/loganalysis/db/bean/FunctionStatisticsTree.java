package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

public class FunctionStatisticsTree implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7083850173865079064L;
	private int statisticsId;
	private float maxTime;
	private float minTime;
	private float avgTime;
	private int count;
	private int functionId;
	private float ratio;
	private int analysisId;
//	private int treeId;
	private String treeUUID;
	public int getStatisticsId() {
		return statisticsId;
	}
	public void setStatisticsId(int statisticsId) {
		this.statisticsId = statisticsId;
	}
	public float getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(float maxTime) {
		this.maxTime = maxTime;
	}
	public float getMinTime() {
		return minTime;
	}
	public void setMinTime(float minTime) {
		this.minTime = minTime;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
//	public int getTreeId() {
//		return treeId;
//	}
//	public void setTreeId(int treeId) {
//		this.treeId = treeId;
//	}
	public String getTreeUUID() {
		return treeUUID;
	}
	public void setTreeUUID(String treeUUID) {
		this.treeUUID = treeUUID;
	}
	
}

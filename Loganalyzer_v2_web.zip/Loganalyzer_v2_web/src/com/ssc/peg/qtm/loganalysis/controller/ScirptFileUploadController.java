package com.ssc.peg.qtm.loganalysis.controller;


import java.io.File;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ssc.peg.qtm.loganalysis.util.UnzipUtility;


@Controller
@RequestMapping("/file")
public class ScirptFileUploadController {
	

	 @RequestMapping(value = "/fileUpload", method = RequestMethod.POST)
	 public String createDocument(String name,
			@RequestParam("uploadFile") MultipartFile file,HttpSession session,Model model) 
					throws Exception {
//		 String realPath = "C:/apms/service/";
		 String realPath = session.getServletContext().getRealPath("/") + "logzip/";
			File pathFile=new File(realPath);
			if(!pathFile.exists()){
				pathFile.mkdirs();
			}
			System.out.println(file.getOriginalFilename());
			file.transferTo(new File(realPath+file.getOriginalFilename()));
			
//			Zip zipfile = new Zip();
//			zipfile.zip(new File("C:/apms/service/TextFiles.zip"),new File("C:/apms/"+file.getOriginalFilename()));
			UnzipUtility unzipper = new UnzipUtility();
			
//			String fileName = unzipper.unzip(realPath+file.getOriginalFilename(), session.getServletContext().getRealPath("/") + "log");
//			session.setAttribute("logPath", session.getServletContext().getRealPath("/") + "log/"+fileName);
			session.setAttribute("logPath",realPath+file.getOriginalFilename());
			System.out.println(session.getAttribute("logPath"));
			//return "../view/head.jsp";
			return "../log/analyzeFromLog.do";
	 }
	 
}

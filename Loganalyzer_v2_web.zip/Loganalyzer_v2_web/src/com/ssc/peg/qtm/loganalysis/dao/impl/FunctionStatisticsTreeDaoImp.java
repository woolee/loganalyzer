package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsTreeDao;
import com.ssc.peg.qtm.loganalysis.mapper.FunctionStatisticsTreeMapper;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;
@Repository
public class FunctionStatisticsTreeDaoImp<T extends FunctionStatisticsTree> implements FunctionStatisticsTreeDao<T> {

	@Inject
	private FunctionStatisticsTreeMapper<T> mapper;
	
	@Override
	public boolean addFunctionStatistics(T entity) {
		boolean flag = false;
		try
		{
			mapper.addFunctionStatistics(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add FunctionStatisticsTree to database",e);
		}
		return flag;
	}

	@Override
	public T getFunctionStaById(int id) {
		// TODO Auto-generated method stub
		return  mapper.getFunctionStaById(id);
	}

	@Override
	public T getFunctionStaByFunctionId(int functionId) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaByFunctionId(functionId);
	}

	@Override
	public T getFunctionStaByTreeUUID(String treeUUID) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaByTreeUUID( treeUUID);
	}

	@Override
	public List<T> getFunctionStaByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaByAnalysisId(analysisId);
	}

	@Override
	public boolean addFunctionStatisList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addFunctionStatisList(list);
//			SqlCounter.sqlExecuCount += 1;
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add FunctionStatisticsTree list to database",e);
		}
		return flag;
	}

	@Override
	public boolean addFunctionStatisListStr(String str) {
		// TODO Auto-generated method stub
		 mapper.addFunctionStatisListStr(str);
		 return true;
	}

	@Override
	public T getFunctionStaByFunctionAndTree(int functionId, String treeUUID) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaByFunctionAndTree(functionId, treeUUID);
	}

}

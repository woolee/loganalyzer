package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.FunctionDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.FunctionMapper;

@Repository
public class FunctionDaoImp<T extends Function> implements FunctionDao<T> {

	@Inject
	private FunctionMapper<T> mapper;
	@Override
	public boolean addFunction(T entity) {
		boolean flag = false;
		try
		{
			mapper.addFunction(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Function to database",e);
		}
		return flag;
		
	}

	@Override
	public T getFunctionById(int id) {
		// TODO Auto-generated method stub
		return  mapper.getFunctionById(id);
	}

	@Override
	public T getFunctionByNameAndDescription(T entity) {
		// TODO Auto-generated method stub
		return mapper.getFunctionByNameAndDescription(entity);
	}

	@Override
	public boolean addFunctionList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addFunctionList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Function list to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getFunctionListByNameAndDescription(List<T> list) {
		// TODO Auto-generated method stub
		return mapper.getFunctionListByNameAndDescription(list);
	}

	@Override
	public List<T> getFunctionList() {
		// TODO Auto-generated method stub
		return mapper.getFunctionList();
	}

}

package com.ssc.peg.qtm.loganalysis.concurrent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.mybatis.spring.SqlSessionTemplate;

import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsTreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;



public class SqlProcessorManager implements Runnable{
	
	BlockingQueue inQueue = null;
	private int processorNumber = 0;
	private AtomicBoolean processorFinishFlag =  new AtomicBoolean();
	private BlockingQueue<Runnable> taskQueue = new ArrayBlockingQueue<Runnable>(204800);
	private FunctionStatisticsTreeDao<FunctionStatisticsTree> fucStatisTreeDao;
	public SqlProcessorManager(BlockingQueue inQueue,int processorNumber, AtomicBoolean processorFinishFlag,FunctionStatisticsTreeDao<FunctionStatisticsTree> fucStatisTreeDao) {
        this.inQueue = inQueue;
        this.processorNumber = processorNumber;
        this.processorFinishFlag = processorFinishFlag;
        this.fucStatisTreeDao = fucStatisTreeDao;
    }
	@Override
	public void run() {
		System.out.println("-----function statistics submit thread start-------");
//		Logger logger = Logger.getLogger(ProcessorManager.class);
//		logger.setLevel(Level.INFO);
		List<FunctionStatisticsTree> list = new ArrayList<FunctionStatisticsTree>();
		ThreadPoolExecutor executor = new ThreadPoolExecutor(
				processorNumber,
				processorNumber,
				5, 
				TimeUnit.SECONDS,
				taskQueue){
			@Override 
			protected void terminated() { 
				processorFinishFlag.set(true);
		     } 
			
		};
		while(true){
			FunctionStatisticsTree inQueueObj = null;
			
			try {
				inQueueObj = (FunctionStatisticsTree)inQueue.poll(5, TimeUnit.SECONDS);
				if(inQueueObj == null){
					if(list.size() > 0)
						executor.execute(new SqlProcessor(list,fucStatisTreeDao));
					System.out.println("process thread shut down ");
					break;
				}
				else
				{
					list.add(inQueueObj);
					if(list.size() >= 3000)
					{
						executor.execute(new SqlProcessor(list,fucStatisTreeDao));
						list = null;
						list = new ArrayList<FunctionStatisticsTree>();
					}
				}
			} catch (InterruptedException e) {
//				logger.error(e.getStackTrace().toString());
			}
		}
		executor.shutdown();
		
		
	}//end of run function
	
	


}

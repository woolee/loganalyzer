package com.ssc.peg.qtm.loganalysis.analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.log4j.Logger;

import com.ssc.peg.qtm.loganalysis.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceMergeTree;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeMapping;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TPSResponseTime;
import com.ssc.peg.qtm.loganalysis.concurrent.ConcurrentMapManager;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;
import com.ssc.peg.qtm.loganalysis.util.NodeUtil;
import com.ssc.peg.qtm.loganalysis.util.SortUtil;

/**
 * This class implements the Runnable interface, which is used to analyze and statistic request tree.
 * 
 * The analysis result are stored in Map object in memory.
 * 
 * @author a549324
 *
 */
public class LogAnalyzer implements Runnable{
	
	private AtomicBoolean processorFinishFlag ;
	private AtomicBoolean analyzerFinishFlag ;
	Logger logger = Logger.getLogger(getClass());
	//service statistic
	private Map<String,IDFData> idfMap;
//	private Map<String,RequestTree> idfMergeTreeMap ; 
	private Map<String,ServiceMergeTree> idfMergeTreeMap;
	private Map<String,Map<ServiceNodeValue,ServiceNodeStatistics>> idfMergeNodeStatisticsMap;
	private Map<Long,Map<String,TPSResponseTime>> statisMap;
	private Map<String, FunctionStatistics> functionScoreMap;
//	private Map<String,Map<String,>>
	private String uuid;
	public LogAnalyzer(AtomicBoolean processorFinishFlag,AtomicBoolean analyzerFinishFlag,Map<String,IDFData> idfMap,Map<String,ServiceMergeTree> idfMergeTreeMap,Map<String,Map<ServiceNodeValue,ServiceNodeStatistics>> idfMergeNodeStatisticsMap,Map<Long,Map<String,TPSResponseTime>> statisMap,Map<String, FunctionStatistics> functionScoreMap,String uuid)
	{
		this.analyzerFinishFlag = analyzerFinishFlag;
		this.processorFinishFlag = processorFinishFlag;
		this.idfMap = idfMap;
		this.idfMergeTreeMap = idfMergeTreeMap;
		this.idfMergeNodeStatisticsMap = idfMergeNodeStatisticsMap;
		this.statisMap = statisMap;
		this.functionScoreMap = functionScoreMap;
		this.uuid = uuid;
	}
	
	public LogAnalyzer(){
		logger.info("Analysis-Thread start up!");
	}
	@Override
	public void run() {

		while(true)
		{
			if(processorFinishFlag.get()){
				logger.info("Analysis thread start analying...");
				long time = System.currentTimeMillis();
				idfInfoGenerate();
				mergeSameStructure();
				mergeIDF();
				
				ConcurrentMapManager manager = DataMapSelector.selectConcurrentMap(uuid);
				tpsRespTimeStatistic(manager.getIdfTreeMap(),500);
				manager.setFunctionStatisticsInInvertMap(idfMergeTreeMap, idfMergeNodeStatisticsMap,uuid);
				manager.calFunctionScore(functionScoreMap);
				
				analyzerFinishFlag.set(true);
				
				DataMapSelector.selectConcurrentMap(uuid).setIdfTreeMap(null);
				
				logger.info("analysis end...cost:" + (System.currentTimeMillis() - time) + "ms");
				break;
			}
		}
	}

	private List<ServiceRequestTree> sortByExecutionTime(List<ServiceRequestTree> treeList)
	{
		Collections.sort(treeList, new Comparator<ServiceRequestTree>() {

			@Override
			public int compare(ServiceRequestTree tree1, ServiceRequestTree tree2) {
				long treeExecTime1 = tree1.getNodeMapping().getNodeMappingMap().get(tree1.getRootNode()).getExecutionTime();
				long treeExecTime2 = tree2.getNodeMapping().getNodeMappingMap().get(tree2.getRootNode()).getExecutionTime();
				if(treeExecTime1 < treeExecTime2)
					return -1;
				else if(treeExecTime1 == treeExecTime2)
					return 0;
				else 
					return 1;
			}
		});
		return treeList;
	}
	
	/**
	 * The method is to calculate the service statistics result which contains max time, min time, average time, call count, ninety percent time, average TPS.
	 */
	private void idfInfoGenerate()
	{
		ConcurrentHashMap<String, List<ServiceRequestTree>>  map = DataMapSelector.selectConcurrentMap(uuid).getIdfTreeMap();
		Set<String> idfSet = map.keySet();
		for (String idfNumber : idfSet) {
			List<ServiceRequestTree> treeList = map.get(idfNumber.intern());
			long maxTime = Long.MIN_VALUE;
			long minTime = Long.MAX_VALUE;
			double sumTime = 0;
			
			
			for (ServiceRequestTree requestTree : treeList) {
//				try{
					ServiceNode rootNode = requestTree.getRootNode();
					ServiceNodeMapping mapping = requestTree.getNodeMapping();
					ServiceNodeValue rootNodeValue = mapping.getNodeMappingMap().get(rootNode);
					long treeExecTime = rootNodeValue.getExecutionTime();
					if(treeExecTime > maxTime)
						maxTime = treeExecTime; 
					if(treeExecTime < minTime)
						minTime = treeExecTime;
					sumTime = sumTime + treeExecTime;
//				}catch(NullPointerException e)
//				{
//					System.out.println(treeList.size());
//				}
			}
			
			double avgTime = sumTime/treeList.size();
			IDFData idfData = new IDFData();
			idfData.setAvgTime((float)avgTime);
			idfData.setMaxTime(maxTime);
			idfData.setMinTime(minTime);
			idfData.setCount(treeList.size());
			
			sortByExecutionTime(treeList);
			int index = (int) Math.round(0.9 * treeList.size());
			ServiceRequestTree nintyTree = treeList.get(index - 1);
			long nintyPercentTime = nintyTree.getNodeMapping().getNodeMappingMap().get(nintyTree.getRootNode()).getExecutionTime();
			idfData.setNintyPercentTime(nintyPercentTime);
			
			long startTime = SortUtil.getStartTree(treeList).getStartTime();
			long endTime = SortUtil.getEndTree(treeList).getEndTime();
			float avgTps = ((float)treeList.size()) / (endTime - startTime);
//			System.out.println("----------------------------avgTps=" + avgTps);
			idfData.setAvgTps(avgTps);
			//forword to the jsp
			idfMap.put(idfNumber, idfData);
		}
	}
	
	/**
	 * Merge trees when they have the same structure with the same service.
	 * The same structure is distinguished by functionHashcode attribute in ServiceRequestTree class.
	 */
	public void mergeSameStructure()
	{
		ConcurrentHashMap<String, List<ServiceRequestTree>>  idfTreeMap = DataMapSelector.selectConcurrentMap(uuid).getIdfTreeMap();
		Set<String> idfSet = idfTreeMap.keySet();
		for (String idfNumber : idfSet) {
			List<ServiceRequestTree> treeList = idfTreeMap.get(idfNumber);
			ServiceMergeTree mergeTree = idfMergeTreeMap.get(idfNumber);
			if(mergeTree == null)
			{
				mergeTree = new ServiceMergeTree();
				idfMergeTreeMap.put(idfNumber.intern(), mergeTree);
			}
			for (ServiceRequestTree tree : treeList) {
				int hashcode = tree.getFunctionHashcode();
				
				//if the structure merge tree list in mergeTree is null , generate new tree add to the merge tree list
				if(mergeTree.getStructureMergeTree() == null)
				{
					List<ServiceRequestTree> structureMergeTrees = new ArrayList<ServiceRequestTree>();
					ServiceRequestTree newTree = generateMergeTree(tree,idfNumber);
					structureMergeTrees.add(newTree);
					newTree.setMergeTreeCount(1);
					mergeTree.setStructureMergeTree(structureMergeTrees);
				}
				else
				{
					List<ServiceRequestTree> structureMergeTrees = mergeTree.getStructureMergeTree();
					boolean exsitHashCode = false;
					ServiceRequestTree exsitTree = null;
					for (ServiceRequestTree structureMergeTree : structureMergeTrees) {
						if(structureMergeTree.getFunctionHashcode() == hashcode)
						{
							exsitHashCode = true;
							exsitTree = structureMergeTree;
							break;
						}
					}
					
					//the hashcode with the function has exsit in list
					if(exsitHashCode)
					{
						
						calExistHashCodeMergeTree(exsitTree, tree,idfNumber);
						exsitTree.setMergeTreeCount(exsitTree.getMergeTreeCount() + 1 );
					}
					else
					{
						ServiceRequestTree newTree = generateMergeTree(tree,idfNumber);
						newTree.setMergeTreeCount(1);
						structureMergeTrees.add(newTree);
					}
				}
			}
		}
//		for (String idfNumber : idfMergeTreeMap.keySet()) {
//			
//			MergeTree  mergeTree = idfMergeTreeMap.get(idfNumber);
//			List<RequestTree> treeList = mergeTree.getStructureMergeTree();
//			
//			for (RequestTree tree : treeList) {
//				print(tree.getRootNode(),tree.getNodeMapping(),idfMergeNodeStatisticsMap.get(idfNumber));
//			}
//		}
	}
	
	/*private void print(ServiceNode node,ServiceNodeMapping mapping,Map<ServiceNodeValue, ServiceNodeStatistics> nodeStatisticMap)
	{
		ServiceNodeValue nodeValue = mapping.getNodeMappingMap().get(node);
		ServiceNodeStatistics nodeStatistic = nodeStatisticMap.get(nodeValue);
		System.out.println(nodeValue.getFunctionName() + " - " + nodeValue.getFuncationDescription() + ":" + nodeStatistic.getAvgTime() + " abl " + nodeStatistic.getPercentageAbl() + " rel " + nodeStatistic.getPercentageRel());
		if(node.getChildrenNode() != null)
		{
			for (ServiceNode child : node.getChildrenNode()) {
				print(child,mapping,nodeStatisticMap);
			}
		}
	}*/
	private ServiceRequestTree generateMergeTree(ServiceRequestTree tree,String idfNumber)
	{
		ServiceRequestTree mergeTree = new ServiceRequestTree();
		mergeTree.setFunctionHashcode(tree.getFunctionHashcode());
		mergeTree.setIdfNumber(tree.getIdfNumber().intern());
		
		ServiceNodeMapping mergeNodeMapping = new ServiceNodeMapping();
		Map<ServiceNode,ServiceNodeValue> mergeNodeMappingMap = new HashMap<ServiceNode, ServiceNodeValue>();
		mergeNodeMapping.setNodeMappingMap(mergeNodeMappingMap);
		mergeTree.setNodeMapping(mergeNodeMapping);
		
		Map<ServiceNodeValue,ServiceNodeStatistics> mergeStatisticMap;
		if(idfMergeNodeStatisticsMap.get(idfNumber) == null)
		{
			mergeStatisticMap = new HashMap<ServiceNodeValue, ServiceNodeStatistics>();
			idfMergeNodeStatisticsMap.put(idfNumber, mergeStatisticMap);
		}
		else
		{
			mergeStatisticMap = idfMergeNodeStatisticsMap.get(idfNumber);
		}
		ServiceNode rootNode = tree.getRootNode();
		Map<ServiceNode,ServiceNodeValue> nodeMappingMap = tree.getNodeMapping().getNodeMappingMap();
		
		addNode(rootNode,null, mergeTree,nodeMappingMap,mergeNodeMappingMap,mergeStatisticMap);
//		printChildSize(tree.getRootNode(), mergeTree.getRootNode());
		
		return mergeTree;
	}
	
//	private void printChildSize(Node node,Node nodeMerge)
//	{
//		if(node.getChildrenNode() != null)
//		{
////			System.out.println(node.getChildrenNode().size()  + "------merge--" + nodeMerge.getChildrenNode().size()  + "  " +(node.getChildrenNode().size() == nodeMerge.getChildrenNode().size()));
//			for (int i = 0; i < node.getChildrenNode().size(); i++) {
//				
//				printChildSize(node.getChildrenNode().get(i), nodeMerge.getChildrenNode().get(i));
//			}
//		}
//		
//	}
	private void addNode(ServiceNode node,ServiceNode parentMergeNode,ServiceRequestTree mergeTree,Map<ServiceNode,ServiceNodeValue> nodeMappingMap,Map<ServiceNode,ServiceNodeValue> mergeNodeMappingMap,Map<ServiceNodeValue,ServiceNodeStatistics> mergeStatisticMap)
	{
		ServiceNode mergeNode = new ServiceNode();
		ServiceNodeValue mergeNodeValue = new ServiceNodeValue();
		ServiceNodeStatistics mergeNodeStatistic = new ServiceNodeStatistics();
		ServiceNodeValue nodeValue = nodeMappingMap.get(node);
		mergeNodeValue.setFunctionName(nodeValue.getFunctionName().intern());
		mergeNodeValue.setFuncationDescription(nodeValue.getFuncationDescription().intern());
		mergeNodeValue.setLevel(nodeValue.getLevel().intern());
		mergeNodeStatistic.setMaxTime(nodeValue.getExecutionTime());
		mergeNodeStatistic.setMinTime(nodeValue.getExecutionTime());
		mergeNodeStatistic.setCount(1);
		mergeNodeStatistic.setTotalSelfTime(nodeValue.getSelfExecutionTime());
		mergeNodeStatistic.setTotalTime(nodeValue.getExecutionTime());
		mergeNodeStatistic.setAvgTime(nodeValue.getExecutionTime());
		mergeNodeStatistic.setSelfAvgTime(nodeValue.getSelfExecutionTime());
		
		mergeNodeMappingMap.put(mergeNode, mergeNodeValue);
		mergeStatisticMap.put(mergeNodeValue, mergeNodeStatistic);
		if(parentMergeNode == null)
		{
			mergeTree.setRootNode(mergeNode);
			mergeNodeStatistic.setPercentageAbl(1);
			mergeNodeStatistic.setPercentageRel(1);
			mergeNodeStatistic.setSelfPercentageAbl(nodeValue.getSelfExecutionTime()/nodeValue.getExecutionTime());
		}
		else
		{
			mergeNode.setParentNode(parentMergeNode);
			ServiceNodeValue parentNodeValue = mergeNodeMappingMap.get(parentMergeNode);
			ServiceNodeStatistics parentNodeStatistic = mergeStatisticMap.get(parentNodeValue);
			
			if(parentMergeNode.getChildrenNode() != null)
			{
				parentMergeNode.getChildrenNode().add(mergeNode);
			}
			else
			{
				List<ServiceNode> childrens = new ArrayList<ServiceNode>();
				childrens.add(mergeNode);
				parentMergeNode.setChildrenNode(childrens);
			}
			
			ServiceNode rootMergeNode = NodeUtil.getRootNode(mergeNode);
			ServiceNodeValue rootMergeNodeValue = mergeNodeMappingMap.get(rootMergeNode);
			ServiceNodeStatistics rootNodeStatistic = mergeStatisticMap.get(rootMergeNodeValue);
			
			mergeNodeStatistic.setPercentageRel(mergeNodeStatistic.getTotalTime() /parentNodeStatistic.getTotalTime());
			mergeNodeStatistic.setPercentageAbl(mergeNodeStatistic.getTotalTime()/rootNodeStatistic.getTotalTime());
			mergeNodeStatistic.setSelfPercentageAbl(mergeNodeStatistic.getTotalSelfTime()/rootNodeStatistic.getTotalTime());
		}
		
		if(node.getChildrenNode() != null)
		{
			for (ServiceNode childNode : node.getChildrenNode()) {
				addNode(childNode,mergeNode,mergeTree, nodeMappingMap, mergeNodeMappingMap,mergeStatisticMap);
			}
		}
		
	}
	
	/**
	 * calculate the node statistics in the same structure tree
	 * @param exsitTree
	 * @param currentTree
	 * @param idfNumber
	 */
	private void calExistHashCodeMergeTree(ServiceRequestTree exsitTree,ServiceRequestTree currentTree,String idfNumber)
	{
		ServiceNode rootMergeNode = exsitTree.getRootNode();
		ServiceNode rootNode = currentTree.getRootNode();
		ServiceNodeMapping mergeNodeMapping = exsitTree.getNodeMapping();
		ServiceNodeMapping nodeMapping = currentTree.getNodeMapping();
		Map<ServiceNodeValue, ServiceNodeStatistics> mergeNodeStatisticsMap = idfMergeNodeStatisticsMap.get(idfNumber);
		calMergeNodeStatistics(rootMergeNode, rootNode, nodeMapping, mergeNodeMapping, mergeNodeStatisticsMap);
	}
	
//	private void printTree(Node node,NodeMapping mapping)
//	{
//		NodeValue nodeValue = mapping.getNodeMappingMap().get(node);
//		System.out.println(nodeValue.getLevel() + nodeValue.getFunctionName() + " - " + nodeValue.getFuncationDescription() );
//		if(node.getChildrenNode() != null)
//		{
//			for (Node child : node.getChildrenNode()) {
//				printTree(child,mapping);
//			}
//		}
//	}
	
	private void calMergeNodeStatistics(ServiceNode mergeNode,ServiceNode node,ServiceNodeMapping nodeMapping,ServiceNodeMapping mergeNodeMapping,Map<ServiceNodeValue, ServiceNodeStatistics> nodeStatisticsMap)
	{
		ServiceNodeValue nodeValue = nodeMapping.getNodeMappingMap().get(node);
		
		ServiceNodeValue mergeNodeValue = mergeNodeMapping.getNodeMappingMap().get(mergeNode);
		ServiceNodeStatistics mergeNodeStatistics = nodeStatisticsMap.get(mergeNodeValue);

		ServiceNode rootMergeNode = NodeUtil.getRootNode(mergeNode);
		ServiceNodeValue rootMergeNodeValue = mergeNodeMapping.getNodeMappingMap().get(rootMergeNode);
		ServiceNodeStatistics rootNodeStatistic = nodeStatisticsMap.get(rootMergeNodeValue);
		
		ServiceNode parentMergeNode = NodeUtil.getParentNode(mergeNode);
		ServiceNodeValue parentMergeNodeValue = mergeNodeMapping.getNodeMappingMap().get(parentMergeNode);
		ServiceNodeStatistics parentNodeStatistic = nodeStatisticsMap.get(parentMergeNodeValue);
		
		double maxTime = mergeNodeStatistics.getMaxTime();
		double minTime = mergeNodeStatistics.getMinTime();
//		double avgTime = mergeNodeStatistics.getAvgTime();
//		double selfAvgTime = mergeNodeStatistics.getSelfAvgTime();
		int count = mergeNodeStatistics.getCount();
		if(nodeValue.getExecutionTime() > maxTime)
			mergeNodeStatistics.setMaxTime(nodeValue.getExecutionTime());
		if(nodeValue.getExecutionTime() < minTime)
			mergeNodeStatistics.setMinTime(nodeValue.getExecutionTime());
		
		mergeNodeStatistics.setTotalSelfTime(mergeNodeStatistics.getTotalSelfTime() + nodeValue.getSelfExecutionTime());
		mergeNodeStatistics.setTotalTime(mergeNodeStatistics.getTotalTime() + nodeValue.getExecutionTime());
		mergeNodeStatistics.setCount(count + 1);
		mergeNodeStatistics.setAvgTime(mergeNodeStatistics.getTotalTime()/mergeNodeStatistics.getCount());
		mergeNodeStatistics.setSelfAvgTime(mergeNodeStatistics.getTotalSelfTime() / mergeNodeStatistics.getCount());
		mergeNodeStatistics.setPercentageAbl(mergeNodeStatistics.getTotalTime() /rootNodeStatistic.getTotalTime());
		mergeNodeStatistics.setPercentageRel(mergeNodeStatistics.getTotalTime()/parentNodeStatistic.getTotalTime());
		mergeNodeStatistics.setSelfPercentageAbl(mergeNodeStatistics.getTotalSelfTime()/ rootNodeStatistic.getTotalTime());
		if(node.getChildrenNode() != null)
		{
			for (int i = 0; i < node.getChildrenNode().size(); i++) {
				calMergeNodeStatistics( mergeNode.getChildrenNode().get(i),node.getChildrenNode().get(i), nodeMapping, mergeNodeMapping, nodeStatisticsMap);
			}
				
		}
	}
	
	/**
	 * The method is to merge the all request tree structure in the same service.
	 * The tree structures in the same service maybe different, we merge the node which they are the same deep in the tree and their parent node's method is same.
	 */
	public void mergeIDF()
	{
		Set<String> idfSet = idfMergeTreeMap.keySet();
		for (String idfNumber : idfSet) {
			List<ServiceRequestTree> treeList = idfMergeTreeMap.get(idfNumber).getStructureMergeTree();
			ServiceRequestTree tree = mergeTree(treeList, idfNumber);
			idfMergeTreeMap.get(idfNumber).setAllMergeTree(tree);
			
		}
		
	}
	
	
	/**
	 * foreach tree list and get the tree nodes
	 * @param treeList
	 * @param idfNumber
	 * @return
	 */
	private ServiceRequestTree mergeTree(List<ServiceRequestTree> treeList,String idfNumber)
	{
		ServiceRequestTree mergeTree = new ServiceRequestTree();
		mergeTree.setIdfNumber(idfNumber);
		
		ServiceNodeMapping mergeTreeMapping = new ServiceNodeMapping();
		Map<ServiceNode, ServiceNodeValue> nodeMappingMap = new HashMap<ServiceNode, ServiceNodeValue>();
		mergeTreeMapping.setNodeMappingMap(nodeMappingMap);
		mergeTree.setNodeMapping(mergeTreeMapping);
		
		Map<ServiceNodeValue,ServiceNodeStatistics> nodeStatisticsMap;
		if(idfMergeNodeStatisticsMap.get(idfNumber) == null)
		{
			nodeStatisticsMap = new HashMap<ServiceNodeValue, ServiceNodeStatistics>();
			idfMergeNodeStatisticsMap.put(idfNumber.intern(), nodeStatisticsMap);
		}
		else
			nodeStatisticsMap = idfMergeNodeStatisticsMap.get(idfNumber);
		
		for (int i = 0; i < treeList.size(); i++) {
			ServiceNodeMapping mapping = treeList.get(i).getNodeMapping();
			ServiceNode rootNode = treeList.get(i).getRootNode();
			int mergeTreeCount = treeList.get(i).getMergeTreeCount();
			ServiceNodeValue rootNodeValue = mapping.getNodeMappingMap().get(rootNode);
			
			ServiceNode mergeRootNode = null;
			if(mergeTree.getRootNode() == null )
			{
				mergeRootNode = new ServiceNode();
				ServiceNodeValue mergeNodeValue = new ServiceNodeValue();
				mergeNodeValue.setFunctionName(rootNodeValue.getFunctionName().intern());
				mergeNodeValue.setFuncationDescription(rootNodeValue.getFuncationDescription().intern());
//				nodeValue.setLevel(rootNodeValue.getLevel());
				mergeTree.setRootNode(mergeRootNode);
				mergeTreeMapping.getNodeMappingMap().put(mergeRootNode,mergeNodeValue);
//				System.out.println(mergeRootNode.hashCode());
			}
			else
				mergeRootNode = mergeTree.getRootNode();
			setNodeStatistics(nodeStatisticsMap,mapping,rootNode, mergeTreeMapping,mergeRootNode,mergeTree.getMergeTreeCount());
			mergeNode(mapping, rootNode,mergeTreeMapping,mergeRootNode,nodeStatisticsMap,mergeTree.getMergeTreeCount(),mergeTreeCount);
			mergeTree.setMergeTreeCount(mergeTree.getMergeTreeCount() + mergeTreeCount);
		}
		ServiceNode node = mergeTree.getRootNode();
		ServiceNodeStatistics rootNodeStatistic = nodeStatisticsMap.get(mergeTreeMapping.getNodeMappingMap().get(node));
		calStatisticPercentage(node,nodeStatisticsMap,mergeTreeMapping,rootNodeStatistic);
//		System.out.println("============+++++==============");
//		print(nodeStatisticsMap);
//		System.out.println("============+++++==============");
		
		return mergeTree;
	}
	
	private void calStatisticPercentage(ServiceNode node,Map<ServiceNodeValue,ServiceNodeStatistics> nodeStatisticsMap,ServiceNodeMapping mergeTreeMapping,ServiceNodeStatistics rootNodeStatistic) {
		
		ServiceNodeValue nodeValue = mergeTreeMapping.getNodeMappingMap().get(node);
		ServiceNodeStatistics nodeStatistics = nodeStatisticsMap.get(nodeValue);
		nodeStatistics.setAvgTime(nodeStatistics.getTotalTime() / nodeStatistics.getCount());
		nodeStatistics.setSelfAvgTime(nodeStatistics.getTotalSelfTime() / nodeStatistics.getCount());
		
//		ServiceNode rootMergeNode = NodeUtil.getRootNode(node);
//		ServiceNodeValue rootMergeNodeValue = mergeTreeMapping.getNodeMappingMap().get(rootMergeNode);
//		ServiceNodeStatistics rootNodeStatistic = nodeStatisticsMap.get(rootMergeNodeValue);
		
		ServiceNode parentMergeNode = NodeUtil.getParentNode(node);
		ServiceNodeValue parentMergeNodeValue = mergeTreeMapping.getNodeMappingMap().get(parentMergeNode);
		ServiceNodeStatistics parentNodeStatistic = nodeStatisticsMap.get(parentMergeNodeValue);
		
		nodeStatistics.setPercentageAbl((nodeStatistics.getTotalTime() / rootNodeStatistic.getTotalTime()));
		nodeStatistics.setPercentageRel(nodeStatistics.getTotalTime() / parentNodeStatistic.getTotalTime());
		nodeStatistics.setSelfPercentageAbl(nodeStatistics.getTotalSelfTime() / rootNodeStatistic.getTotalTime());
	
//		System.out.println("nodeStatistics.getSelfAvgTime() =" + nodeStatistics.getSelfAvgTime() );
		if(nodeStatistics.getPercentageAbl() > 1 || nodeStatistics.getPercentageRel()>1 || nodeStatistics.getSelfPercentageAbl() > 1)
			System.out.println(nodeStatistics);
		if(node.getChildrenNode() != null)
		{
			for (ServiceNode childNode : node.getChildrenNode()) {
				calStatisticPercentage(childNode, nodeStatisticsMap, mergeTreeMapping,rootNodeStatistic);
			}
		}
	}
	/**
	 * 
	 * @param mapping
	 * @param parentNode
	 * @param rootNodeValue
	 * @param nodeStatisticsMap
	 */
	private void mergeNode(ServiceNodeMapping mapping,ServiceNode parentNode,ServiceNodeMapping mergeMapping,ServiceNode mergeParentNode,Map<ServiceNodeValue,ServiceNodeStatistics> nodeStatisticsMap,int previousCount,int currentCount)
	{
//			setNodeStatistics(nodeStatisticsMap,mapping,parentNode, mergeMapping,mergeParentNode);
		List<ServiceNode> childNodes = parentNode.getChildrenNode();
		if(childNodes != null)
		{
			
		//find the node in merge tree which is not contains in the current input tree
		if(mergeParentNode.getChildrenNode() != null)
		{
			for (ServiceNode mergeChildNode : mergeParentNode.getChildrenNode()) {
				ServiceNodeValue mergeNodeValue = mergeMapping.getNodeMappingMap().get(mergeChildNode);
				boolean findFlag = false;
				String mergeFucntion = (mergeNodeValue.getFunctionName() + " - " + mergeNodeValue.getFuncationDescription()).intern();
				for (ServiceNode childNode : childNodes) {
					ServiceNodeValue nodeValue = mapping.getNodeMappingMap().get(childNode);
					if(mergeFucntion.equals((nodeValue.getFunctionName() + " - " + nodeValue.getFuncationDescription()).intern()))
					{
						findFlag = true;
						break;
					}
				}
				if(!findFlag) 
				{
					//calculate the node avg time priority
					ServiceNode rootMergeNode = NodeUtil.getRootNode(mergeChildNode);
					ServiceNodeValue rootMergeNodeValue = mergeMapping.getNodeMappingMap().get(rootMergeNode);
					ServiceNodeStatistics rootNodeStatistic = nodeStatisticsMap.get(rootMergeNodeValue);
					
					ServiceNodeValue parentMergeNodeValue = mergeMapping.getNodeMappingMap().get(mergeParentNode);
					ServiceNodeStatistics parentNodeStatistic = nodeStatisticsMap.get(parentMergeNodeValue);
					
					ServiceNodeStatistics nodeContainsNodeStatis = nodeStatisticsMap.get(mergeNodeValue);
					nodeContainsNodeStatis.setAvgTime(nodeContainsNodeStatis.getAvgTime() * previousCount / (previousCount + currentCount));
					nodeContainsNodeStatis.setSelfAvgTime(nodeContainsNodeStatis.getSelfAvgTime() * previousCount / (previousCount + currentCount));
					nodeContainsNodeStatis.setPercentageAbl(nodeContainsNodeStatis.getAvgTime() / rootNodeStatistic.getAvgTime());
					nodeContainsNodeStatis.setPercentageRel(nodeContainsNodeStatis.getAvgTime() / parentNodeStatistic.getAvgTime());
					nodeContainsNodeStatis.setSelfPercentageAbl(nodeContainsNodeStatis.getSelfAvgTime() / rootNodeStatistic.getAvgTime());
				}
			}
		}
		for (ServiceNode childNode : childNodes) {
			ServiceNodeValue childNodeValue = mapping.getNodeMappingMap().get(childNode);
			ServiceNode mergeChildNode = null;
			String nodeFunction = (childNodeValue.getFunctionName() + " - " + childNodeValue.getFuncationDescription()).intern();
			if(mergeParentNode.getChildrenNode() == null)
			{
				mergeChildNode = new ServiceNode();
				ServiceNodeValue mergeChildNodeValue = new ServiceNodeValue();
				mergeChildNode.setParentNode(mergeParentNode);
				List<ServiceNode> mergeChildNodeList = new ArrayList<ServiceNode>();
				mergeChildNodeList.add(mergeChildNode);
				mergeParentNode.setChildrenNode(mergeChildNodeList);
				
//				mergeNodeValue.setExecutionTime(childNodeValue.getExecutionTime());
				mergeChildNodeValue.setFunctionName(childNodeValue.getFunctionName().intern());
				mergeChildNodeValue.setFuncationDescription(childNodeValue.getFuncationDescription().intern());
				mergeMapping.getNodeMappingMap().put(mergeChildNode, mergeChildNodeValue);
			}
			else
			{
				//the mergeParentNode has children, find node which the function belongs to 
				boolean findFlag = false;
				for(ServiceNode node : mergeParentNode.getChildrenNode())
				{
					ServiceNodeValue nodeValue = mergeMapping.getNodeMappingMap().get(node);
					if(nodeFunction.equals((nodeValue.getFunctionName() + " - " + nodeValue.getFuncationDescription()).intern()))
					{
								
						mergeChildNode = node;
						findFlag = true;
					}
						
				}
					
				//the nodeStatisticsMap contains the function but is not the mergeParentNode's child
				if(!findFlag)
				{
					mergeChildNode = new ServiceNode();
					ServiceNodeValue mergeNodeValue = new ServiceNodeValue();
					mergeChildNode.setParentNode(mergeParentNode);
					mergeParentNode.getChildrenNode().add(mergeChildNode);
//					mergeNodeValue.setExecutionTime(childNodeValue.getExecutionTime());
					mergeNodeValue.setFunctionName(childNodeValue.getFunctionName().intern());
					mergeNodeValue.setFuncationDescription(childNodeValue.getFuncationDescription().intern());
					mergeMapping.getNodeMappingMap().put(mergeChildNode, mergeNodeValue);
				}
			}
			setNodeStatistics(nodeStatisticsMap,mapping,childNode, mergeMapping,mergeChildNode,previousCount);
			if(childNode.getChildrenNode() != null)
				mergeNode(mapping, childNode,mergeMapping,mergeChildNode,nodeStatisticsMap,previousCount,currentCount);
		}
		}
	}
	
	private void setNodeStatistics(Map<ServiceNodeValue,ServiceNodeStatistics> nodeStatisticsMap, ServiceNodeMapping mapping,ServiceNode node,ServiceNodeMapping mergemapping,ServiceNode mergeNode,int previousTreeCount)
	{
		ServiceNodeValue nodeValue = mapping.getNodeMappingMap().get(node);
		ServiceNodeStatistics nodeStatistic = nodeStatisticsMap.get(nodeValue);
//		String function = nodeValue.getFunctionName() + " - " + nodeValue.getFuncationDescription();
		ServiceNodeStatistics mergeNodeStatic = null;
		
		//the nodeStatisticsMap contains the function, it's not the first time to calculate
		ServiceNodeValue mergeNodeValue = mergemapping.getNodeMappingMap().get(mergeNode);
		if(nodeStatisticsMap.get(mergeNodeValue) != null)
		{
			mergeNodeStatic = nodeStatisticsMap.get(mergeNodeValue);
			if(nodeStatistic.getMaxTime() > mergeNodeStatic.getMaxTime())
				mergeNodeStatic.setMaxTime(nodeStatistic.getMaxTime());
			if(nodeStatistic.getMinTime() < mergeNodeStatic.getMinTime())
				mergeNodeStatic.setMinTime(nodeStatistic.getMinTime());
			mergeNodeStatic.setCount(mergeNodeStatic.getCount() + nodeStatistic.getCount());
			mergeNodeStatic.setTotalTime(mergeNodeStatic.getTotalTime() + nodeStatistic.getAvgTime() * nodeStatistic.getCount());
			mergeNodeStatic.setTotalSelfTime(mergeNodeStatic.getTotalSelfTime() + nodeStatistic.getSelfAvgTime() * nodeStatistic.getCount());
		}
		//it's the first time the function to be calculated, put new nodeStatic to nodeStatisticsMap
		else
		{
			mergeNodeStatic = new ServiceNodeStatistics();
			mergeNodeStatic.setCount(nodeStatistic.getCount());
			mergeNodeStatic.setMaxTime(nodeStatistic.getMaxTime());
			mergeNodeStatic.setMinTime(nodeStatistic.getMinTime());
			mergeNodeStatic.setTotalSelfTime(nodeStatistic.getCount() * nodeStatistic.getSelfAvgTime());
			mergeNodeStatic.setTotalTime(nodeStatistic.getCount() * nodeStatistic.getAvgTime());
			nodeStatisticsMap.put(mergeNodeValue, mergeNodeStatic);
		}
	}
	
	
	
	private long getStartTime(Map<String,List<ServiceRequestTree>> map)
	{
		long startTime = Long.MAX_VALUE;
		Set<String> idfNumbers = map.keySet();
		for (String idfNumber : idfNumbers) {
			List<ServiceRequestTree> treeList = map.get(idfNumber);
			for (ServiceRequestTree requestTree : treeList) {
				if(startTime > requestTree.getStartTime())
					startTime = requestTree.getStartTime();
			}
		}
		return startTime;
	}
	
	private long getEndTime(Map<String,List<ServiceRequestTree>> map)
	{
		long endTime = Long.MIN_VALUE;
		Set<String> idfNumbers = map.keySet();
		for (String idfNumber : idfNumbers) {
			List<ServiceRequestTree> treeList = map.get(idfNumber);
			for (ServiceRequestTree requestTree : treeList) {
				if(endTime < requestTree.getEndTime())
					endTime = requestTree.getEndTime();
			}
		}
		return endTime;
	}
	
	/**
	 * The method statistic the response time points and TPS points of different services for showing in page. 
	 * @param idfMap
	 * @param maxPointSize
	 */
	public void tpsRespTimeStatistic(Map<String,List<ServiceRequestTree>> idfMap,int maxPointSize)
	{
		//the start time and end time unit is ms
		long startTime = getStartTime(idfMap);
		long endTime = getEndTime(idfMap);
		//analyze every 1000ms
		
//		int interval = 1;
		int interval = (int)(Math.ceil((float)((endTime - startTime)/1000)/maxPointSize));
		int intervalMs = interval * (int) Math.pow(10,3);
		if(interval < 1)
		{
			interval =1;
			intervalMs = (int) Math.pow(10,3);
		}
		//tps and response time map, key: timestamp; value: tps and response time
//		Map<Long,Map<String,TPSResponseTime>> statisMap = new HashMap<Long, Map<String,TPSResponseTime>>();
		
		Set<String> idfNumbers = idfMap.keySet();
		
		for (long i = startTime; i < endTime ; i = i + intervalMs) {
			//key: idf number
			Map<String,TPSResponseTime> tpsRespTimeMap = new HashMap<String, TPSResponseTime>();
			statisMap.put(i + intervalMs, tpsRespTimeMap);
			//foreach idfTreeMap get the idfNumber
			for (String idfNumber : idfNumbers) {
				//get the idf number tree list
				List<ServiceRequestTree> trees = idfMap.get(idfNumber);
				if(statisMap.get(i + intervalMs).get(idfNumber) == null)
				{
					TPSResponseTime tempTpsResponseTime = new TPSResponseTime();
					statisMap.get(i + intervalMs).put(idfNumber.intern(), tempTpsResponseTime);
				}
				for (ServiceRequestTree tree : trees) {
					if(tree.getEndTime() > i && tree.getEndTime() <= i + intervalMs)
					{
						TPSResponseTime tempTpsResponseTime = statisMap.get(i + intervalMs).get(idfNumber);
						float avgResponseTime = tempTpsResponseTime.getResponseTime();
						int count = tempTpsResponseTime.getCount();
						float tps = tempTpsResponseTime.getTps();
						tempTpsResponseTime.setResponseTime((avgResponseTime * count + tree.getNodeMapping().getNodeMappingMap().get(tree.getRootNode()).getExecutionTime())/(count + 1));
						tempTpsResponseTime.setTps((tps * interval + 1)/ interval );
						tempTpsResponseTime.setCount(count + 1);
						
					}
				}
				
			}
		}
			Set<Long> timeSet = statisMap.keySet();
		for (Long time : timeSet) {
			//key: IDF number
			Map<String, TPSResponseTime> tpsRespMap = statisMap.get(time);
//			Map<String, TPSResponseTime> totalTpsRespMap = new HashMap<String, TPSResponseTime>();
			TPSResponseTime tpsResp = new TPSResponseTime();
			float totalThroughput = 0;
			float totalRespTime = 0;
			Set<String> idfs = tpsRespMap.keySet();
			for (String idf : idfs) {
				TPSResponseTime idfTpsResp = tpsRespMap.get(idf);
				totalThroughput = totalThroughput + idfTpsResp.getCount();
				totalRespTime = totalRespTime + idfTpsResp.getCount() * idfTpsResp.getResponseTime(); 
			}
			if(totalThroughput == 0)
			{
				tpsResp.setCount(0);
				tpsResp.setResponseTime(0);
				tpsResp.setTps(0);
			}
			else{
				tpsResp.setCount((int)totalThroughput);
				tpsResp.setTps(totalThroughput / interval );
				tpsResp.setResponseTime(totalRespTime / totalThroughput);
			}
			tpsRespMap.put("0", tpsResp);
//			statisMap.put(time, totalTpsRespMap);
		}
		
	}
}

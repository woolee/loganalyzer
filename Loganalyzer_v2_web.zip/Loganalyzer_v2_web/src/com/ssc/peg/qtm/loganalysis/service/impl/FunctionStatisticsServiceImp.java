package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.dao.FuncRatioTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FuncTimeTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceFunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncRatioTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncTimeTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.FunctionStatisticsService;

@org.springframework.stereotype.Service
public class FunctionStatisticsServiceImp<T extends FunctionStatistics> implements
		FunctionStatisticsService<T> {

	@Inject
	private FunctionStatisticsDao<T> dao;
	@Inject
	private FunctionDao<Function> funcDao;
	
	@Inject
	private ServiceFunctionDao<ServiceFunction> functionStatisInIDFDao;
	
	@Inject
	private ServiceDao<Service> servDao;
	
	@Inject
	private FuncRatioTopNDao<FuncRatioTopN> funcRatioDao;
	
	@Inject
	private TreeDao<Tree> treeDao;
	
	@Inject
	private FuncTimeTopNDao<FuncTimeTopN> funcTimeDao;

	@Override
	public T getFunctionStaByFunctionId(int functionId) {
		// TODO Auto-generated method stub
		return dao.getFunctionStaByFunctionId(functionId);
	}

	@Override
	public List<T> getFunctionStaByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return dao.getFunctionStaByAnalysisId(analysisId);
	}

	
	@Override
	@Transactional
	public List<List> getFunctionRatioInService(int functionId, int analysisId) {
		Function function = funcDao.getFunctionById(functionId);
		String functionName = function.getFunctionName() + " - " + function.getFunctionDescription();
		List<String> functionnamelist = new ArrayList<String>();
		functionnamelist.add(functionName);
		List<String> strlist_idfnumber = new ArrayList<String>();
		List<Float> strlist_percentageabs = new ArrayList<Float>();
		List<Float> strlist_selfpercentageabs = new ArrayList<Float>();
		List<Float> strlist_childpercentageabs = new ArrayList<Float>();
		List<Float> strlist_totalavgTime = new ArrayList<Float>();
		List<Float> strlist_selfavgTime = new ArrayList<Float>();
		List<Float> strlist_childrenavgTime = new ArrayList<Float>();
		List<Integer> function_id_list = new ArrayList<Integer>();
		List<Integer> service_id_list = new ArrayList<Integer>();
		List<List> idfnumber_and_percentage = new ArrayList<List>();
		
		List<ServiceFunction> functStatisInService = functionStatisInIDFDao.getServiceFuncByFunctionAnalysisId(analysisId, functionId);
//		Set<Service> serviceList = new HashSet<Service>();
		for(ServiceFunction functionInService : functStatisInService){
			//too many operations of get service id
			Service service = servDao.getServiceById(functionInService.getServiceId()); 
			strlist_idfnumber.add(service.getServiceName());
//			serviceList.add(service);
			strlist_percentageabs.add( functionInService.getRatio()*100);
			strlist_selfpercentageabs.add( functionInService.getSelfRatio()*100);
//			System.out.println("(functionInService.getRatio()-functionInService.getSelfRatio())*100=" + (functionInService.getRatio()-functionInService.getSelfRatio())*100);
			strlist_childpercentageabs.add( (functionInService.getRatio()-functionInService.getSelfRatio())*100);
			strlist_totalavgTime.add(functionInService.getAvgTime()/1000000);
			strlist_selfavgTime.add(functionInService.getSelfAvgTime()/1000000);
			strlist_childrenavgTime.add((functionInService.getAvgTime()-functionInService.getSelfAvgTime())/1000000);
			function_id_list.add(functionInService.getFunctionId());
			service_id_list.add(functionInService.getServiceId());
		}
		
		idfnumber_and_percentage.add(0, strlist_idfnumber);
		idfnumber_and_percentage.add(1, strlist_percentageabs);
		idfnumber_and_percentage.add(2, functionnamelist);
		idfnumber_and_percentage.add(3, strlist_selfpercentageabs);
		idfnumber_and_percentage.add(4, strlist_childpercentageabs);
		idfnumber_and_percentage.add(5, strlist_totalavgTime);
		idfnumber_and_percentage.add(6, strlist_selfavgTime);
		idfnumber_and_percentage.add(7, strlist_childrenavgTime);
		idfnumber_and_percentage.add(8, function_id_list);
		idfnumber_and_percentage.add(9, service_id_list);
		return idfnumber_and_percentage;
	}
	@Override
	@Transactional
	public List<List> getFuncRatioTopN(int functionId, int analysisId,
			String serviceName) {
		List<String> requestid = new ArrayList<String>();
		List<Float> requestpercentage = new ArrayList<Float>();//function percentage in request
		List<List> top5request = new ArrayList<List>();
		
		int serviceId = servDao.getServiceByName(serviceName).getServiceId();
		List<FuncRatioTopN>  funcRatioTopNInService = funcRatioDao.getTopNByFunctionServiceId(functionId, serviceId,analysisId);
		
		for (FuncRatioTopN funcRatioTopN : funcRatioTopNInService) {
			Tree topNTree = treeDao.getTreeByTreeUUID(funcRatioTopN.getTreeUUID());
			requestid.add(topNTree.getRequestId());
			requestpercentage.add(funcRatioTopN.getRatio()*100);
		}
		top5request.add(0, requestid);
		top5request.add(1, requestpercentage);
		return top5request;
	}
	@Override
	@Transactional
	public List<List> getFuncTimeTopN(int functionId, int analysisId,
			String serviceName) {
		List<String> requestid = new ArrayList<String>();
		List<Float> requesttime = new ArrayList<Float>();//function avgTime in request
		List<List> top5request = new ArrayList<List>();
		
		int serviceId = servDao.getServiceByName(serviceName).getServiceId();
		List<FuncTimeTopN>  funcTimeTopNInService = funcTimeDao.getTopNByFunctionServiceId(functionId, serviceId, analysisId);
		
		for (FuncTimeTopN funcTimeTopN : funcTimeTopNInService) {
			Tree topNTree = treeDao.getTreeByTreeUUID(funcTimeTopN.getTreeUUID());
			requestid.add(topNTree.getRequestId());
			requesttime.add(funcTimeTopN.getExecutionTime()/1000000);
		}
		top5request.add(0, requestid);
		top5request.add(1, requesttime);
		return top5request;
	}
}

package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface FunctionStatisticsTreeMapper<T> extends SqlMapper {
	public void addFunctionStatistics(T entity);
	public T getFunctionStaById(int id);
	public T getFunctionStaByFunctionId(int functionId);
	public T getFunctionStaByTreeUUID(String treeUUID);
	public List<T> getFunctionStaByAnalysisId(int analysisId);
	public void addFunctionStatisList(List<T> list);
	public void addFunctionStatisListStr(String str);
	public T getFunctionStaByFunctionAndTree(@Param("functionId")int functionId,@Param("treeUUID")String treeUUID);
}

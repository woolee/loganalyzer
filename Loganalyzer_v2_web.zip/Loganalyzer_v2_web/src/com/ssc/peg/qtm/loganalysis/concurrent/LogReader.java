package com.ssc.peg.qtm.loganalysis.concurrent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

/**
 * The class is implements Runnable. 
 * Class read log file or folder to get request tree String object from begin signal to end signal, and put the object to queue.
 * @author a549324
 *
 */
public class LogReader implements Runnable{

    protected BlockingQueue<String> queue = null;
    private File file = null;
    public LogReader(BlockingQueue<String> queue, File file) {
        this.queue = queue;
        this.file = file;
    }
    
    public void run() {
    	System.out.println("start reading logs...");
//    	File file = new File(logFilePath);
    	
    	if(file.exists())
    	{
    		if(file.isDirectory())
    		{
    			List<File> logFileList = new ArrayList<File>();
    			getLogFiles(file, logFileList);
    			StringBuilder stringBuilder = new StringBuilder(20000);
    			if(logFileList.size() > 0)
    			{
    				for(File logFile : logFileList)
    				{
    					readLog(logFile,stringBuilder);
    				}
    			}
    		}
    		else if(file.getName().endsWith(".log"))
    		{
    			
    			StringBuilder stringBuilder = new StringBuilder(20000);
    			readLog(file,stringBuilder);
    		}
    		
    		else
    		{
    			try {
    				throw new FileNotFoundException("Log file is invaild");
    			} catch (FileNotFoundException e) {
    				e.printStackTrace();
    			}
    		}
    	}
    	else
    	{
    		try {
				throw new FileNotFoundException("cannot find the log file");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
    	}
    	System.out.println("read log end...");
    }
    
    private void readLog(File file,StringBuilder stringBuilder)
    {
    	try {
			FileInputStream fileInputStream = null;
			fileInputStream = new FileInputStream(file);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
			String line = br.readLine();
			
			Boolean hasBegin = false;
			while(line != null){
				Boolean beginFlag = line.contains("=Begin=");
				Boolean endFlag = line.contains("=End=");
				
				if(beginFlag){
					hasBegin = true;
				}
				else if(!beginFlag && !endFlag && hasBegin){
					stringBuilder.append(line);
					stringBuilder.append("\n");
				}
				else if(endFlag && hasBegin ){
//					stringBuilder.deleteCharAt(stringBuilder.length()-1);
					queue.put(stringBuilder.toString());
					stringBuilder.setLength(0);
					hasBegin = false;
				}
				line = br.readLine();
				continue;
				
			}//end while
			
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
		
    }
    
    
    public List<File> getLogFiles(File directory,List<File> logFileList)
    {
    	File[] logFiles = directory.listFiles(new FileFilter() {
			
			@Override
			public boolean accept(File pathname) {
				if(pathname.getName().endsWith(".log") || pathname.isDirectory() )
					return true;
				return false;
			}
		}
		);
    	if(logFiles.length > 0)
    	{
    		for (File file : logFiles) {
    			if(file.isDirectory())
    				getLogFiles(file, logFileList);
    			else
    				logFileList.add(file);
    		}
    	}
    	return logFileList;
    }
    
}

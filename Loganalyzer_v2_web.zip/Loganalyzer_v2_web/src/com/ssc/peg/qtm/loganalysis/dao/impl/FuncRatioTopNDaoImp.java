package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.db.bean.FuncRatioTopN;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.FuncRatioTopNMapper;
import com.ssc.peg.qtm.loganalysis.dao.FuncRatioTopNDao;
@Repository
public class FuncRatioTopNDaoImp<T extends FuncRatioTopN> implements FuncRatioTopNDao<T> {

	@Inject
	private FuncRatioTopNMapper<T> mapper;


	@Override
	public boolean addFuncRatioTopN(T entity) {
		boolean flag = false;
		try
		{
			mapper.addFuncRatioTopN(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add FuncRatioTopN to database",e);
		}
		return flag;
		
		
	}


	@Override
	public boolean addFuncRatioTopNList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addFuncRatioTopNList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add FuncRatioTopN list to database",e);
		}
		return flag;
	}


	@Override
	public List<T> getTopNByFunctionServiceId(int functionId, int serviceId,int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getTopNByFunctionServiceId(functionId, serviceId,analysisId);
	}

}

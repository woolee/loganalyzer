package com.ssc.peg.qtm.loganalysis.exception;

public class LogFormatException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 621725970886658720L;

	public LogFormatException()
	{
		super();
	}
	
	public LogFormatException(String message)
	{
		super(message);
	}
	
	public LogFormatException(String message, Throwable  e)
	{
		super(message, e);
	}
}


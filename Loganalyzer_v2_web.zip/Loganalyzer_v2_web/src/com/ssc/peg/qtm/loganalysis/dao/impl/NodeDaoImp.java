package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.NodeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Node;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.NodeMapper;
@Repository
public class NodeDaoImp<T extends Node> implements NodeDao<T> {
	@Inject
	private NodeMapper<T> mapper;
	
	@Override
	public boolean addNode(T entity) throws DataAccessException {
		boolean flag = false;
		try
		{
			mapper.addNode(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Node to database",e);
		}
		return flag;
	}

	@Override
	public T getNodeById(int id) throws DataAccessException {
		// TODO Auto-generated method stub
		return mapper.getNodeByNodeId(id);
	}


	@Override
	public T getNodeByUUID(String uuid) throws DataAccessException {
		// TODO Auto-generated method stub
		return mapper.getNodeByUUID(uuid);
	}

	@Override
	public boolean addNodeList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addNodeList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Node list to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getNodeListByUUID(List<T> list) {
		return mapper.getNodeListByUUID(list);
	}

	@Override
	public List<T> getNodeByParentUUID(String parentUUID)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return mapper.getNodeByParentUUID(parentUUID);
	}

}

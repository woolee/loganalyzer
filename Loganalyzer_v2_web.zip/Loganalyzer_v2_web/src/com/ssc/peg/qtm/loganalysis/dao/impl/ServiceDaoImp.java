package com.ssc.peg.qtm.loganalysis.dao.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.ServiceMapper;
@Repository
public class ServiceDaoImp<T extends Service> implements ServiceDao<T> {

	@Inject
	private ServiceMapper<T> mapper;
	
	@Override
	public boolean addService(T entity) {
		boolean flag = false;
		try
		{
			mapper.addService(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Service to database",e);
		}
		return flag;
	}

	@Override
	public T getServiceById(int id) {
		// TODO Auto-generated method stub
		return mapper.getServiceById(id);
	}

	@Override
	public T getServiceByName(String name) {
		// TODO Auto-generated method stub
		return mapper.getServiceByName(name);
	}

}

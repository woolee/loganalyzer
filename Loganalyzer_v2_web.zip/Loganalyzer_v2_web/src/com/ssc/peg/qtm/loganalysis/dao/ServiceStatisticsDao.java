package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;


public interface ServiceStatisticsDao<T> {
	public boolean addServiceStatistics(T entity);
	public boolean addServiceStatisticsList(List<T> list);
	public List<T> getServiceStatisListByAnalysisId(int analysisId);
}

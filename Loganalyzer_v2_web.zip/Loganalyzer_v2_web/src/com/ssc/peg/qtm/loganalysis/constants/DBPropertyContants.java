package com.ssc.peg.qtm.loganalysis.constants;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class DBPropertyContants {
	public static final String DRIVER = getProperty("mysql.driver");
	public static final String URL = getProperty("mysql.url");
	public static final String USER = getProperty("mysql.user");
	public static final String PWD = getProperty("mysql.password");
	
	private static String getProperty(String propertyName) {
		String property = "";
		InputStream is = DBPropertyContants.class.getClassLoader().getResourceAsStream("./mysql.properties");
		//System.out.println("getProperty:" + new FilePathConstants().getClass().getClassLoader().toString());
		Properties prop = new Properties();     
			try {
				prop.load(is);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			property = prop.getProperty(propertyName);
		prop.clear();
		
		return property;
	}
	
	public static void main(String[] args) {
		System.out.println(DBPropertyContants.DRIVER);
	}
}

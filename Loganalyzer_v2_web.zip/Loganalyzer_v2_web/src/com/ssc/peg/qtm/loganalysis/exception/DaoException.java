package com.ssc.peg.qtm.loganalysis.exception;

import org.springframework.dao.DataAccessException;

public class DaoException extends DataAccessException
{

	public DaoException(String msg)
	{
		super(msg);
		// TODO Auto-generated constructor stub
	}

	public DaoException(String msg, Throwable cause )
	{
		super(msg, cause);
		// TODO Auto-generated constructor stub
	}
}
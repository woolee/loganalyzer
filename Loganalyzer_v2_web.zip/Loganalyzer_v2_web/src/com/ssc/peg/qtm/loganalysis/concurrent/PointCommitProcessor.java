package com.ssc.peg.qtm.loganalysis.concurrent;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.dao.PointDao;
public class PointCommitProcessor implements Runnable {

	private List<Point> pointList = null;
	private PointDao<Point> pointDao ;
	private AtomicBoolean pointCommitFlag;
	public PointCommitProcessor(List<Point> pointList,PointDao<Point> pointDao,AtomicBoolean pointCommitFlag) {
		this.pointList = pointList;
		this.pointDao = pointDao;
		this.pointCommitFlag = pointCommitFlag;
	}

	public void run() {
		while(true)
		{
			if(pointCommitFlag.get())
			{
				
				pointDao.addPointList(pointList);
			}
		}
	}

	
}
package com.ssc.peg.qtm.loganalysis.bean;

import java.util.HashMap;
import java.util.Map;

import com.ssc.peg.qtm.loganalysis.analysis.IDFData;

/**
 * This class is composed by a number of map used for temporary storage request information tree.
 *  Different information in different analysis use different UUID to distinguish.
 *  
 * @author a549324
 * 
 */
public class CommonMap {
	private Map<String,ServiceMergeTree> idfMergeTreeMap = new HashMap<String,ServiceMergeTree>();
//	= new HashMap<String, RequestTree>();
	private  Map<String,Map<ServiceNodeValue,ServiceNodeStatistics>> idgMergeNodeStatisticsMap = new HashMap<String,Map<ServiceNodeValue,ServiceNodeStatistics>>();
//	= new HashMap<String, Map<NodeValue,NodeStatistics>>();
	private  Map<Long,Map<String,TPSResponseTime>> statisMap = new HashMap<Long, Map<String,TPSResponseTime>>();

	private Map<String,IDFData> idfMap = new HashMap<String, IDFData>();
	private  Map<String,FunctionStatistics> functionScoreMap = new HashMap<String,FunctionStatistics>();

	public Map<String, ServiceMergeTree> getIdfMergeTreeMap() {
		return idfMergeTreeMap;
	}

	public void setIdfMergeTreeMap(Map<String, ServiceMergeTree> idfMergeTreeMap) {
		this.idfMergeTreeMap = idfMergeTreeMap;
	}

	public Map<String, Map<ServiceNodeValue, ServiceNodeStatistics>> getIdgMergeNodeStatisticsMap() {
		return idgMergeNodeStatisticsMap;
	}

	public void setIdgMergeNodeStatisticsMap(
			Map<String, Map<ServiceNodeValue, ServiceNodeStatistics>> idgMergeNodeStatisticsMap) {
		this.idgMergeNodeStatisticsMap = idgMergeNodeStatisticsMap;
	}

	public Map<Long, Map<String, TPSResponseTime>> getStatisMap() {
		return statisMap;
	}

	public void setStatisMap(Map<Long, Map<String, TPSResponseTime>> statisMap) {
		this.statisMap = statisMap;
	}

	public Map<String, FunctionStatistics> getFunctionScoreMap() {
		return functionScoreMap;
	}

	public void setFunctionScoreMap(Map<String, FunctionStatistics> functionScoreMap) {
		this.functionScoreMap = functionScoreMap;
	}

	public Map<String, IDFData> getIdfMap() {
		return idfMap;
	}

	public void setIdfMap(Map<String, IDFData> idfMap) {
		this.idfMap = idfMap;
	}
	
	
}

package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;


public interface FuncTimeTopNMapper<T> extends SqlMapper {
	public void addFuncTimeTopN(T entity);
	public void addFuncTimeTopNList(List<T> list);
	public List<T> getTopNByFunctionServiceId(@Param("functionId")int functionId, @Param("serviceId")int serviceId,@Param("analysisId")int analysisId);
}

package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;

public interface FunctionStatisticsInServService<T> {
	public T getServiceFuncByFuncAndService(int analysisId,int serviceId,int functionId);
	public List<T> gettopNfunctioninservice(int analysisId,int serviceId,int N);
	public List<T> getFunctionStatisticBiggerThan(int analysisId,int serviceId,float ratio);
	public Map<Integer,List<T>> getFuncStatisMapByRatio(int analysisId,float ratio,Set<Integer> serviceIdSet);
}

package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

public class ServiceTopN implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4596743964028103652L;
	private int id;
	private int serviceId;
	private String treeUUID;
	private int analysisId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getTreeUUID() {
		return treeUUID;
	}
	public void setTreeUUID(String treeUUID) {
		this.treeUUID = treeUUID;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	
}

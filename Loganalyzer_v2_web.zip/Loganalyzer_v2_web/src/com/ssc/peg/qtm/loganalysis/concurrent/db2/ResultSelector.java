package com.ssc.peg.qtm.loganalysis.concurrent.db2;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;

import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TimePicker;
import com.ssc.peg.qtm.loganalysis.exception.LogFormatException;
import com.ssc.peg.qtm.loganalysis.concurrent.ConcurrentMapManager;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;
import com.ssc.peg.qtm.loganalysis.concurrent.TreeReader;

public class ResultSelector implements Runnable {
	private Logger log = Logger.getLogger(getClass());
	private String queueString = null;
	private int topN = 10;
	private String uuid ;
	private TimePicker timePicker;
	private AtomicInteger atomicInt;
	public ResultSelector(String queueString,String uuid,int topN,AtomicInteger atomicInt) {
		this.queueString = queueString;
		this.topN = topN;
		this.uuid = uuid;
		this.atomicInt = atomicInt;
		
		
	}

	public ResultSelector(String queueString,String uuid,TimePicker timePicker,AtomicInteger atomicInt) {
		this.queueString = queueString;
		this.uuid = uuid;
		this.timePicker = timePicker;
		this.atomicInt = atomicInt;
	}
	public void run() {
		ServiceRequestTree tree = null;
		try {
			tree = new TreeTransfer(timePicker).rsToMemory(queueString);
			log.info("atomicInt=" + atomicInt.incrementAndGet() );
//			if(tree.getIdfNumber() == null)
//				System.out.println(tree.getRequestId());
		} catch (Exception e) {
			log.error(queueString,e);
			return;
		}
		if (tree != null) {
//			System.out.println("atomicInt=" + atomicInt + " process one -----");
			ConcurrentMapManager manager = DataMapSelector.selectConcurrentMap(uuid);
			manager.addToTopNMap(tree, topN);

			manager.addToIDFTreeMap(tree);

			manager.addToInvertedIdfTreeMap(tree);
			
			manager.addToFunctionRatioTopN(tree, 5);

			manager.addToFunctionTimeTopN(tree, 5);
		}
	}

	
}
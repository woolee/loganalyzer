package com.ssc.peg.qtm.loganalysis.bean;

import java.util.List;

public class ServiceMergeTree {
	private ServiceRequestTree allMergeTree;
	private List<ServiceRequestTree> structureMergeTree;
	public List<ServiceRequestTree> getStructureMergeTree() {
		return structureMergeTree;
	}
	public void setStructureMergeTree(List<ServiceRequestTree> structureMergeTree) {
		this.structureMergeTree = structureMergeTree;
	}
	public ServiceRequestTree getAllMergeTree() {
		return allMergeTree;
	}
	public void setAllMergeTree(ServiceRequestTree allMergeTree) {
		this.allMergeTree = allMergeTree;
	}
	
}

package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;

public interface PointService<T> {
	public List<T> getTPSRespTimeByAnalysisServiceId(int analysisId,int serviceId);
}

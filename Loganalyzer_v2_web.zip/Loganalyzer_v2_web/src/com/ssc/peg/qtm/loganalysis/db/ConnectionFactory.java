package com.ssc.peg.qtm.loganalysis.db;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.ssc.peg.qtm.loganalysis.constants.DBPropertyContants;

public class ConnectionFactory {  
	  
    private ConnectionFactory(){  
    }      
  
    private static ComboPooledDataSource ds = null;  
  
    static {  
        try {  
            // Logger log = Logger.getLogger("com.mchange"); 
              // log.setLevel(Level.WARNING);  
              ds = new ComboPooledDataSource();  
              ds.setDriverClass(DBPropertyContants.DRIVER);    
              ds.setJdbcUrl(DBPropertyContants.URL);  
              ds.setUser(DBPropertyContants.USER);  
              ds.setPassword(DBPropertyContants.PWD);  
              ds.setMaxPoolSize(200);  
              ds.setMinPoolSize(20);  
        } catch (PropertyVetoException e) {  
            e.printStackTrace();  
        }  
    }  
    
    public static synchronized Connection getConnection() {  
        Connection con = null;  
        try {  
            con = ds.getConnection();  
        } catch (SQLException e1) {  
            e1.printStackTrace();  
        }  
        return con;  
    }  
    // C3P0 end  
}  
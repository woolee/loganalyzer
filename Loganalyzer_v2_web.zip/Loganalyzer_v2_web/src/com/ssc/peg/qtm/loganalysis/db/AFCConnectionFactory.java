package com.ssc.peg.qtm.loganalysis.db;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * This class is used for get DB2 connection according to the specified server,port,database
 * @author a549324
 *
 */
public class AFCConnectionFactory {  
	private static final String DRIVER = "com.ibm.db2.jcc.DB2Driver";
	private static String server;
	private static String port;
	private static String db;
	private static String user;
	private static String password;

	
    private AFCConnectionFactory(){  
    }      
  
    private static ComboPooledDataSource ds = null;  
  
    static {  
    	 
            // Logger log = Logger.getLogger("com.mchange"); 
              // log.setLevel(Level.WARNING);  
            ds = new ComboPooledDataSource();  
            ds.setMaxPoolSize(20);  
            ds.setMinPoolSize(0);  
            
            
       
        	try {
				Class.forName(DRIVER);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }  
    
    public static synchronized Connection getConnection() {
    	try {  
    	ds.setDriverClass(DRIVER);    
        ds.setJdbcUrl("jdbc:db2://"+server+":" + port + "/"+ db);
        ds.setUser(user);  
        ds.setPassword(password); 
    	 } catch (PropertyVetoException e) {  
             e.printStackTrace();  
         }  
        Connection con = null;  
        try {  
            con = ds.getConnection();  
        } catch (SQLException e1) {  
            e1.printStackTrace();  
        }  
        return con;  
    }

	public static void setServer(String server) {
		AFCConnectionFactory.server = server;
	}

	public static void setPort(String port) {
		AFCConnectionFactory.port = port;
	}

	public static void setDb(String db) {
		AFCConnectionFactory.db = db;
	}

	public static void setUser(String user) {
		AFCConnectionFactory.user = user;
	}

	public static void setPassword(String password) {
		AFCConnectionFactory.password = password;
	}

	public static void setDs(ComboPooledDataSource ds) {
		AFCConnectionFactory.ds = ds;
	}  
    
    
    // C3P0 end  
}  
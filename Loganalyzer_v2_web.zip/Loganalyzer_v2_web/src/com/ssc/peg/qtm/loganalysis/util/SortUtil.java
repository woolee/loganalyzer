package com.ssc.peg.qtm.loganalysis.util;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.ssc.peg.qtm.loganalysis.bean.ServiceFunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;

public class SortUtil {
	public static List<ServiceRequestTree> sortByExecutionTime(List<ServiceRequestTree> treeList)
	{
		Collections.sort(treeList, new Comparator<ServiceRequestTree>() {

			@Override
			public int compare(ServiceRequestTree tree1, ServiceRequestTree tree2) {
				long treeExecTime1 = tree1.getNodeMapping().getNodeMappingMap().get(tree1.getRootNode()).getExecutionTime();
				long treeExecTime2 = tree2.getNodeMapping().getNodeMappingMap().get(tree2.getRootNode()).getExecutionTime();
				if(treeExecTime1 < treeExecTime2)
					return -1;
				else if(treeExecTime1 == treeExecTime2)
					return 0;
				else 
					return 1;
			}
		});
		return treeList;
	}
	
	public static ServiceRequestTree getStartTree(List<ServiceRequestTree> treeList)
	{
		ServiceRequestTree tree = Collections.min(treeList, new Comparator<ServiceRequestTree>() {

			@Override
			public int compare(ServiceRequestTree tree1, ServiceRequestTree tree2) {
				long time1 = tree1.getStartTime();
				long time2 = tree2.getStartTime();
				return (int) (time1 - time2);
			}
		});
		return tree;
	}
	
	public static ServiceRequestTree getEndTree(List<ServiceRequestTree> treeList)
	{
		ServiceRequestTree tree = Collections.max(treeList, new Comparator<ServiceRequestTree>() {

			@Override
			public int compare(ServiceRequestTree tree1, ServiceRequestTree tree2) {
				long time1 = tree1.getEndTime();
				long time2 = tree2.getEndTime();
				return (int) (time1 - time2);
			}
		});
		return tree;
	}
	
	public static List<Point> sortPointByTime(List<Point> pointList)
	{
		Collections.sort(pointList, new Comparator<Point>() {

			@Override
			public int compare(Point o1, Point o2) {
				 return (int) (o1.getPointTime().getTime()-o2.getPointTime().getTime());
			}
		});
		return pointList;
	}
	
	//idf sorted by percentageabs desc
		public static Map sortByRatio(Map<String, ServiceFunctionStatistics> funcStatInServMap) {
			Map sortedMap = new TreeMap(new ValueComparator(funcStatInServMap));
			sortedMap.putAll(funcStatInServMap);
			return sortedMap;
		}
		
	}

	class ValueComparator implements Comparator<Object> {
		 
		Map<String,ServiceFunctionStatistics> map;
	 
		public ValueComparator(Map<String,ServiceFunctionStatistics> map) {
			this.map = map;
		}
	 
		public int compare(Object keyA, Object keyB) {
			Comparable valueA = (Comparable) map.get(keyA).getPercentageByRoot();
			Comparable valueB = (Comparable) map.get(keyB).getPercentageByRoot();
			return valueB.compareTo(valueA);
		}
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface PointDao<T> {
	public boolean addPoint(T entity);
	public T getTPSRespTimePoint(int pointId);
	public List<T> getTPSRespTimeByAnalysisId(int analysisId);
	public boolean addPointList(List<T> list);
	public List<T> getTPSRespTimeByAnalysisServiceId(int analysisId,int serviceId);
}

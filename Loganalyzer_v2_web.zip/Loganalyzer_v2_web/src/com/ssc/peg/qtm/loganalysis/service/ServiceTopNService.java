package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;

public interface ServiceTopNService<T> {
	public List<T> getTopNByAnalyIdAndServiceId(int analysisId,int serviceId);
}

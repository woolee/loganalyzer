package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

public interface FunctionMapper<T>  extends SqlMapper{
	public void addFunction(T entity);
	public T getFunctionById(int id);
	public T getFunctionByNameAndDescription(T entity);
	public List<T> getFunctionListByNameAndDescription(List<T> list);
	public void addFunctionList(List<T> list);
	public List<T> getFunctionList();
}

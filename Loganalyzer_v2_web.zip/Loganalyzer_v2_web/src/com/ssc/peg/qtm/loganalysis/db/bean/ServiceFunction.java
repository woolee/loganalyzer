package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class ServiceFunction implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5087020846913832839L;
	private int relationId;
	private int functionId;
	private int serviceId;
	private float ratio;
	private float avgTime;
	private int count;
	private int analysisId;
	private long maxTime;
	private long minTime;
	private float selfRatio;
	private float selfAvgTime;
	public int getRelationId() {
		return relationId;
	}
	public void setRelationId(int relationId) {
		this.relationId = relationId;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public long getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(long maxTime) {
		this.maxTime = maxTime;
	}
	public long getMinTime() {
		return minTime;
	}
	public void setMinTime(long minTime) {
		this.minTime = minTime;
	}
	public float getSelfRatio() {
		return selfRatio;
	}
	public void setSelfRatio(float selfRatio) {
		this.selfRatio = selfRatio;
	}
	public float getSelfAvgTime() {
		return selfAvgTime;
	}
	public void setSelfAvgTime(float selfAvgTime) {
		this.selfAvgTime = selfAvgTime;
	}
	
	
}

package com.ssc.peg.qtm.loganalysis.constants;

public class Constants
{
        /**
         * the decode/encode of path
         */
	public final static String FILE_PATH_DECODE="utf-8";
	public final static String CURRENT_DATE_FORMAT="MM/dd/yyyy HH:mm:ss";
	public final static String CLOUD_LOG_DATETIME_FORMAT="yyyy-MM-dd HH:mm:ss,SSS";
	public final static String AFC_LOG_DATA_FORMAT="yyyy-MM-dd HH:mm:ss";
	/**
	 * the max rows of excel
	 */
	public static int MAXS_ROWSIZE_OF_SHEET = 65536;
	public static int MAXS_SHEET_SIZE = 5;
	public static final int MAX_SHEET_NAME_LENGTH = 31;
	/**
	 * the max length of a cell
	 */
	public static final int MAX_CELL_LENGTH = 40;
	
}

package com.ssc.peg.qtm.loganalysis.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.ssc.peg.qtm.loganalysis.bean.JsonNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.AnalysisService;
import com.ssc.peg.qtm.loganalysis.service.FunctionService;
import com.ssc.peg.qtm.loganalysis.service.FunctionStatisticsInServService;
import com.ssc.peg.qtm.loganalysis.service.FunctionStatisticsService;
import com.ssc.peg.qtm.loganalysis.service.PointService;
import com.ssc.peg.qtm.loganalysis.service.ServService;
import com.ssc.peg.qtm.loganalysis.service.ServiceStatisticsService;
import com.ssc.peg.qtm.loganalysis.service.ServiceTopNService;
import com.ssc.peg.qtm.loganalysis.service.TreeService;
import com.ssc.peg.qtm.loganalysis.service.JsonService;
import com.ssc.peg.qtm.loganalysis.util.SortUtil;

@Controller
@RequestMapping("/compare")
public class HistoryCompareController {
	@Inject
	private AnalysisService<Analysis> analysisService;
	@Inject
	private FunctionStatisticsService<FunctionStatistics> functionStatisService;
	@Inject
	private ServiceStatisticsService<ServiceStatistics> serviceStatisService;
	@Inject
	private PointService<Point> pointService;
	@Inject
	private ServiceTopNService<ServiceTopN> serviceTopNService;
	@Inject
	private TreeService<Tree> treeService;
	@Inject
	private FunctionStatisticsInServService<ServiceFunction> functionStatisInIDFService;
	@Inject
	private FunctionService<Function> funcService;
	@Inject
	private ServService<Service> servService;
	@Inject
	private JsonService jsonService;
	
	private Map<Integer,FunctionStatistics> getFuncsAsHashMap(List<FunctionStatistics> funcStatisList)
	{
		Map<Integer,FunctionStatistics> funcStatisMap = new HashMap<Integer, FunctionStatistics>();
		for (FunctionStatistics functionStatistics : funcStatisList) {
			funcStatisMap.put(functionStatistics.getFunctionId(), functionStatistics);
		}
		return funcStatisMap;
	}
	
	private Map<Integer,ServiceStatistics> getServsAsHashMap(List<ServiceStatistics> servStatisList)
	{
		Map<Integer,ServiceStatistics> servStatisMap = new HashMap<Integer, ServiceStatistics>();
		for (ServiceStatistics servStatistics : servStatisList) {
			servStatisMap.put(servStatistics.getServiceId(), servStatistics);
		}
		return servStatisMap;
	}
	
	/**
	 * The method is to get information of selected different analysis and compare different analysis result.
	 * At the end of method will jump to historycompare.jsp.
	 * 
	 * @param request
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping("/selectAnalysis")
	public String compareAnalysis(HttpServletRequest request,Model model,HttpSession session)
	{
		SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
		SimpleDateFormat sdfDate =new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		String basicIdStr = request.getParameterValues("iCheck")[0];
		int basicId = Integer.parseInt(basicIdStr);
		String [] analysisIdArr = request.getParameterValues("analysiss");
		List<Integer> selectIdList = new ArrayList<Integer>();
		/*int analysisId1 = 0;
		int analysisId2 = 0;*/
		for (String id : analysisIdArr) {
			if(id.trim().equals(basicIdStr))
			{
				selectIdList.add(0, Integer.parseInt(id));
			}
			else
			{
				selectIdList.add(Integer.parseInt(id));
			}
		}
		
		//key: analysisId value:(map with key functionId)
		Map<Integer,Map<Integer,FunctionStatistics>> functionStatsMap = new HashMap<Integer, Map<Integer,FunctionStatistics>>();
		Map<Integer,List<Point>> pointMap = new HashMap<Integer, List<Point>>();
		Map<Integer,Map<Integer, ServiceStatistics>> serviceStatsMap = new HashMap<Integer, Map<Integer,ServiceStatistics>>();
		Map<Integer,Map<Integer,Function>> funcMapByAnalysisId = new HashMap<Integer, Map<Integer,Function>>();
		Map<Integer,Map<Integer,Service>> servMapByAnalysisId = new HashMap<Integer, Map<Integer,Service>>();
		
		//[KEY:service id , VALUE:[ KEY: analysis id, VALUE: list]] 
		Map<String,Map<String,List<List>> > pointJsonMap = new HashMap<String, Map<String,List<List>>>();
		List<Analysis> analysisList = analysisService.getAnalysisList(selectIdList);
		
		
		Map<String,List<List>> servicePointMap = new HashMap<String, List<List>>();
		for (Analysis analysis: analysisList) {
			
			List<FunctionStatistics> funcStatisList = functionStatisService.getFunctionStaByAnalysisId(analysis.getAnalysisId());
			Map<Integer,FunctionStatistics> funcStatisMap = getFuncsAsHashMap(funcStatisList);
			functionStatsMap.put(analysis.getAnalysisId(), funcStatisMap);
			
			pointJsonMap.put("0", servicePointMap);
			List<Point> pointList = pointService.getTPSRespTimeByAnalysisServiceId(analysis.getAnalysisId(), 0);
			String seriesName = sdfDate.format(analysis.getAnalysisTime());
			pointList = SortUtil.sortPointByTime(pointList);
			pointMap.put(analysis.getAnalysisId(), pointList);
			
			List<String> time = new ArrayList<String>();
			List<Float> tps = new ArrayList<Float>();
			List<Float> responsetime = new ArrayList<Float>();
			List<Long> timestamp = new ArrayList<Long>();
			List<String> seriesNameList = new ArrayList<String>();
			List<List> pointJsonList = new ArrayList<List>();
			long startTime = pointList.get(0).getPointTime().getTime();
			for(Point point : pointList){
				seriesNameList.add(seriesName);
				time.add(sdf.format(point.getPointTime()) ); //get time 
				tps.add(point.getTps());//get tps
				responsetime.add(point.getRespTime()/1000000);//get responsetime
				timestamp.add(point.getPointTime().getTime()- startTime);
			}
			pointJsonList.add(0, time);
			pointJsonList.add(1, tps);
			pointJsonList.add(2, responsetime);
			pointJsonList.add(3, timestamp);
			pointJsonList.add(4,seriesNameList);
			servicePointMap.put(analysis.getAnalysisId()+"", pointJsonList);
			
			List<ServiceStatistics> servStatisList = serviceStatisService.getServiceStatisListByAnalysisId(analysis.getAnalysisId());
			Map<Integer, ServiceStatistics> servStatisMap = getServsAsHashMap(servStatisList);
			serviceStatsMap.put(analysis.getAnalysisId(), servStatisMap);
			
			Map<Integer,Function> funcMap = funcService.getFunctionListByFunctionStatistic(funcStatisList);
			funcMapByAnalysisId.put(analysis.getAnalysisId(), funcMap);
			
			Map<Integer,Service> serviceMap = servService.getServiceByServiceStatics(servStatisList);
			servMapByAnalysisId.put(analysis.getAnalysisId(), serviceMap);
		}
		
		
		
		
		//-----get the functions,services that all analysiss contain-----
		Map<Integer,Function> sameFunctionMap = null;
		Map<Integer,Function> diffFunctionMap = null;
		Iterator<Integer> iterator = funcMapByAnalysisId.keySet().iterator();
		if(iterator.hasNext())
		{
			int analysisId = iterator.next();
			sameFunctionMap = new HashMap<Integer,Function>(funcMapByAnalysisId.get(analysisId));
			diffFunctionMap = new HashMap<Integer,Function>();
		}
		while(iterator.hasNext())
		{
			List<Integer> removeFunctions = new ArrayList<Integer>();
			Map<Integer,Function> functionMap = funcMapByAnalysisId.get(iterator.next());
			if(functionMap == null || functionMap.size() == 0)
			{
				diffFunctionMap.putAll(sameFunctionMap);
				sameFunctionMap.clear();
			}
			else
			{
				if(sameFunctionMap == null || sameFunctionMap.size() == 0)
				{
					sameFunctionMap.putAll(functionMap);
				}
				for (Integer functionId : sameFunctionMap.keySet()) {
					if(!functionMap.containsKey(functionId))
					{
						removeFunctions.add(functionId);
						//if the diffFunctionMap don't contain the function,put the function to diffFunctionMap
						if(!diffFunctionMap.containsKey(functionId))
							diffFunctionMap.put(functionId, sameFunctionMap.get(functionId));
					}
					else
					{
						if(diffFunctionMap.containsKey(functionId))
							diffFunctionMap.remove(functionId);
					}
				}
				for (Integer functionId : functionMap.keySet()) {
					if(!sameFunctionMap.containsKey(functionId))
						diffFunctionMap.put(functionId, functionMap.get(functionId));
				}
				for (Integer functionId : removeFunctions) {
					sameFunctionMap.remove(functionId);
				}
				
			}
		}
		
		Map<Integer,Service> sameServiceMap = null;
		Map<Integer,Service> diffServiceMap = null;
		Iterator<Integer> servIterator = servMapByAnalysisId.keySet().iterator();
		if(servIterator.hasNext())
		{
			int analysisId = servIterator.next();
			sameServiceMap = new HashMap<Integer, Service>(servMapByAnalysisId.get(analysisId));
			diffServiceMap = new HashMap<Integer, Service>();
		}
		while(servIterator.hasNext())
		{
			List<Integer> removeServices = new ArrayList<Integer>();
			Map<Integer,Service> serviceMap = servMapByAnalysisId.get(servIterator.next());
			if(serviceMap == null || serviceMap.size() == 0)
			{
				diffServiceMap.putAll(sameServiceMap);
				sameServiceMap.clear();
			}
			else
			{
				if(sameServiceMap == null || sameServiceMap.size() == 0)
				{
					diffServiceMap.putAll(serviceMap);
				}
				for (Integer serviceId : sameServiceMap.keySet()) {
					if(!serviceMap.containsKey(serviceId))
					{
						removeServices.add(serviceId);
						if(!diffServiceMap.containsKey(serviceId))
						{
							diffServiceMap.put(serviceId, sameServiceMap.get(serviceId));
//							System.out.println("---" + Arrays.toString(diffServiceMap.keySet().toArray()));					
						}
					}
					else
					{
						if(diffServiceMap.containsKey(serviceId))
							diffServiceMap.remove(serviceId);
					}
				}
				for (Integer serviceId : serviceMap.keySet()) {
					if(!sameServiceMap.containsKey(serviceId))
						diffServiceMap.put(serviceId, serviceMap.get(serviceId));
				}
				for (Integer serviceId : removeServices) {
					sameServiceMap.remove(serviceId);
				}
			}
		}

		
		
			for (Integer serviceId : sameServiceMap.keySet()) {
				Map<String,List<List>> singleServicePointMap = new HashMap<String, List<List>>();
				pointJsonMap.put(serviceId+"", singleServicePointMap);
				
				for (Analysis analysis : analysisList) {
				String seriesName = sdfDate.format(analysis.getAnalysisTime());
				List<Point> pointList = pointService.getTPSRespTimeByAnalysisServiceId(analysis.getAnalysisId(), serviceId);
				pointList = SortUtil.sortPointByTime(pointList);
				pointMap.put(analysis.getAnalysisId(), pointList);
				
				List<String> time = new ArrayList<String>();
				List<Float> tps = new ArrayList<Float>();
				List<Float> responsetime = new ArrayList<Float>();
				List<Long> timestamp = new ArrayList<Long>();
				List<String> seriesNameList = new ArrayList<String>();
				List<List> pointJsonList = new ArrayList<List>();
				long startTime = pointList.get(0).getPointTime().getTime();
				for(Point point : pointList){
					seriesNameList.add(seriesName);
					time.add(sdf.format(point.getPointTime()) ); //get time 
					tps.add(point.getTps());//get tps
					responsetime.add(point.getRespTime()/1000000);//get responsetime
					timestamp.add(point.getPointTime().getTime()- startTime);
				}
				pointJsonList.add(0, time);
				pointJsonList.add(1, tps);
				pointJsonList.add(2, responsetime);
				pointJsonList.add(3, timestamp);
				pointJsonList.add(4,seriesNameList);
				singleServicePointMap.put(analysis.getAnalysisId() + "", pointJsonList);
			}
		}
			
		float ratio = 0.1f;
		
		Map<Integer,List<ServiceFunction>> functionStatisFilterMap = functionStatisInIDFService.getFuncStatisMapByRatio(selectIdList.get(0), ratio, sameServiceMap.keySet());
		Map<Integer,Map<Integer,List<ServiceFunction>>> hotFunctionListByAnalysis = new HashMap<Integer,Map<Integer,List<ServiceFunction>>>();
		hotFunctionListByAnalysis.put(selectIdList.get(0),functionStatisFilterMap);
		for (int i = 1; i < selectIdList.size(); i++) {
			Map<Integer,List<ServiceFunction>> map = new HashMap<Integer, List<ServiceFunction>>();
			for (Integer serviceId : functionStatisFilterMap.keySet()) {
				List<ServiceFunction> funcStatInServList = functionStatisFilterMap.get(serviceId);
				List<ServiceFunction> list = new ArrayList<ServiceFunction>();
				for (ServiceFunction funcStat : funcStatInServList) {
					ServiceFunction compareFuncStat = functionStatisInIDFService.getServiceFuncByFuncAndService(selectIdList.get(i),serviceId, funcStat.getFunctionId());
					list.add(compareFuncStat);
				}
				map.put(serviceId, list);
			}
			hotFunctionListByAnalysis.put(selectIdList.get(i), map);
		}
		
		session.setAttribute("functionStatsMap", functionStatsMap);
		session.setAttribute("serviceStatsMap", serviceStatsMap);
		
		
		session.setAttribute("sameFunctionMap", sameFunctionMap);
		session.setAttribute("sameServiceMap", sameServiceMap);
		model.addAttribute("diffFunctionMap", diffFunctionMap);
		model.addAttribute("diffServiceMap", diffServiceMap);
		session.setAttribute("hotFunction",hotFunctionListByAnalysis);
		
		session.setAttribute("selectIdList", selectIdList);
		session.setAttribute("analysisList",analysisList);
		model.addAttribute("pointJson", JSONArray.fromObject(pointJsonMap).toString());
		
		return "../view/historycompare.jsp";
	}
	/**
	 * Export the hot function summary table to CSV file
	 * @param response
	 * @param request
	 * @param model
	 * @throws IOException 
	 * @throws Throwable
	 */
	@RequestMapping("/exportComparedFunction")
    public void exportComparedFunctionToCSV(HttpServletResponse response,HttpServletRequest request,Model model,HttpSession session) throws IOException {
//		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		
//		List<FunctionStatistics> funcStatisList = functionStatisService.getFunctionStaByAnalysisId(analysisId);
//		Map<Integer,Function> funcMap = funcService.getFunctionListByFunctionStatistic(funcStatisList);
		
		@SuppressWarnings("unchecked")
		Map<Integer, Function> sameFunctionMap = (Map<Integer, Function>) session.getAttribute("sameFunctionMap");
		@SuppressWarnings("unchecked")
		Map<Integer, Map<Integer, FunctionStatistics>> functionStatsMap = (Map<Integer, Map<Integer, FunctionStatistics>>) session.getAttribute("functionStatsMap");
		@SuppressWarnings("unchecked")
		List<Analysis> analysisList = (List<Analysis>) session.getAttribute("analysisList");
		@SuppressWarnings("unchecked")
		List<Integer> selectIdList = (List<Integer>) session.getAttribute("selectIdList");
		
		
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"function_compare_summary.csv\"");
	    StringBuilder header = new StringBuilder();
	    
	    StringBuilder outputResult = new StringBuilder();
	    outputResult.append("Function Name");
	    String diff = "Diff";
	    String percentage = "%";
	    for (int i = 0; i < analysisList.size(); i++) {
	    	if(i == 0 ){
	    		header.append("," + analysisList.get(i).getAnalysisName());
	    	}
	    	else{
	    		header.append("," + analysisList.get(i).getAnalysisName());
	    		header.append("," + diff);
	    		header.append("," + percentage);
	    	}
		}
	    outputResult.append(header.toString());
	    outputResult.append(header.toString());
	    outputResult.append(header.toString()  + "\n");
	    for(Integer functionId : sameFunctionMap.keySet()){
	    	outputResult.append(sameFunctionMap.get(functionId).getFunctionName() + " - " + sameFunctionMap.get(functionId).getFunctionDescription());
	    	float baseTime = 0 ;
	    	float base90Time = 0 ;
	    	float baseScore = 0;
	    	for (int j = 0; j < selectIdList.size(); j++) {
				if(j == 0){
					baseScore = (float) (functionStatsMap.get(selectIdList.get(j)).get(functionId).getScore());
					outputResult.append("," + (float)baseScore);
				}
				else{
					float currentScore = (float) (functionStatsMap.get(selectIdList.get(j)).get(functionId).getScore());
					outputResult.append("," + currentScore);
					outputResult.append("," + (baseScore - currentScore));
					outputResult.append("," + (baseScore - currentScore)/baseScore*100);
				}
			}
	    	for (int j = 0; j < selectIdList.size(); j++) {
				if(j == 0){
					baseTime = (float) (functionStatsMap.get(selectIdList.get(j)).get(functionId).getAvgTime()/Math.pow(10, 6));
					outputResult.append("," + (float)baseTime);
				}
				else{
					float currentTime = (float) (functionStatsMap.get(selectIdList.get(j)).get(functionId).getAvgTime()/Math.pow(10, 6));
					outputResult.append("," + currentTime);
					outputResult.append("," + (baseTime - currentTime));
					outputResult.append("," + (baseTime - currentTime)/baseTime*100);
				}
			}
	    	for (int j = 0; j < selectIdList.size(); j++) {
				if(j == 0){
					base90Time = (float) (functionStatsMap.get(selectIdList.get(j)).get(functionId).getNintyTime()/Math.pow(10, 6));
					outputResult.append("," + base90Time);
				}
				else{
					float currentTime = (float) (functionStatsMap.get(selectIdList.get(j)).get(functionId).getNintyTime()/Math.pow(10, 6));
					outputResult.append("," + currentTime);
					outputResult.append("," + (base90Time - currentTime));
					outputResult.append("," + (base90Time - currentTime)/base90Time*100);
				}
			}
	    	outputResult.append("\n");
	    }
	    	OutputStream outputStream;
			try {
				outputStream = response.getOutputStream();
				outputStream.write(outputResult.toString().getBytes());
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw e;
			}
	    
    }
	
	/**
	 * export top n function in specify service to CSV file
	 * @param response
	 * @param request
	 * @param model
	 * @throws Throwable
	 */
	@RequestMapping("/exportComparedService")
    public void exportComparedServiceToCSV(HttpServletResponse response,HttpServletRequest request,Model model,HttpSession session) throws Throwable {
		
		@SuppressWarnings("unchecked")
		Map<Integer, Service> sameServiceMap = (Map<Integer, Service>) session.getAttribute("sameServiceMap");
		@SuppressWarnings("unchecked")
		Map<Integer, Map<Integer, ServiceStatistics>> serviceStatsMap = (Map<Integer, Map<Integer, ServiceStatistics>>) session.getAttribute("serviceStatsMap");
		@SuppressWarnings("unchecked")
		List<Analysis> analysisList = (List<Analysis>) session.getAttribute("analysisList");
		@SuppressWarnings("unchecked")
		List<Integer> selectIdList = (List<Integer>) session.getAttribute("selectIdList");
		@SuppressWarnings("unchecked")
		Map<Integer,Map<Integer,List<ServiceFunction>>> hotFunction = (Map<Integer, Map<Integer, List<ServiceFunction>>>) session.getAttribute("hotFunction");
		@SuppressWarnings("unchecked")
		Map<Integer, Function> sameFunctionMap = (Map<Integer, Function>) session.getAttribute("sameFunctionMap");
//		Map<Integer,Function> functionMap = funcService.getFunctionListByServiceFunction(serviceFunctionList);
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"service_compare_summary.csv\"");
	    
	    StringBuilder header = new StringBuilder();
	    
	    StringBuilder outputResult = new StringBuilder();
	    outputResult.append("Function Name");
	    String diff = "Diff";
	    String percentage = "%";
	    for (int i = 0; i < analysisList.size(); i++) {
	    	if(i == 0 ){
	    		header.append("," + analysisList.get(i).getAnalysisName());
	    	}
	    	else{
	    		header.append("," + analysisList.get(i).getAnalysisName());
	    		header.append("," + diff);
	    		header.append("," + percentage);
	    	}
		}
	    outputResult.append(header.toString());
	    outputResult.append(header.toString());
	    outputResult.append(header.toString());
	    outputResult.append(header.toString()  + "\n");
	    for(Integer serviceId : sameServiceMap.keySet()){
	    	outputResult.append(sameServiceMap.get(serviceId).getServiceName());
	    	float baseTime = 0 ;
	    	float base90Time = 0 ;
	    	float baseTPS = 0;
	    	for (int j = 0; j < selectIdList.size(); j++) {
	    		List<ServiceFunction> fsList = hotFunction.get(selectIdList.get(j)).get(serviceId);
	    		
				if(j == 0){
					outputResult.append(",");
					for (int k=0; k<fsList.size();k++) {
						Function f = sameFunctionMap.get(fsList.get(k).getFunctionId());
						outputResult.append(f.getFunctionName() + " - " + f.getFunctionDescription());
		    			outputResult.append("(" + fsList.get(k).getSelfRatio()*100 + ")");
		    			
					}
					/*for (ServiceFunction fs : fsList) {
		    			Function f = sameFunctionMap.get(fs.getFunctionId());
		    			outputResult.append(f.getFunctionName() + "- " + f.getFunctionDescription() + "(" + fs.getRatio()*100 + ")");
					}*/
				}
				else{
					outputResult.append(",");
					for (int k=0; k<fsList.size();k++) {
		    			outputResult.append("(" + fsList.get(k).getSelfRatio()*100 + ")");
		    			
					}
					outputResult.append(",");
					for (int k=0; k<fsList.size();k++) {
		    			outputResult.append("(" + ((hotFunction.get(selectIdList.get(0)).get(serviceId).get(k).getSelfRatio() - fsList.get(k).getRatio())*100) + ")");
		    			
					}
					outputResult.append(",");
					for (int k=0; k<fsList.size();k++) {
		    			outputResult.append("(" + (1- fsList.get(k).getSelfRatio()/hotFunction.get(selectIdList.get(0)).get(serviceId).get(k).getSelfRatio())*100 + ")");
		    			
					}
					
				}
			}
	    	for (int j = 0; j < selectIdList.size(); j++) {
				if(j == 0){
					baseTime = (float) (serviceStatsMap.get(selectIdList.get(j)).get(serviceId).getAvgTime()/Math.pow(10, 6));
					outputResult.append("," + (float)baseTime);
				}
				else{
					float currentTime = (float) (serviceStatsMap.get(selectIdList.get(j)).get(serviceId).getAvgTime()/Math.pow(10, 6));
					outputResult.append("," + currentTime);
					outputResult.append("," + (baseTime - currentTime));
					outputResult.append("," + (baseTime - currentTime)/baseTime*100);
				}
			}
	    	for (int j = 0; j < selectIdList.size(); j++) {
				if(j == 0){
					base90Time = (float) (serviceStatsMap.get(selectIdList.get(j)).get(serviceId).getNintyTime()/Math.pow(10, 6));
					outputResult.append("," + (float)base90Time);
				}
				else{
					float currentTime = (float) (serviceStatsMap.get(selectIdList.get(j)).get(serviceId).getNintyTime()/Math.pow(10, 6));
					outputResult.append("," + (float)currentTime);
					outputResult.append("," + (base90Time - currentTime));
					outputResult.append("," + (base90Time - currentTime)/base90Time*100);
				}
			}
	    	for (int j = 0; j < selectIdList.size(); j++) {
				if(j == 0){
					baseTPS = (float) (serviceStatsMap.get(selectIdList.get(j)).get(serviceId).getAvgTps()/Math.pow(10, 6));
					outputResult.append("," + (float)baseTPS);
				}
				else{
					float currentTime = (float) (serviceStatsMap.get(selectIdList.get(j)).get(serviceId).getAvgTps()/Math.pow(10, 6));
					outputResult.append("," + (float)currentTime);
					outputResult.append("," + (baseTPS - currentTime));
					outputResult.append("," + (baseTPS - currentTime)/baseTPS*100);
				}
			}
	    	outputResult.append("\n");
	    }
	    
	    try
	    {
	        OutputStream outputStream = response.getOutputStream();
	        outputStream.write(outputResult.toString().getBytes());
	        outputStream.flush();
	        outputStream.close();
	    }
	    catch(Exception e)
	    {
	    	throw e;
	    }
    }
	
	/**
	 * The tree structures with the same service in different analysis result.
	 *  
	 * @param request
	 * @param session
	 * @param model
	 * @return
	 */
	@RequestMapping("/getSameServStruc")
	public String getSameServStruc(HttpServletRequest request,HttpSession session,Model model){
		List<Analysis> analysisList = (List<Analysis>) session.getAttribute("analysisList");
		int serviceId = Integer.parseInt(request.getParameter("serviceId"));
//		List<JSONArray> jsonArrList = new ArrayList<JSONArray>();
		Map<Integer,Map<JsonNode,ServiceNodeStatistics>> jsonMapByAnaly = new HashMap<Integer,Map<JsonNode,ServiceNodeStatistics>>();
		Map<Integer,JsonNode> rootNodeByAnaly = new HashMap<Integer,JsonNode>();
		
		
		jsonService.saveAsjsonNodeByAnaly(jsonMapByAnaly, rootNodeByAnaly, analysisList, serviceId);
		
		int baseAnalysis = analysisList.get(0).getAnalysisId();
//		JsonNode baseRootNode = rootNodeByAnaly.get(baseAnalysis);
		Map<JsonNode, ServiceNodeStatistics> baseMap = jsonMapByAnaly.get(baseAnalysis);
		Map<JsonNode,Map<Integer,ServiceNodeStatistics>> nodeStatSameAsBase = new HashMap<JsonNode,Map<Integer,ServiceNodeStatistics>>();
		for (JsonNode node : baseMap.keySet()) {
			if(nodeStatSameAsBase.get(node) == null){
				Map<Integer,ServiceNodeStatistics> nodeStatByAnaly = new HashMap<Integer,ServiceNodeStatistics>();
				nodeStatSameAsBase.put(node, nodeStatByAnaly);
			}
			
			//loop the comparedMap to get the same node(nodeName, parent node name,parent deep)
			for (int i = 1; i < analysisList.size(); i++) {
				Map<JsonNode, ServiceNodeStatistics> compareMap = jsonMapByAnaly.get(analysisList.get(i).getAnalysisId());
				JsonNode sameNode = null;
				for (JsonNode compareNode : compareMap.keySet()) {
					if(compareNode.getNodeName().equals(node.getNodeName()) && compareNode.getDeep() == node.getDeep()){
						if(compareNode.getDeep() == 0 || (compareNode.getParentNode().getNodeName().equals(node.getParentNode().getNodeName()) && compareNode.getParentNode().getDeep() == node.getParentNode().getDeep())){
							sameNode = compareNode;
							break;
						}
					}
				}
				if(sameNode != null){
					ServiceNodeStatistics stat = compareMap.get(sameNode);
					//put the node statistics to nodeStatSameAsBase
					nodeStatSameAsBase.get(node).put(analysisList.get(i).getAnalysisId(), stat);
				}
				
			}
		}
		
		Map<String,Map<Analysis,JsonNode>> nodeByAnalyMap = new HashMap<String,Map<Analysis,JsonNode>>();
		/*for each the analysis get the different function*/
		for (int i = 0; i < analysisList.size(); i++) {
			int baseId = analysisList.get(i).getAnalysisId();
			Map<JsonNode, ServiceNodeStatistics> baseNodeMap = jsonMapByAnaly.get(baseId);
//			if(nodeByAnalyMap.get(baseId) == null){
//				Map<JsonNode,ServiceNodeStatistics> nodeStatMap = new HashMap<JsonNode,ServiceNodeStatistics>();
//				nodeByAnalyMap.put(analysisList.get(i), nodeStatMap);
//			}
			for (int j = 0; j < analysisList.size(); j++) {
				if(i != j){
					int compareId = analysisList.get(j).getAnalysisId();
					Map<JsonNode, ServiceNodeStatistics> comapreNodeMap = jsonMapByAnaly.get(compareId);
					for (JsonNode baseNode : baseNodeMap.keySet()) {
						JsonNode sameNode = null;
						for(JsonNode compareNode : comapreNodeMap.keySet()){
							if(compareNode.getNodeName().equals(baseNode.getNodeName()) && compareNode.getDeep() == baseNode.getDeep()){
								if(compareNode.getDeep() == 0 || (compareNode.getParentNode().getNodeName().equals(baseNode.getParentNode().getNodeName()) && compareNode.getParentNode().getDeep() == baseNode.getParentNode().getDeep())){
									sameNode = compareNode;
									break;
								}
							}
						}
						if(sameNode == null){
							if(jsonMapByAnaly.get(baseNode.getNodeName().intern()) == null) {
								Map<Analysis,JsonNode> analyNodeMap = new HashMap<Analysis,JsonNode>();
								analyNodeMap.put(analysisList.get(i), baseNode);
								nodeByAnalyMap.put(baseNode.getNodeName(), analyNodeMap);
							}
						}
					}
				}
			}
		}
		Service service = servService.getServiceById(serviceId);
		model.addAttribute("service",service);
		session.setAttribute("nodeByAnalyMap", nodeByAnalyMap);
		session.setAttribute("jsonMap", jsonMapByAnaly);
		session.setAttribute("rootNode", rootNodeByAnaly);
		session.setAttribute("nodeStatSameAsBase", nodeStatSameAsBase);
		model.addAttribute("analysisJson", JSONArray.fromObject(analysisList).toString());
		return "../view/serviceStatisCompare.jsp";
	}
	
	
	/**
	 * The method is to export the different functions that are in the same service and different analysis result.
	 * The export file content type is text/csv, and name is "diff.csv";
	 * 
	 * @param session
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/exportDiff")
	public void exportDiff(HttpSession session,HttpServletResponse response,HttpServletRequest request) throws Exception{
		/*Sting: function name*/
		Map<String, Map<Analysis, JsonNode>> nodeByAnalyMap = (Map<String, Map<Analysis, JsonNode>>) session.getAttribute("nodeByAnalyMap");
		List<Analysis> analysisList = (List<Analysis>) session.getAttribute("analysisList");
		int serviceId = Integer.parseInt(request.getParameter("serviceId"));
		Service service = servService.getServiceById(serviceId);
		Map<Integer, Map<JsonNode, ServiceNodeStatistics>> jsonMapByAnaly  = (Map<Integer, Map<JsonNode, ServiceNodeStatistics>>) session.getAttribute("jsonMap");
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"diff-" + service.getServiceName() +".csv\"");
	    StringBuilder resultOutput = new StringBuilder();
	    resultOutput.append("Deep,Function");
	    for (Analysis analysis : analysisList) {
	    	resultOutput.append("," + analysis.getAnalysisName());
	    }
	    resultOutput.append("\n");
	    
	    for (String functionName : nodeByAnalyMap.keySet()) {
	    	
	    	for (Analysis analysis : analysisList) {
	    		JsonNode node = nodeByAnalyMap.get(functionName).get(analysis);
	    		if(node != null)
	    		{
	    			resultOutput.append(node.getDeep());
	    			resultOutput.append("," + node.getNodeName());
	    			break;
	    		}
	    	}
	    	for (Analysis analysis : analysisList) {
	    		JsonNode node = nodeByAnalyMap.get(functionName).get(analysis);
	    		if(node != null)
	    		{
	    			resultOutput.append("," + jsonMapByAnaly.get(analysis.getAnalysisId()).get(node).getAvgTime()/1000000);
	    		}
	    		else{
	    			resultOutput.append(",--");
	    		}
	    	}
	    	resultOutput.append("\n");
		}
	    try
	    {
	        OutputStream outputStream = response.getOutputStream();
	        outputStream.write(resultOutput.toString().getBytes());
	        outputStream.flush();
	        outputStream.close();
	    }
	    catch(Exception e)
	    {
	    	throw e;
	    }
	}
	
	/**
	 * The method is to export the compared function statistics depends on the selected base line result.
	 * The result which need to be compared with the base line doesn't have the node, it will fill "--" in, otherwise fill the statistics result.
	 * Details can be found in page "serviceStatisComapre.jsp";
	 * The export file content type is text/csv, and name is "compared_tree.csv";
	 * @param session
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/exportComparedTree")
	public void export(HttpSession session,HttpServletResponse response,HttpServletRequest request) throws Exception{
		Map<Integer, Map<JsonNode, ServiceNodeStatistics>> jsonMapByAnaly  = (Map<Integer, Map<JsonNode, ServiceNodeStatistics>>) session.getAttribute("jsonMap");
		Map<Integer, JsonNode> rootNodeByAnaly = (Map<Integer, JsonNode>) session.getAttribute("rootNode");
		List<Analysis> analysisList = (List<Analysis>) session.getAttribute("analysisList");
		int serviceId = Integer.parseInt(request.getParameter("serviceId"));
		Service service = servService.getServiceById(serviceId);
		Map<JsonNode, Map<Integer, ServiceNodeStatistics>> nodeStatSameAsBase = (Map<JsonNode, Map<Integer, ServiceNodeStatistics>>) session.getAttribute("nodeStatSameAsBase");
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"" + service.getServiceName() + ".csv\"");
	    
	    StringBuilder resultOutput = new StringBuilder();
	    resultOutput.append("deep,function");
	    resultOutput.append(","+analysisList.get(0).getAnalysisName());
	    for (int i = 1; i <analysisList.size(); i++) {
	    	resultOutput.append("," + analysisList.get(i).getAnalysisName());
	    	resultOutput.append(",diff,%");
	    }
	    resultOutput.append("\n");
	    int baseAnalyId = analysisList.get(0).getAnalysisId();
	    JsonNode baseRootNode = rootNodeByAnaly.get(baseAnalyId);
	    
	    combineExpOutput(baseRootNode, nodeStatSameAsBase, jsonMapByAnaly, analysisList, resultOutput);
	    
	    
		/*for (Analysis analysis : analysisList) {
			resultOutput.append(analysis.getAnalysisName() + "\n");
			resultOutput.append("deep,function,AVG time(ms),count,total Time(ms)" + "\n");
			JsonNode rootNode = rootNodeByAnaly.get(analysis.getAnalysisId());
			Map<JsonNode, ServiceNodeStatistics> map = jsonMapByAnaly.get(analysis.getAnalysisId());
			combineExpOutput(rootNode, map, resultOutput);
		}
		*/
		 try
		    {
		        OutputStream outputStream = response.getOutputStream();
		        outputStream.write(resultOutput.toString().getBytes());
		        outputStream.flush();
		        outputStream.close();
		    }
		    catch(Exception e)
		    {
		    	throw e;
		    }
	}
	
	private void combineExpOutput(JsonNode parent,Map<JsonNode, Map<Integer, ServiceNodeStatistics>> nodeStatSameAsBase,Map<Integer, Map<JsonNode, ServiceNodeStatistics>> jsonMapByAnaly,List<Analysis> analysisList,StringBuilder resultOutput){
		float baseAvgTime = jsonMapByAnaly.get(analysisList.get(0).getAnalysisId()).get(parent).getAvgTime()/1000000;
		for (int i = 0; i < parent.getDeep(); i++) {
			resultOutput.append("\t");
		}
		resultOutput.append(parent.getDeep() + "," + parent.getNodeName());
		resultOutput.append("," + baseAvgTime);
		for (int i = 1; i < analysisList.size(); i++) {
			int id = analysisList.get(i).getAnalysisId();
			ServiceNodeStatistics stat = nodeStatSameAsBase.get(parent).get(id);
			if(stat != null){
				float avgTime = stat.getAvgTime()/1000000;
				resultOutput.append("," + avgTime);
				resultOutput.append("," + (baseAvgTime - avgTime));
				resultOutput.append("," + ((1 - avgTime/baseAvgTime) * 100 ) );
			}else{
				resultOutput.append(",--,--,--");
			}
		}
		resultOutput.append("\n");
		if(parent.getNodeChildren() != null && parent.getNodeChildren().size() != 0){
			for (JsonNode child : parent.getNodeChildren()) {
				combineExpOutput(child,nodeStatSameAsBase,jsonMapByAnaly,analysisList,resultOutput);
				
			}
		}
		/*int deep = 0;
		int length = parent.getNodeLevel().split("\\.").length;
		if("0".equals(parent.getNodeLevel())){
			deep = 0;
		}
		else
			deep = length;*/
		/*resultOutput.append(parent.getDeep() + "," + parent.getNodeName() + "," + map.get(parent).getAvgTime()/1000000 + "," + map.get(parent).getCount() + "," + map.get(parent).getTotalTime()/1000000 + "\n");
		if(parent.getNodeChildren() != null && parent.getNodeChildren().size() != 0){
			for (JsonNode child :  parent.getNodeChildren()) {
				combineExpOutput(child, map, resultOutput);
			}
		}*/
		
	}
	
	private int getDeep(String nodeLevel){
		int deep = 0;
		int length = nodeLevel.split("\\.").length;
		if("0".equals(nodeLevel)){
			deep = 0;
		}
		else
			deep = length;
		return deep;
	}
//	public static void main(String[] args) {
//		System.out.println("1".split("\\.").length);
//	}
}

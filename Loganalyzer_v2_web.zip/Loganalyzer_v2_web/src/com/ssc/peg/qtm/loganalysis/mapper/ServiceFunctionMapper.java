package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface ServiceFunctionMapper <T> extends SqlMapper{
	public void addServiceFunction(T entity);
	public T getServiceFuncById(int id);
	public List<T> getServiceFuncByFunction(int functionId);
	public List<T> getServiceFuncByService(int serviceId);
	public T getServiceFuncByFuncAndService(@Param("analysisId")int analysisId,@Param("serviceId")int serviceId,@Param("functionId")int functionId);
	public void addServiceFunctionList(List<T> list);
	public List<T> getServiceFuncByFunctionAnalysisId(@Param("analysisId")int analysisId,@Param("functionId")int functionId);
	public List<T> gettopNfunctioninservice(@Param("analysisId")int analysisId,@Param("serviceId")int serviceId,@Param("N")int N);
	public List<T> getFunctionStatisticBiggerThan(@Param("analysisId")int analysisId, @Param("serviceId")int serviceId,@Param("ratio")float ratio);
}

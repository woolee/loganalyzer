package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

public interface AnalysisMapper<T> extends SqlMapper {
	public void addAnalysis(T entity);
	public T getAnalysisById(int id);
	public T getAnalysisByUUID(String uuid);
	public List<T> getAnalysis();
	public void deleteAnalysis(int analysisId);
}

package com.ssc.peg.qtm.loganalysis.concurrent.db2;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;

import com.ssc.peg.qtm.loganalysis.bean.QueueObject;
import com.ssc.peg.qtm.loganalysis.bean.TimePicker;



public class SqlQueueProcessorManager implements Runnable{
	
	BlockingQueue inQueue = null;
	private int processorNumber = 0;
	private AtomicBoolean processorFinishFlag =  new AtomicBoolean();
//	private BlockingQueue<Runnable> taskQueue = new ArrayBlockingQueue<Runnable>(204800);
	private BlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<Runnable>();
	private String uuid;
	private int topN = 10;
	private TimePicker timePicker;
	private AtomicInteger atomicInt = new AtomicInteger(0);
	Logger logger = Logger.getLogger(this.getClass());
	public SqlQueueProcessorManager(BlockingQueue inQueue,int processorNumber, AtomicBoolean processorFinishFlag,String uuid,int topN) {
        this.inQueue = inQueue;
        this.processorNumber = processorNumber;
        this.processorFinishFlag = processorFinishFlag;
        this.topN = topN;
        this.uuid = uuid;
    }

	public SqlQueueProcessorManager(BlockingQueue inQueue,int processorNumber, AtomicBoolean processorFinishFlag,String uuid,TimePicker timePicker) {
        this.inQueue = inQueue;
        this.processorNumber = processorNumber;
        this.processorFinishFlag = processorFinishFlag;
        this.uuid = uuid;
        this.timePicker = timePicker;
    }
	@Override
	public void run() {
		
//		logger.setLevel(Level.INFO);
		
		ThreadPoolExecutor executor = new ThreadPoolExecutor(
				processorNumber,
				processorNumber,
				5, 
				TimeUnit.SECONDS,
				taskQueue){
			@Override 
			protected void terminated() { 
				processorFinishFlag.set(true);
				logger.info("Processor terminal");
		     } 
			
		};
		String currentUUID = "";
		StringBuilder builder = new StringBuilder(204800);
		while(true){
//			System.out.println("taskQueue.size()=" + taskQueue.size());
			String inQueueString = "";
			QueueObject obj ;
				try {
//				inQueueString = (String)inQueue.poll(5, TimeUnit.SECONDS);
//				if(inQueueString == null){
//					System.out.println("process thread shut down ");
//					break;
//				}
//				String requestID = inQueueString.substring(0,inQueueString.indexOf(","));
////				System.out.println(requestID);
//				if(currentUUID.equals("")){
//					currentUUID = requestID;
//				}
//				else if(!currentUUID.equals(requestID)){
////					System.out.println("-----------------");
//					executor.execute(new ResultSelector(builder.toString(),uuid,timePicker,atomicInt));
//					builder.setLength(0);
//					currentUUID = requestID;
//				}
////				System.out.println(inQueueString);
//				builder.append(inQueueString);
//				
					obj = (QueueObject)inQueue.poll(30, TimeUnit.SECONDS);
					if(obj == null){
						System.out.println("process thread shut down ");
						break;
					}
					logger.info("Consume one object, current size="+inQueue.size());
					if(currentUUID.equals("")){
						currentUUID = obj.getUuid();
					}
					else if(!currentUUID.equals(obj.getUuid())){
						executor.execute(new ResultSelector(builder.toString(),uuid,timePicker,atomicInt));
						builder.setLength(0);
						currentUUID = obj.getUuid();
					}
					builder.append(obj.getLine());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		executor.shutdown();
		
		
	}//end of run function
	
	


}

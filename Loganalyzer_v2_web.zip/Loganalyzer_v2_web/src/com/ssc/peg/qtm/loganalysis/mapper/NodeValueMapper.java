package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

public interface NodeValueMapper<T> extends SqlMapper{
	public void addNodeValue(T entity);
	public T getNodeValueByValueId(int valueId);
	public T getNodeValueByNodeUUID(String uuid);
	public void addNodeValueList(List<T> list);
}

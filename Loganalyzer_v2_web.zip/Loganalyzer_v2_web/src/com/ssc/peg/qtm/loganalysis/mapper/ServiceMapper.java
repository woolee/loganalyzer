package com.ssc.peg.qtm.loganalysis.mapper;


public interface ServiceMapper<T> extends SqlMapper {
	public void addService(T entity);
	public T getServiceById(int id);
	public T getServiceByName(String name);
}

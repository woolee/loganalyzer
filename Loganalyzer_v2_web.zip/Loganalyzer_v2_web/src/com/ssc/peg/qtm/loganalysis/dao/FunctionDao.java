package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface FunctionDao<T> {
	public boolean addFunction(T entity);
	public T getFunctionById(int id);
	public T getFunctionByNameAndDescription(T entity);
	public boolean addFunctionList(List<T> list);
	public List<T> getFunctionListByNameAndDescription(List<T> list);
	public List<T> getFunctionList();
}


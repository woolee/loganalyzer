package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface FunctionStatisticsDao<T> {
	public boolean addFunctionStatistics(T entity);
	public T getFunctionStaById(int id);
	public T getFunctionStaByFunctionId(int functionId);
	public boolean addFunctionStatisticsList(List<T> list);
	public List<T> getFunctionStaByAnalysisId(int analysisId);
}

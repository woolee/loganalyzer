package com.ssc.peg.qtm.loganalysis.bean;

public class ServiceNodeStatistics {
	private long maxTime;
	private long minTime;
	private float avgTime;
	private int count;
	private float percentageAbl;
	private float percentageRel;
	private float selfAvgTime;
	private float selfPercentageAbl;
	private float totalTime;
	private float totalSelfTime;
	public long getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(long maxTime) {
		this.maxTime = maxTime;
	}
	public long getMinTime() {
		return minTime;
	}
	public void setMinTime(long minTime) {
		this.minTime = minTime;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getPercentageAbl() {
		return percentageAbl;
	}
	public void setPercentageAbl(float percentageAbl) {
		this.percentageAbl = percentageAbl;
	}
	public float getPercentageRel() {
		return percentageRel;
	}
	public void setPercentageRel(float percentageRel) {
		this.percentageRel = percentageRel;
	}
	
	public float getSelfAvgTime() {
		return selfAvgTime;
	}
	public void setSelfAvgTime(float selfAvgTime) {
		this.selfAvgTime = selfAvgTime;
	}
	public float getSelfPercentageAbl() {
		return selfPercentageAbl;
	}
	public void setSelfPercentageAbl(float selfPercentageAbl) {
		this.selfPercentageAbl = selfPercentageAbl;
	}
	public float getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(float totalTime) {
		this.totalTime = totalTime;
	}
	public float getTotalSelfTime() {
		return totalSelfTime;
	}
	public void setTotalSelfTime(float totalSelfTime) {
		this.totalSelfTime = totalSelfTime;
	}
	@Override
	public String toString() {
		return "NodeStatistics [maxTime=" + maxTime + ", minTime=" + minTime + ",avgTime=" + avgTime + ", count="
				+ count + ", percentageAbl=" + percentageAbl + ", percentageRel="
				+ percentageRel + ", selfPercentageAbl="
						+ selfPercentageAbl + "]";
	}
}

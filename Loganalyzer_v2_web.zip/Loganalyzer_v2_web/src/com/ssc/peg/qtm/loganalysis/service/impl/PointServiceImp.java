package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.ssc.peg.qtm.loganalysis.dao.PointDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.service.PointService;

@Service
public class PointServiceImp<T extends Point> implements PointService<T>{

	@Inject
	private PointDao<T> dao;

	@Override
	public List<T> getTPSRespTimeByAnalysisServiceId(int analysisId,
			int serviceId) {
		// TODO Auto-generated method stub
		return dao.getTPSRespTimeByAnalysisServiceId(analysisId, serviceId);
	}



}

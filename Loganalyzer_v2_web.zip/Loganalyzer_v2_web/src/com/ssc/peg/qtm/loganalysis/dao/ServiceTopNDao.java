package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;


public interface ServiceTopNDao<T>{
	public boolean addServiceTopN(T entity);
	public boolean addServiceTopNList(List<T> list);
	public List<T> getServiceTopNByAnalysisId(int analysisId);
	public List<T> getTopNByAnalyIdAndServiceId(int analysisId, int serviceId) ;
}

package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;
import java.util.Map;

import com.ssc.peg.qtm.loganalysis.bean.JsonNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;

public interface JsonService {
	public List<List> getFunctionRatioInService(int functionId, int analysisId);
	public List<List> getFuncRatioTopN(int functionId,int analysisId,String serviceName);
	public List<List> getFuncTimeTopN(int functionId,int analysisId,String serviceName);
	public void saveAsjsonNodeByAnaly(Map<Integer,Map<JsonNode,ServiceNodeStatistics>> jsonMapByAnaly,Map<Integer,JsonNode> rootNodeByAnaly,List<Analysis> analysisList,int serviceId);
}

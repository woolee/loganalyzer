package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.ServiceFunctionDao;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.ServiceFunctionMapper;
@Repository
public class ServiceFunctionDaoImp<T extends ServiceFunction> implements ServiceFunctionDao<T> {

	@Inject
	private ServiceFunctionMapper<T> mapper;
	
	@Override
	public boolean addServiceFunction(T entity) {
		boolean flag = false;
		try
		{
			mapper.addServiceFunction(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add ServiceFunction to database",e);
		}
		return flag;
	}

	@Override
	public T getServiceFuncById(int id) {
		return mapper.getServiceFuncById(id);
	}

	@Override
	public List<T> getServiceFuncByFunction(int functionId) {
		return mapper.getServiceFuncByFunction(functionId);
	}

	@Override
	public List<T> getServiceFuncByService(int serviceId) {
		return mapper.getServiceFuncByService(serviceId);
	}

	@Override
	public T getServiceFuncByFuncAndService(int analysisId,int serviceId, int functionId) {
		return mapper.getServiceFuncByFuncAndService(analysisId,serviceId,functionId);
	}

	@Override
	public boolean addServiceFunctionList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addServiceFunctionList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add ServiceFunction list to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getServiceFuncByFunctionAnalysisId(int analysisId,
			int functionId) {
		// TODO Auto-generated method stub
		return mapper.getServiceFuncByFunctionAnalysisId(analysisId, functionId);
	}

	@Override
	public List<T> gettopNfunctioninservice(int analysisId,  
			int serviceId, int N) {
		// TODO Auto-generated method stub
		return mapper.gettopNfunctioninservice(analysisId,  serviceId, N);
	}

	@Override
	public List<T> getFunctionStatisticBiggerThan(int analysisId, int serviceId,
			float ratio) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStatisticBiggerThan(analysisId, serviceId, ratio);
	}

}

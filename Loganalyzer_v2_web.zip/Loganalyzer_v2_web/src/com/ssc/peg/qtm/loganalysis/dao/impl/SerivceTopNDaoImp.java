package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.ServiceTopNDao;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.ServiceTopNMapper;

@Repository
public class SerivceTopNDaoImp<T extends ServiceTopN> implements ServiceTopNDao<T> {

	@Inject
	private ServiceTopNMapper<T> mapper;


	@Override
	public boolean addServiceTopN(T entity) {
		boolean flag = false;
		try {
			mapper.addServiceTopN(entity);
			flag = true;
		} catch (Exception e) {
			flag = false;
			throw new DaoException(
					"Exception while add ServiceTopN to database", e);
		}
		return flag;
		
	}


	@Override
	public boolean addServiceTopNList(List<T> list) {
		boolean flag = false;
		try {
			mapper.addServiceTopNList(list);
			flag = true;
		} catch (Exception e) {
			flag = false;
			throw new DaoException(
					"Exception while add ServiceTopN list to database", e);
		}
		return flag;
	}


	@Override
	public List<T> getServiceTopNByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getServiceTopNByAnalysisId(analysisId);
	}


	@Override
	public List<T> getTopNByAnalyIdAndServiceId(int analysisId, int servieId) {
		// TODO Auto-generated method stub
		return mapper.getTopNByAnalyIdAndServiceId(analysisId, servieId);
	}

}

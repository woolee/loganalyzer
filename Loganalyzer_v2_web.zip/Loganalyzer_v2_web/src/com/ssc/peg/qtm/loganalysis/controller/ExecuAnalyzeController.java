package com.ssc.peg.qtm.loganalysis.controller;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.peg.qtm.loganalysis.analysis.IDFData;
import com.ssc.peg.qtm.loganalysis.analysis.LogAnalyzer;
import com.ssc.peg.qtm.loganalysis.bean.CommonMap;
import com.ssc.peg.qtm.loganalysis.bean.TPSResponseTime;
import com.ssc.peg.qtm.loganalysis.bean.TimePicker;
import com.ssc.peg.qtm.loganalysis.concurrent.ConcurrentMapManager;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;
import com.ssc.peg.qtm.loganalysis.concurrent.LogReader;
import com.ssc.peg.qtm.loganalysis.concurrent.ProcessorManager;
import com.ssc.peg.qtm.loganalysis.concurrent.db2.RequestReader;
import com.ssc.peg.qtm.loganalysis.concurrent.db2.SqlQueueProcessorManager;
import com.ssc.peg.qtm.loganalysis.db.AFCConnectionFactory;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;
import com.ssc.peg.qtm.loganalysis.service.AnalysisService;
import com.ssc.peg.qtm.loganalysis.service.ResultStoreService;
import com.ssc.peg.qtm.loganalysis.util.FileZip;
import com.ssc.peg.qtm.loganalysis.constants.Constants;

@Controller
@RequestMapping("/log")
public class ExecuAnalyzeController {

	private Logger logger = Logger.getLogger(ExecuAnalyzeController.class);
	@Inject
	private AnalysisService<Analysis> analysisService;
	
	@Inject
	private ResultStoreService storeService;
	
	/**
	 * The method upload log file and analyze logs, store results to database 
	 * @param response
	 * @param request
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/analyzeFromLog")
	public String showidfclasscification(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) throws Exception {
		/*if(session.getAttribute("uuid") != null)
			return "../view/error.jsp";*/
		String from = request.getParameter("from");
		String to = request.getParameter("to");
		String renameTo = request.getParameter("renameto");
		
		System.out.println("......................");
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.AFC_LOG_DATA_FORMAT);
		long dateFrom = 0;
		long dateTo = 0;
		if(from != null && !from.isEmpty())
			dateFrom = dateFormat.parse(from.trim()).getTime();
		if(to != null && !to.isEmpty())
			dateTo = dateFormat.parse(to.trim()).getTime();
	
		TimePicker timePicker = new TimePicker(dateFrom, dateTo);
		
		String uuid = UUID.randomUUID().toString();
		BlockingQueue queue = DataMapSelector.selectBlockingQueue(uuid);

		
		CommonMap commMap = DataMapSelector.selectCommonMap(uuid);
		ConcurrentMapManager manager = DataMapSelector.selectConcurrentMap(uuid);
		
		
	
		String logFilePath = (String)session.getAttribute("logPath");
		String saveFolder = null;
		if(logFilePath.endsWith(".zip"))
		{
			saveFolder = session.getServletContext().getRealPath("/") + "log";
			logFilePath = FileZip.unzip(logFilePath, saveFolder);
		}
//		String logFilePath = "C:/large_log/AFC_l4j_Performance.log.2014-08-27-06.log";
//		String logFilePath = "C:/large_log/afcfgcaller_AFC_l4j_Performance.log";
		File file = new File(logFilePath);
		
		if(renameTo == null || "".equals(renameTo))
			renameTo = file.getName();
			
		LogReader logReader = new LogReader(queue, file);
		new Thread(logReader).start();
		
		AtomicBoolean processorFinishFlag = new AtomicBoolean(false);
		AtomicBoolean analyzerFinishFlag = new AtomicBoolean(false);
		ProcessorManager pm = new ProcessorManager(queue, 10, processorFinishFlag,uuid,timePicker);
		new Thread(pm).start();
				
		LogAnalyzer la = new LogAnalyzer(processorFinishFlag,analyzerFinishFlag, commMap.getIdfMap(),commMap.getIdfMergeTreeMap(),commMap.getIdgMergeNodeStatisticsMap(),commMap.getStatisMap(),commMap.getFunctionScoreMap(),uuid);
		new Thread(la).start();

		while (true) {
			if (analyzerFinishFlag.get()) {
				break;
			}
		}
		
		/*
		 * save analysis 
		 * get analysis
		 */
		long currentTime = System.currentTimeMillis();
		BlockingQueue<FunctionStatisticsTree> funcStatidQueue = new ArrayBlockingQueue<FunctionStatisticsTree>(204800);
		Analysis analysis = storeService.saveToAll(renameTo,uuid,funcStatidQueue);
		model.addAttribute("IDFDetails", commMap.getIdfMap());//current request
		session.setAttribute("uuid", uuid);
		session.setAttribute("IDFDetails", commMap.getIdfMap());//the pie request
		session.setAttribute("HotFunction", commMap.getFunctionScoreMap());
    
		commMap = null;
		manager.setFunctionRatioTopN(null);
		manager.setTopNMap(null);
		manager.setFunctionTimeTopN(null);
		manager.setIdfTreeMap(null);
		manager.setIdfTreeMap(null);
		manager.setInvertedIdfTreeMap(null);
		
		return "redirect:../history/getSummaryInfo.do?analysisId=" + analysis.getAnalysisId();
	}
	
	/**
	 * The method get data from DB2 database, analyze data and store results to our MYSQL database 
	 * @param response
	 * @param request
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/analyzeFromDB")
	public String showidfclasscification2(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) throws Exception {
		/*if(session.getAttribute("uuid") != null)
			return "../view/error.jsp";*/
		logger.info("Submit analysis request");
		String from = request.getParameter("datefrom");
		String to = request.getParameter("dateto");
		String renameTo = request.getParameter("renameto");
		
		String server = request.getParameter("server");
		String port = request.getParameter("port");
		String db = request.getParameter("db");
		String user = request.getParameter("user");
		String password = request.getParameter("pwd");
		String context = request.getParameter("context");
		AFCConnectionFactory.setServer(server.trim());
		AFCConnectionFactory.setPort(port.trim());
		AFCConnectionFactory.setDb(db.trim());
		AFCConnectionFactory.setUser(user.trim());
		AFCConnectionFactory.setPassword(password.trim());
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.AFC_LOG_DATA_FORMAT);
		long dateFrom = 0;
		long dateTo = 0;
		if(from != null && !from.isEmpty())
			dateFrom = dateFormat.parse(from.trim()).getTime();
		if(to != null && !to.isEmpty())
			dateTo = dateFormat.parse(to.trim()).getTime();
		from = dateFormat.format(dateFrom);
		to = dateFormat.format(dateTo);
		
		final String PLATFORM_CD = "CLOUD";
//		final String ENVIRONMENT_CD = "UAT";
//		final String ENVIRONMENT_CD = "DEV";
//		final String CONTEXT_NM = "afcfgmq";
		if(from != null && !from.isEmpty() && to != null && !to.isEmpty() ){
			
			String sql = "SELECT ADI.UUID,ADI.USER_ID," +                       
					"ADI.ENTITY_NM,ADI.CRITERIA_CD,ALDID.COMPONENT_NM,"+                    
					"ALDID.TASK_NM,ALDID.START_TS,"+                        
					"ALDID.END_TS,ALDID.TIME_SPENT_NUM,ALDID.CALL_LVL_NUM,ALDID.CALL_NUM_TXT,"+
					"ADI.CREATED_BY_ID "+
					"FROM U1K.AFC_DIAGNOSTICS_INFO ADI "+          
					"LEFT JOIN "+                              
					"U1K.AFC_LOG_DIAGNOSTICS_INFO_DETAILS ALDID "+ 
					"ON ADI.UUID = ALDID.UUID "+
					"WHERE ADI.PLATFORM_CD = '"+PLATFORM_CD + "' "+            
					"AND ADI.CONTEXT_NM = '"+context+"' AND ALDID.START_TS >= '"+from+"' AND ALDID.END_TS <= '"+to+"' "+
					"ORDER BY ADI.UUID, ALDID.CALL_NUM_TXT";
			
			
			//get the all request UUID form DB2
			Connection conn = AFCConnectionFactory.getConnection();
			PreparedStatement ptst = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ptst.setFetchSize(500);
//			ptst.setFetchDirection(ResultSet.FETCH_REVERSE);  
			logger.info(sql);
			
			ResultSet rs = ptst.executeQuery();
			
			rs.last();
		    int size = rs.getRow();
		    rs.beforeFirst();
		    if(size == 0){
		    	logger.error("SQL return size is 0!");
		    	return "../view/dberror.html";
		    }
		    
			String uuid = UUID.randomUUID().toString();
			BlockingQueue queue = DataMapSelector.selectBlockingQueue(uuid);
			
			//insert all the UUID into blockingqueue
			RequestReader reader = new RequestReader(queue, rs);
			Thread readThread = new Thread(reader);
			readThread.setName("Thread-Get Requests UUID");
			readThread.start();
			
			
			TimePicker timePicker = new TimePicker(dateFrom, dateTo);
			AtomicBoolean processorFinishFlag = new AtomicBoolean(false);
			AtomicBoolean analyzerFinishFlag = new AtomicBoolean(false);
			SqlQueueProcessorManager pm = new SqlQueueProcessorManager(queue, 20, processorFinishFlag,uuid,timePicker);
			new Thread(pm).start();
			
			CommonMap commMap = DataMapSelector.selectCommonMap(uuid);
			ConcurrentMapManager manager = DataMapSelector.selectConcurrentMap(uuid);
			
			
			
			LogAnalyzer la = new LogAnalyzer(processorFinishFlag,analyzerFinishFlag, commMap.getIdfMap(),commMap.getIdfMergeTreeMap(),commMap.getIdgMergeNodeStatisticsMap(),commMap.getStatisMap(),commMap.getFunctionScoreMap(),uuid);
			new Thread(la).start();
			
			while (true) {
				if (analyzerFinishFlag.get()) {
					break;
				}
			}
			
			
			 /** save analysis 
			 * get analysis*/
			 
			long currentTime = System.currentTimeMillis();
			BlockingQueue<FunctionStatisticsTree> funcStatidQueue = new ArrayBlockingQueue<FunctionStatisticsTree>(204800);
			Analysis analysis = storeService.saveToAll(renameTo,uuid,funcStatidQueue);
			model.addAttribute("IDFDetails", commMap.getIdfMap());//current request
			session.setAttribute("uuid", uuid);
			session.setAttribute("IDFDetails", commMap.getIdfMap());//the pie request
			session.setAttribute("HotFunction", commMap.getFunctionScoreMap());
			
			commMap = null;
			manager.setFunctionRatioTopN(null);
			manager.setTopNMap(null);
			manager.setFunctionTimeTopN(null);
			manager.setIdfTreeMap(null);
			manager.setIdfTreeMap(null);
			manager.setInvertedIdfTreeMap(null);
			
			return "redirect:../history/getSummaryInfo.do?analysisId=" + analysis.getAnalysisId();
		}
		return "error.jsp";
	}
	
	/*@RequestMapping("/get_hotfunction")
	public String showhotfunction(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {
		Map<String,Double> functionscoreMap = (Map<String,Double>)session.getAttribute("HotFunction");
		return "../view/hotfunctionDetails.jsp";
	}*/
	
	/*
	@RequestMapping("/IDFcallpie")
	public void IDFchart(HttpServletResponse response, HttpServletRequest request,HttpSession session,Model model) throws IOException{
		
		Map<String, IDFData> idfMap = (Map<String, IDFData>)session.getAttribute("IDFDetails");
		List<String> strlist = new ArrayList<String>();
		for(Entry<String, IDFData> entry : idfMap.entrySet()){
			StringBuffer sb = new StringBuffer();
			sb.append("[\"");
			sb.append(entry.getKey());
			sb.append("\",");
			sb.append(entry.getValue().getCount());
			sb.append("]");
			strlist.add(sb.toString());
		}
//		System.out.println(JSONArray.fromObject(strlist).toString());
		response.getWriter().print(JSONArray.fromObject(strlist).toString());
	}*/
	
	/*@RequestMapping("/IDFspenttimepie")
	public void IDFchart2(HttpServletResponse response, HttpServletRequest request,HttpSession session,Model model) throws IOException{
		
		Map<String, IDFData> idfMap = (Map<String, IDFData>)session.getAttribute("IDFDetails");
		List<String> strlist = new ArrayList<String>();
		for(Entry<String, IDFData> entry : idfMap.entrySet()){
			StringBuffer sb = new StringBuffer();
			sb.append("[\"");
			sb.append(entry.getKey());
			sb.append("\",");
			sb.append(entry.getValue().getAvgTime());
			sb.append("]");
			strlist.add(sb.toString());
		}
//		System.out.println(JSONArray.fromObject(strlist).toString());
		response.getWriter().print(JSONArray.fromObject(strlist).toString());
	}*/

	/*@RequestMapping("/IDFtpsresponsetime")
	public void idftpsresponsetime(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model){
		
			String uuid = (String)session.getAttribute("uuid");
		//idf TPS ResponseTime
			List<String> time = new ArrayList<String>();
			List<String> idfnumber = new ArrayList<String>();
			List<Double> tps = new ArrayList<Double>();
			List<Double> responsetime = new ArrayList<Double>();
			
			
			List<List> idftpsresponsetime = new ArrayList<List>();//save time, idfnumber, tps, reqponsetime
			
			SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
			for(Entry<Long,Map<String,TPSResponseTime>> entry : DataMapSelector.selectCommonMap(uuid).getStatisMap().entrySet()){
				
				time.add(sdf.format(new Date(entry.getKey()))); //get time 
				
				
				
				Map<String,TPSResponseTime> idftpsresponse = new HashMap<String,TPSResponseTime>();
				idftpsresponse = entry.getValue();
				
				TPSResponseTime tpsresponse = idftpsresponse.get("0");//get total idf if idfnumber=="0"
				tps.add((double) tpsresponse.getTps());//get tps
				responsetime.add((double) (tpsresponse.getResponseTime()/1000000));//get responsetime
				
				
			}
			
			idftpsresponsetime.add(0, time);
			idftpsresponsetime.add(1, tps);
			idftpsresponsetime.add(2, responsetime);
			
			try {
				response.getWriter().print(JSONArray.fromObject(idftpsresponsetime).toString());
			} catch (IOException e) {
				
				System.out.println("Exception");
				e.printStackTrace();
			}
	}*/
}

package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;


public interface FuncRatioTopNMapper<T> extends SqlMapper {
	public void addFuncRatioTopN(T entity);
	public void addFuncRatioTopNList(List<T> entity);
	public List<T> getTopNByFunctionServiceId(@Param("functionId")int functionId, @Param("serviceId")int serviceId,@Param("analysisId")int analysisId);
}

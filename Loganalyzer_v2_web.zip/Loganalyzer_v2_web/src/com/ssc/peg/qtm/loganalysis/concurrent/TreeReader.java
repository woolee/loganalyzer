package com.ssc.peg.qtm.loganalysis.concurrent;

import static com.ssc.peg.qtm.loganalysis.constants.LogPattern.branchPattern;
import static com.ssc.peg.qtm.loganalysis.constants.LogPattern.idPattern;
import static com.ssc.peg.qtm.loganalysis.constants.LogPattern.idfPattern;
import static com.ssc.peg.qtm.loganalysis.constants.LogPattern.rootPattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ssc.peg.qtm.loganalysis.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeMapping;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TimePicker;
import com.ssc.peg.qtm.loganalysis.exception.LogFormatException;

public class TreeReader {
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
	private TimePicker timePicker;
	public TreeReader(TimePicker timePicker)
	{
		this.timePicker = timePicker;
	}
	public TreeReader(){};
	public ServiceRequestTree strToTree(String treeStr) throws LogFormatException, ParseException
	{
		if(!isIDFTree(treeStr))
			return null;
		ServiceNodeMapping mapping = null;
		//get the array of lines 
		String [] processArray = Pattern.compile("\n").split(treeStr);
		
		treeStr=null;
		
		Matcher rootMatcher = rootPattern.matcher(processArray[0]);
		StringBuilder functionSb = new StringBuilder();
		ServiceRequestTree tree = new ServiceRequestTree();
		//generate the root node and set parent node null
		if(rootMatcher.find())
		{
//			rootNodeValue = setRootNode(rootMatcher,functionSb,tree)
			if(!checkTime(rootMatcher))
				return null;
			setRootNode(rootMatcher,functionSb,tree);
			mapping = tree.getNodeMapping();
		}
		else
		{
			return null;
		}
		
		if(tree.getRootNode() == null)
			return null;
		generateBranchNode(processArray, mapping, tree, functionSb);
		
		if("XXXXXX".equals(tree.getEntityName()))
			return null;
		tree.setFunctionHashcode(functionSb.toString().hashCode());
		
		functionSb.setLength(0);
		functionSb=null;
		processArray = null;
		return tree;
	}
	
	private void generateBranchNode(String [] processArray,ServiceNodeMapping mapping,ServiceRequestTree tree,StringBuilder functionSb)
	{
		ServiceNode rootNode = tree.getRootNode();
		ServiceNodeValue rootNodeValue = mapping.getNodeMappingMap().get(rootNode);
		//generate child node ,set parent node and child node to parent 
		for (int i = 1; i < processArray.length; i++) {
			Matcher branchMatcher = branchPattern.matcher(processArray[i]);
					
			//if matches the branchPatten
			if(branchMatcher.find())
			{
				Matcher idMatcher = idPattern.matcher(processArray[i]);
				//get the process level and transform to array 
				String [] levelArr = (branchMatcher.group(1)+".").split("\\.");
				ServiceNode node = new ServiceNode();
				ServiceNodeValue nodeVaule = new ServiceNodeValue();
						
				//get parent level 
				int [] parentLevel = getParentLevel(levelArr);
						
						
//				Set<ServiceNode> nodekeys = mapping.getNodeMappingMap().keySet();
				if(idMatcher.find())
				{
//					System.out.println(processArray[i]);
//					System.out.println("id matches");
					//set the root node
					
					tree.setEntityName(idMatcher.group(5).intern());
					
					//change idf number to entity+criteria
//					tree.setIdfNumber(idMatcher.group(4).intern());
					if(idMatcher.group(6) == null || "null".equals(idMatcher.group(6)))
						tree.setCriteria(("[]").intern());
					else
						tree.setCriteria(("[" + idMatcher.group(6) + "]").intern());
					tree.setIdfNumber((idMatcher.group(5) + " " + tree.getCriteria()));
							
					nodeVaule.setLevel(idMatcher.group(1).intern());
					nodeVaule.setFunctionName(idMatcher.group(2).intern());
					nodeVaule.setFuncationDescription(idMatcher.group(3).intern());
					nodeVaule.setExecutionTime(Long.parseLong(idMatcher.group(7)));
					nodeVaule.setPercentageAbsolute(Float.parseFloat(idMatcher.group(7))/rootNodeValue.getExecutionTime());
					nodeVaule.setSelfExecutionTime(Long.parseLong(idMatcher.group(7)));
					functionSb.append(nodeVaule.getLevel()+nodeVaule.getFunctionName() + " - " + nodeVaule.getFuncationDescription() + "\n");			
					
					ServiceNode parentNode = getParentNode(parentLevel,rootNode);
//					node.setParentNode(parentNode);
//					for (Node nodeKey : nodekeys) {
//						NodeValue nodeValueMapping = mapping.getNodeMappingMap().get(nodeKey);
//						String tempLevel = nodeValueMapping.getLevel();
//						if(parentLevel.equals(tempLevel))
//						{
//							node.setParentNode(nodeKey);
//							break;
//						}
//					}
//							
//					Node parentNode = node.getParentNode();
					
					if(parentNode.getChildrenNode() == null)
					{
						List<ServiceNode> keyChildNode = new ArrayList<ServiceNode>();
						keyChildNode.add(node);
						parentNode.setChildrenNode(keyChildNode);
					}
					else
						parentNode.getChildrenNode().add(node);
					ServiceNodeValue parentNodeValue = mapping.getNodeMappingMap().get(parentNode);
					parentNodeValue.setSelfExecutionTime(parentNodeValue.getSelfExecutionTime() - nodeVaule.getExecutionTime());
					nodeVaule.setPercentageRelative(Float.parseFloat(idMatcher.group(7))/parentNodeValue.getExecutionTime());
					mapping.getNodeMappingMap().put(node, nodeVaule);
										
				}
				else{
					nodeVaule.setLevel(branchMatcher.group(1).intern());
					nodeVaule.setFunctionName(branchMatcher.group(2).intern());
					String decs = branchMatcher.group(3).intern();
					if(decs.contains("output row count"))
						decs = decs.split(",")[0];
					nodeVaule.setFuncationDescription(decs);
					nodeVaule.setExecutionTime(Long.parseLong(branchMatcher.group(4)));
					nodeVaule.setSelfExecutionTime(Long.parseLong(branchMatcher.group(4)));
					nodeVaule.setPercentageAbsolute(Float.parseFloat(branchMatcher.group(4))/rootNodeValue.getExecutionTime());
							
					functionSb.append(nodeVaule.getLevel()+nodeVaule.getFunctionName() + " - " + nodeVaule.getFuncationDescription() + "\n");
					
					ServiceNode parentNode = getParentNode(parentLevel,rootNode);
//					for (Node nodeKey : nodekeys) {
//						NodeValue nodeValueMapping = mapping.getNodeMappingMap().get(nodeKey);
//						String tempLevel = nodeValueMapping.getLevel();
//						if(parentLevel.equals(tempLevel))
//						{
//							node.setParentNode(nodeKey);
//									
//						}
//					}
//							
//					Node parentNode = node.getParentNode();
					if(parentNode.getChildrenNode() == null)
					{
						List<ServiceNode> keyChildNode = new ArrayList<ServiceNode>();
						keyChildNode.add(node);
						parentNode.setChildrenNode(keyChildNode);
					}
					else
						parentNode.getChildrenNode().add(node);
					
					ServiceNodeValue parentNodeValue = mapping.getNodeMappingMap().get(parentNode);
					parentNodeValue.setSelfExecutionTime(parentNodeValue.getSelfExecutionTime() - nodeVaule.getExecutionTime());
					
					nodeVaule.setPercentageRelative(Float.parseFloat(branchMatcher.group(4))/parentNodeValue.getExecutionTime());
					mapping.getNodeMappingMap().put(node, nodeVaule);
				}
				String function = nodeVaule.getFunctionName() + " - " + nodeVaule.getFuncationDescription();
				FunctionStatistics fs = tree.getFunctionStatistics().get(function);
				if(fs == null)
				{
					fs = new FunctionStatistics();
					fs.setAvgTime(nodeVaule.getExecutionTime());
					fs.setMaxTime(nodeVaule.getExecutionTime());
					fs.setMinTime(nodeVaule.getExecutionTime());
					fs.setRatio((float)nodeVaule.getExecutionTime() / rootNodeValue.getExecutionTime());
					fs.setCount(1);
					tree.getFunctionStatistics().put(function.intern(), fs);
				}
				else
				{
					if(nodeVaule.getExecutionTime() > fs.getMaxTime())
						fs.setMaxTime(nodeVaule.getExecutionTime());
					if(nodeVaule.getExecutionTime() < fs.getMinTime())
						fs.setMinTime(nodeVaule.getExecutionTime());
					fs.setAvgTime((fs.getAvgTime() * fs.getCount() + nodeVaule.getExecutionTime())/ (fs.getCount() + 1));
					fs.setCount(fs.getCount() + 1);
					fs.setRatio((float)fs.getAvgTime() * fs.getCount() / rootNodeValue.getExecutionTime());
				}
//				System.out.println(fs);
			}
							
		}	
	}
	private ServiceNode getParentNode(int[] parentLevel,ServiceNode rootNode) {
		if(parentLevel[0] == 0)
			return rootNode;
		else 
		{
			ServiceNode parentNode = rootNode;
			for (int i = 0; i < parentLevel.length; i++) {
				parentNode = parentNode.getChildrenNode().get(parentLevel[i] - 1);
			}
			return parentNode;
		}
		// TODO Auto-generated method stub
	}

	private boolean isIDFTree(String treeStr) {
		Matcher idMatcher = idfPattern.matcher(treeStr);
		boolean isTree = true;
		if(!idMatcher.find())
		{
			isTree = false;
		}
		return isTree;
	}

	private int[] getParentLevel(String [] levelArr)
	{
		
		if(levelArr.length != 1)
		{
			int [] parentLevel = new int[levelArr.length-1];
			for (int j = 0; j < levelArr.length -1 ; j++) {
				parentLevel[j] = Integer.parseInt(levelArr[j]);
			}
			return parentLevel;
		}
		else
		{
			int [] parentLevel = {0};
			return parentLevel;
		}
	}
	
	/**
	 * check the tree is executed during the timePicker time
	 * @param rootMatcher
	 * @return
	 * @throws ParseException
	 */
	private boolean checkTime(Matcher rootMatcher) throws ParseException
	{
		boolean flag = false;
		long startTime = sdf.parse(rootMatcher.group(1)).getTime() - Long.parseLong(rootMatcher.group(10)) / 1000000;
		// date from maybe 0 or timestamp 
		if(startTime> timePicker.getDateFrom())
		{
			if(startTime < timePicker.getDateTo() || timePicker.getDateTo() == 0)
				flag = true;
		}
		return flag;
	}
	
	/**
	 * matcher informations of the root node
	 * @param rootMatcher
	 * @param functionSb
	 * @param tree
	 * @return
	 * @throws ParseException
	 */
	private ServiceNode setRootNode(Matcher rootMatcher,StringBuilder functionSb,ServiceRequestTree tree) throws ParseException
	{
		ServiceNode rootNode = new ServiceNode();
		rootNode.setParentNode(null);
		ServiceNodeValue rootNodeValue = new ServiceNodeValue();
		rootNodeValue.setFunctionName(rootMatcher.group(8).intern());
		rootNodeValue.setFuncationDescription(rootMatcher.group(9).intern());
		rootNodeValue.setExecutionTime(Long.parseLong(rootMatcher.group(10)));
		rootNodeValue.setSelfExecutionTime(Long.parseLong(rootMatcher.group(10)));
		rootNodeValue.setPercentageAbsolute(1);
		rootNodeValue.setPercentageRelative(1);
		rootNodeValue.setLevel("0");
		
		functionSb.append(rootNodeValue.getFunctionName() + " - " + rootNodeValue.getFuncationDescription() + "\n");
		ServiceNodeMapping mapping = new ServiceNodeMapping();
		Map<ServiceNode,ServiceNodeValue> mappingMap = new HashMap<ServiceNode, ServiceNodeValue>();
		mappingMap.put(rootNode, rootNodeValue);
		mapping.setNodeMappingMap(mappingMap);
		
		tree.setTreeId(Integer.parseInt(rootMatcher.group(2)));
		tree.setClientRequestId(rootMatcher.group(3).intern());
		tree.setCallerId(rootMatcher.group(4).intern());
		tree.setCertificateID(rootMatcher.group(5).intern());
		tree.setRequestId(rootMatcher.group(6).intern());
		tree.setThreadName(rootMatcher.group(7).intern());
		tree.setStartTime(sdf.parse(rootMatcher.group(1)).getTime() - Long.parseLong(rootMatcher.group(10)) / 1000000);
		tree.setEndTime(sdf.parse(rootMatcher.group(1)).getTime());
		tree.setRootNode(rootNode);
		tree.setNodeMapping(mapping);
		Map<String,FunctionStatistics> functionStatisticMap = new HashMap<String, FunctionStatistics>();
		FunctionStatistics fs = new FunctionStatistics();
		fs.setAvgTime(rootNodeValue.getExecutionTime());
		fs.setMaxTime(rootNodeValue.getExecutionTime());
		fs.setMinTime(rootNodeValue.getExecutionTime());
		fs.setRatio(1);
		fs.setCount(1);
		functionStatisticMap.put((rootNodeValue.getFunctionName() + " - " + rootNodeValue.getFuncationDescription()).intern(), fs);
		tree.setFunctionStatistics(functionStatisticMap);
		
		return rootNode;
	}
	
	private static int parseLevel(String s){
		int result = 0;
		int i = 0, max = s.length();
		int radix=10;
		int digit;
		if (max>0){
			digit = Character.digit(s.charAt(i++),radix);
			result = -digit;
		}
		
		while (i < max) {
			digit = Character.digit(s.charAt(i++),radix);
			result *= radix;
			result -= digit;
		}
		return -result;
	}
	
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface NodeDao<T> {
	public boolean addNode(T entity) throws DataAccessException;
	public T getNodeById(int id)throws DataAccessException;
	public List<T> getNodeByParentUUID(String parentUUID)throws DataAccessException;
	public T getNodeByUUID(String uuid) throws DataAccessException;
	public boolean addNodeList(List<T> list);
	public List<T> getNodeListByUUID(List<T> list);
}

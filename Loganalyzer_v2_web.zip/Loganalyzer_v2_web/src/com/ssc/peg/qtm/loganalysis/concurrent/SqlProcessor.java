package com.ssc.peg.qtm.loganalysis.concurrent;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsTreeDao;
import com.ssc.peg.qtm.loganalysis.db.ConnectionFactory;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;
import com.ssc.peg.qtm.loganalysis.constants.DBPropertyContants;

public class SqlProcessor implements Runnable {
	private final String DRIVER = DBPropertyContants.DRIVER;
	private final String URL = DBPropertyContants.URL;

	private final String USER = DBPropertyContants.USER;
	private final String PASSWORD = DBPropertyContants.PWD;
	Logger logger = Logger.getLogger(getClass());
	private List<FunctionStatisticsTree> funcStatisList = null;
	private FunctionStatisticsTreeDao<FunctionStatisticsTree> fucStatisTreeDao;

	public SqlProcessor(List<FunctionStatisticsTree> funcStatisList,
			FunctionStatisticsTreeDao<FunctionStatisticsTree> fucStatisTreeDao
			 ) {
		this.funcStatisList = funcStatisList;
		this.fucStatisTreeDao = fucStatisTreeDao;
	}

	public void run() {
		
		
		long thisTime ;
		Connection conn = null;
		PreparedStatement ptmt = null;
		try {
			Class.forName(DRIVER);
//			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			conn = ConnectionFactory.getConnection();
			long currentTime = System.currentTimeMillis();
			long connTime = System.currentTimeMillis();
//			logger.info("--------------------------------db conn time: " + (connTime - currentTime));
			StringBuilder sb = new StringBuilder(300000);
			sb.append("insert into FUNC_STAT_IN_TREE(tree_uuid,max_time,min_time,avg_time,FUNC_CNT,FUNC_ID,ratio,ANALY_ID) values ".intern()); 
			sb.append("(".intern());
			sb.append("\"".intern());
			sb.append(funcStatisList.get(0).getTreeUUID());
			sb.append("\"".intern());
			sb.append(",".intern());
			sb.append(funcStatisList.get(0).getMaxTime());
			sb.append(",".intern());
			sb.append(funcStatisList.get(0).getMinTime());
			sb.append(",".intern());
			sb.append(funcStatisList.get(0).getAvgTime());
			sb.append(",".intern()); 
			sb.append(funcStatisList.get(0).getCount());
			sb.append(",".intern());
			sb.append(funcStatisList.get(0).getFunctionId());
			sb.append(",".intern());
			sb.append(funcStatisList.get(0).getRatio());
			sb.append(",".intern());
			sb.append(funcStatisList.get(0).getAnalysisId());
			sb.append(")");
			for (int i = 1; i < funcStatisList.size(); i++) {
				sb.append(",".intern());
				sb.append("(".intern());
				sb.append("\"".intern());
				sb.append(funcStatisList.get(i).getTreeUUID());
				sb.append("\"".intern());
				sb.append(",".intern());
				sb.append(funcStatisList.get(i).getMaxTime());
				sb.append(",".intern());
				sb.append(funcStatisList.get(i).getMinTime());
				sb.append(",".intern());
				sb.append(funcStatisList.get(i).getAvgTime());
				sb.append(",".intern()); 
				sb.append(funcStatisList.get(i).getCount());
				sb.append(",".intern());
				sb.append(funcStatisList.get(i).getFunctionId());
				sb.append(",".intern());
				sb.append(funcStatisList.get(i).getRatio());
				sb.append(",".intern());
				sb.append(funcStatisList.get(i).getAnalysisId());
				sb.append(")");
			}
			thisTime = System.currentTimeMillis();
			logger.info("sb.length()=" + sb.length());
			logger.info("stringbuilder cost:" + (thisTime - connTime));
			ptmt = conn.prepareStatement(sb.toString());
			sb.setLength(0);
			sb = null;
				ptmt.execute();
//				logger.info("***********insert to db cost*****"+ (System.currentTimeMillis() - thisTime));
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(ptmt !=null)
					ptmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		

	}
}
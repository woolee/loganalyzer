package com.ssc.peg.qtm.loganalysis.bean;

/**
 * The class is used for analysis of DB. We combine information together in the class and put it to queue. 
 * @author a549324
 *
 */
public class QueueObject {
	private String uuid;
	private String line;
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	
}

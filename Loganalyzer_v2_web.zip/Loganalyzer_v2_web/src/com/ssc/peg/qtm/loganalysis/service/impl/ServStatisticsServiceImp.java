package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.List;

import javax.inject.Inject;

import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceStatisticsDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.service.ServiceStatisticsService;

@org.springframework.stereotype.Service
public class ServStatisticsServiceImp<T extends ServiceStatistics> implements ServiceStatisticsService<T> {

	@Inject
	private ServiceStatisticsDao<T> dao;


	@Override
	public List<T> getServiceStatisListByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return dao.getServiceStatisListByAnalysisId(analysisId);
	}

}

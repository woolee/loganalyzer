package com.ssc.peg.qtm.loganalysis.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.peg.qtm.loganalysis.bean.ServiceFunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.concurrent.ConcurrentMapManager;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;
import com.ssc.peg.qtm.loganalysis.util.SortUtil;

@Controller
@RequestMapping("/back")
public class FuncRatioStatController {
	

	/**
	 * Get the select the function and show function statistics detail
	 * @param response
	 * @param request
	 * @param session
	 * @param model
	 * @return
	 */
	@RequestMapping("/idfnumber")
	public String showidf(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {
		
		String function=request.getParameter("function_name");
		model.addAttribute("Function", function);
//		session.setAttribute("Function", function);
		
		return "../view/funcStatDetail.jsp";
	}
	
	/**
	 * The method is get the services ratio of specified function, and return the JSON format
	 * @param response
	 * @param request
	 * @param session
	 * @param model
	 */
	@RequestMapping("/serv_ratio")
	public void showServRatio(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {
		String uuid = (String) session.getAttribute("uuid");
		String function=request.getParameter("func");
		ConcurrentMapManager instance = DataMapSelector.selectConcurrentMap(uuid);		
		Map<String, ServiceFunctionStatistics> funcStatInServMap = instance.getInvertedIdfTreeMap().get(function);
	
		List<String> functionnamelist = new ArrayList<String>();
		functionnamelist.add(function);
		List<String> strlist_idfnumber = new ArrayList<String>();
		List<Double> strlist_percentageabs = new ArrayList<Double>();
		List<Double> strlist_selfpercentageabs = new ArrayList<Double>();
		List<Double> strlist_childpercentageabs = new ArrayList<Double>();
		List<Double> strlist_totalavgTime = new ArrayList<Double>();
		List<Double> strlist_selfavgTime = new ArrayList<Double>();
		List<Double> strlist_childrenavgTime = new ArrayList<Double>();
		List<List> idfnumber_and_percentage = new ArrayList<List>();

		Map<String,ServiceFunctionStatistics> sortedMap = SortUtil.sortByRatio(funcStatInServMap);//sort map
		for(Entry<String, ServiceFunctionStatistics> entry : sortedMap.entrySet()){
			strlist_idfnumber.add(entry.getKey());
			strlist_percentageabs.add((double) (entry.getValue().getPercentageByRoot()*100));
			strlist_selfpercentageabs.add((double) (entry.getValue().getSelfPercentageByRoot()*100));
			strlist_childpercentageabs.add((double) ((entry.getValue().getPercentageByRoot()-entry.getValue().getSelfPercentageByRoot())*100));
			strlist_totalavgTime.add((double) (entry.getValue().getAvgTimeInIdf()/1000000));
			strlist_selfavgTime.add((double) (entry.getValue().getSelfAvgTime()/1000000));
			strlist_childrenavgTime.add((double) (entry.getValue().getAvgTimeInIdf()/1000000-entry.getValue().getSelfAvgTime()/1000000));		
		}
		
		idfnumber_and_percentage.add(0, strlist_idfnumber);
		idfnumber_and_percentage.add(1, strlist_percentageabs);
		idfnumber_and_percentage.add(2, functionnamelist);
		idfnumber_and_percentage.add(3, strlist_selfpercentageabs);
		idfnumber_and_percentage.add(4, strlist_childpercentageabs);
		idfnumber_and_percentage.add(5, strlist_totalavgTime);
		idfnumber_and_percentage.add(6, strlist_selfavgTime);
		idfnumber_and_percentage.add(7, strlist_childrenavgTime);
		
		try {
			response.getWriter().print(JSONArray.fromObject(idfnumber_and_percentage).toString());
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	/**
	 * The method get the top 5 requests that specified function in the tree takes the most execution time group by service. 
	 * @param response
	 * @param request
	 * @param session
	 * @param model
	 */
	@RequestMapping("/top5request")
	public void top5request(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {
		String uuid = (String) session.getAttribute("uuid");
		final String functionname = request.getParameter("func");
		String idfnumber = request.getParameter("idfNumber");
		ConcurrentMapManager manager = DataMapSelector.selectConcurrentMap(uuid);
		List<ServiceRequestTree> requestlist = manager.getFunctionRatioTopN().get(functionname).get(idfnumber);
		
		List<String> requestid = new ArrayList<String>();
		List<Long> requesttime = new ArrayList<Long>();//function avgTime in request
		List<Float> requestpercentage = new ArrayList<Float>();//function percentage in request
		List<List> top5request = new ArrayList<List>();
		
		//sort requestlist by percentage
		Collections.sort(requestlist, new Comparator<ServiceRequestTree>() {
			  public int compare(ServiceRequestTree s1, ServiceRequestTree s2) {
			    if (s1.getFunctionStatistics().get(functionname).getRatio() > s2.getFunctionStatistics().get(functionname).getRatio()) return -1;
			    if (s1.getFunctionStatistics().get(functionname).getRatio() > s2.getFunctionStatistics().get(functionname).getRatio()) return 1;
			    return 0;
			  }});
		
		for (ServiceRequestTree RequestTree : requestlist) {
			requestid.add(RequestTree.getRequestId());
			requesttime.add((long) RequestTree.getFunctionStatistics().get(functionname).getAvgTime()/1000000);
			requestpercentage.add(RequestTree.getFunctionStatistics().get(functionname).getRatio()*100);
			
		}
		session.setAttribute("top5requestlist", requestlist);
		top5request.add(0, requestid);
		top5request.add(1, requesttime);
		top5request.add(2, requestpercentage);
		
		try {
			response.getWriter().print(JSONArray.fromObject(top5request).toString());
			//response.getWriter().print(jsonarray);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
}
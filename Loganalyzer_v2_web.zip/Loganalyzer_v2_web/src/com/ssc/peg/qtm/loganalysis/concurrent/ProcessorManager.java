package com.ssc.peg.qtm.loganalysis.concurrent;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import com.ssc.peg.qtm.loganalysis.bean.TimePicker;


/**
 * The class is an thread pool which manage the log processor thread.
 * 
 * @author a549324
 *
 */
public class ProcessorManager implements Runnable{
	
	BlockingQueue inQueue = null;
	private int processorNumber = 0;
	private AtomicBoolean processorFinishFlag =  new AtomicBoolean();
//	private BlockingQueue<Runnable> taskQueue = new ArrayBlockingQueue<Runnable>(204800);
	private BlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<Runnable>();
	private String uuid;
	private int topN = 10;
	private TimePicker timePicker;
	public ProcessorManager(BlockingQueue inQueue,int processorNumber, AtomicBoolean processorFinishFlag,String uuid,int topN) {
        this.inQueue = inQueue;
        this.processorNumber = processorNumber;
        this.processorFinishFlag = processorFinishFlag;
        this.topN = topN;
        this.uuid = uuid;
    }

	public ProcessorManager(BlockingQueue inQueue,int processorNumber, AtomicBoolean processorFinishFlag,String uuid,TimePicker timePicker) {
        this.inQueue = inQueue;
        this.processorNumber = processorNumber;
        this.processorFinishFlag = processorFinishFlag;
        this.uuid = uuid;
        this.timePicker = timePicker;
    }
	@Override
	public void run() {
		
//		Logger logger = Logger.getLogger(ProcessorManager.class);
//		logger.setLevel(Level.INFO);
		
		ThreadPoolExecutor executor = new ThreadPoolExecutor(
				processorNumber,
				processorNumber+5,
				5, 
				TimeUnit.SECONDS,
				taskQueue){
			@Override 
			protected void terminated() { 
				processorFinishFlag.set(true);
		     } 
			
		};
		while(true){
			System.out.println("taskQueue.size()=" + taskQueue.size());
			String inQueueString = "";
			try {
				inQueueString = (String)inQueue.poll(5, TimeUnit.SECONDS);
				if(inQueueString == null){
					System.out.println("process thread shut down ");
					break;
				}
			} catch (InterruptedException e) {
//				logger.error(e.getStackTrace().toString());
			}
			executor.execute(new LogProcessor(inQueueString,uuid,timePicker));
		}
		executor.shutdown();
		
		
	}//end of run function
	
	


}

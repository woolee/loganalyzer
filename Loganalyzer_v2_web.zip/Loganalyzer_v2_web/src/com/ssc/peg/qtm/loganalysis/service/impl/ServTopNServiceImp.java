package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.List;

import javax.inject.Inject;

import com.ssc.peg.qtm.loganalysis.dao.ServiceTopNDao;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.service.ServiceTopNService;

@org.springframework.stereotype.Service
public class ServTopNServiceImp<T extends ServiceTopN> implements ServiceTopNService<T> {

	@Inject
	private ServiceTopNDao<T> dao;


	@Override
	public List<T> getTopNByAnalyIdAndServiceId(int analysisId, int serviceId) {
		// TODO Auto-generated method stub
		return dao.getTopNByAnalyIdAndServiceId(analysisId, serviceId);
	}

}

package com.ssc.peg.qtm.loganalysis.concurrent.db2;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ssc.peg.qtm.loganalysis.bean.QueueObject;


public class RequestReader implements Runnable{
	private Logger log = Logger.getLogger(getClass());
    protected BlockingQueue queue = null;
    private ResultSet rs = null;
    public RequestReader(BlockingQueue queue,ResultSet rs) {
        this.queue = queue;
        this.rs = rs;
    }
    
    public void run() {
    	log.info("start reading logs...");
//    	File file = new File(logFilePath);
//    	writeToFileAndRead();
    	putToQueue();
    	log.info("read log end...");
    }
    
    
    private void putToQueue(){
//    	StringBuilder builder1 = new StringBuilder(20480000);
    	StringBuilder builder = new StringBuilder(10240);
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    	long current = System.currentTimeMillis();
//    	File outFile = new File("C:/tempDBFile/"+current + ".csv");
//		try {
//			if(!outFile.exists())
//				outFile.createNewFile();
//			RandomAccessFile out = new RandomAccessFile(outFile,"rw");
    	long totalSt = System.nanoTime();
			String currentUUID = "";
				String uuid;
				try {
//					long start1 = 0;
					while(rs.next()){
//					long start = System.nanoTime();
					uuid = rs.getString("UUID");
					String entityName = rs.getString("ENTITY_NM").intern();
					String functionName = rs.getString("COMPONENT_NM").intern();
					String funcationDesc = rs.getString("TASK_NM").intern();
					String criteria = rs.getString("CRITERIA_CD").intern();
					Date startTime = rs.getTimestamp("START_TS");
					Date endTime = rs.getTimestamp("END_TS");
					String level = rs.getString("CALL_NUM_TXT").intern();
					long execuTime = rs.getLong("TIME_SPENT_NUM");
					String callerId = rs.getString("USER_ID").intern();
//					long end = System.nanoTime();
					/*if(currentUUID.equals("")){
//					builder.append("-----begin-----\n");
						start1 = System.nanoTime();
						currentUUID = uuid;
					}
					else if(!currentUUID.equals(uuid)){
						System.out.println("*********" + (System.nanoTime() - start1)+ "ns");
						start1 = System.nanoTime();
						queue.put(builder.toString());
						System.out.println("queue.size()=" + queue.size());
						builder.setLength(0);
						currentUUID = uuid;
					}*/
					log.info("ResultSet get one. Request Id=" + uuid);
					builder.append(uuid
							+ "," + entityName.intern()
							+ "," + functionName.intern()
							+ "," + funcationDesc
							+ "," + criteria.intern()
							+ "," + callerId .intern()
							+ "," + sdf.format(startTime)
							+ "," + sdf.format(endTime)
							+ "," + level.intern()
							+ "," + execuTime 
							+ "\n");
					QueueObject obj = new QueueObject();
					obj.setUuid(uuid);
					obj.setLine(builder.toString());
					queue.put(obj);
					log.info("Put one to queue, current queue.size()="+queue.size());
					builder.setLength(0);
//					long end = System.nanoTime();
//					System.out.println("cost-----" +  (end - start));
					}
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
    }
 /*   private void readLog(File file,StringBuilder stringBuilder)
    {
    	try {
			FileInputStream fileInputStream = null;
			fileInputStream = new FileInputStream(file);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
			String line = br.readLine();
			
			Boolean hasBegin = false;
			while(line != null){
				Boolean beginFlag = line.contains("=Begin=");
				Boolean endFlag = line.contains("=End=");
				
				if(beginFlag){
					hasBegin = true;
				}
				else if(!beginFlag && !endFlag && hasBegin){
					stringBuilder.append(line);
					stringBuilder.append("\n");
				}
				else if(endFlag && hasBegin ){
//					stringBuilder.deleteCharAt(stringBuilder.length()-1);
					queue.put(stringBuilder.toString());
					stringBuilder.setLength(0);
					hasBegin = false;
				}
				line = br.readLine();
				continue;
				
			}//end while
			
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
		
    }*/
    
    
    /*public List<File> getLogFiles(File directory,List<File> logFileList)
    {
    	File[] logFiles = directory.listFiles(new FileFilter() {
			
			@Override
			public boolean accept(File pathname) {
				if(pathname.getName().endsWith(".log") || pathname.isDirectory() )
					return true;
				return false;
			}
		}
		);
    	if(logFiles.length > 0)
    	{
    		for (File file : logFiles) {
    			if(file.isDirectory())
    				getLogFiles(file, logFileList);
    			else
    				logFileList.add(file);
    		}
    	}
    	return logFileList;
    }*/
    
}

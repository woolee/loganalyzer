package com.ssc.peg.qtm.loganalysis.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.concurrent.ConcurrentMapManager;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;

@Controller
@RequestMapping("/request")
public class RequestTreecontroller {
	
	@RequestMapping("/onerequesttree_before")
	public String idfnumber(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {
		
		String idfnumber = request.getParameter("idfNumber");
		session.setAttribute("idfNumber", idfnumber);
		String requestid=request.getParameter("requestId");	
		session.setAttribute("requestId", requestid);
		String flag = request.getParameter("flag");
		session.setAttribute("flag", flag);
		
		if(request.getParameter("idfNumber") != null){//if has, comes from showInvertedIDF.jsp;otherwise,from top10request.jsp
			session.setAttribute("idfNumber", request.getParameter("idfNumber"));
		}
		
		return "../view/showRequests.jsp";
		
	}
	
	@RequestMapping("/onerequesttree")
	public void mergetree(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {    
		String uuid = (String) session.getAttribute("uuid");
		String requestid=request.getParameter("requestId");	
		String flag = request.getParameter("flag");
		System.out.println("top5request: "+requestid);
		// "topNrequest" in TopN-controller
		
		ConcurrentMapManager instance = DataMapSelector.selectConcurrentMap(uuid);	
		int requestIndex = -1;//which one is the request in top 10
		ServiceRequestTree tree = null;//the request chosed
		if("fromtop5".equals(flag)){
			List<ServiceRequestTree> top5request = (List<ServiceRequestTree>) session.getAttribute("top5requestlist");
			for (int j = 0; j < top5request.size(); j++) {
				if(requestid.equals(top5request.get(j).getRequestId())){
					requestIndex = j;
					tree = top5request.get(j);
					break;
				}
			}
		}else{
			List<ServiceRequestTree> top10_requests = (List<ServiceRequestTree>) session.getAttribute("topNrequest");
			for(int i=0;i<top10_requests.size();i++){
				if(requestid.equals(top10_requests.get(i).getRequestId())){
					requestIndex = i;
					tree = top10_requests.get(i);
					break;
				}
			}
		}
		
		ServiceNode rootNode = tree.getRootNode();	
		
		StringBuffer sb = new StringBuffer();
		sb.append("{");
		String json1 = HasChildren(rootNode,tree,sb);
		sb.append("}");

		System.out.println("sb: "+sb.toString());
		JsonParser parser = new JsonParser();
        JsonElement jsonE = parser.parse(sb.toString().trim());
	    JsonObject json = jsonE.getAsJsonObject();
	      
		try {
			response.getWriter().print(json);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
	}
	
	private String HasChildren(ServiceNode rootNode,ServiceRequestTree tree,StringBuffer sb) {
		// TODO Auto-generated method stub
		ServiceNodeValue  parentNodeValue = tree.getNodeMapping().getNodeMappingMap().get(rootNode);
		
//	  	Map<NodeValue,NodeStatistics> map = CommonMap.idgMergeNodeStatisticsMap.get(idfnumber);
//	  	
//	  	String lastString = null;
//	 	NodeStatistics statis =  map.get(parentNodeValue);
	 		 	
	 	String function= parentNodeValue.getFunctionName()+" - "+parentNodeValue.getFuncationDescription();
	 	double excutionTime = parentNodeValue.getExecutionTime();
	 	double percentageabs=parentNodeValue.getPercentageAbsolute();
	 	
	 	sb.append("\"name\""+":");
	 	sb.append("\""+function+"\"");
	 	sb.append(",");
	 	sb.append("\"excutionTime\""+":");
	 	sb.append("\""+excutionTime/1000000+"\"");
	 	sb.append(",");
	 	sb.append("\"percentageabs\""+":");
	 	sb.append("\""+percentageabs+"\"");
	 	
	 	//test results
/*	 	System.out.println("-----------------");
	 	System.out.println("function:"+function);
	 	System.out.println("excutionTime:"+excutionTime/1000000);
	 	System.out.println("percentagerel"+percentagerel);*/
	 	//test results
	 	
	 	if(rootNode.getChildrenNode()!= null){
	 		
	 		sb.append(","+"\"children\""+":"+"[");
	 		sb.append("{");
	 		sb.append("\"name\""+":");
		 	sb.append("\"self\"");
		 	sb.append(",");
		 	sb.append("\"excutionTime\""+":");
		 	sb.append("\""+parentNodeValue.getSelfExecutionTime()/1000000+"\"");
		 	System.out.println("getSelfExecutionTime:"+parentNodeValue.getSelfExecutionTime()/1000000);
		 	sb.append(",");
		 	sb.append("\"percentageabs\""+":");
		 	sb.append("\""+parentNodeValue.getSelfExecutionTime()/parentNodeValue.getExecutionTime()+"\"");
		 	sb.append("},"); 
		 	
 			List<ServiceNode> children = rootNode.getChildrenNode();
 			for(int j=0;j<children.size()-1;j++){
 				sb.append("{");
	  			HasChildren(children.get(j),tree,sb);
	  			sb.append("},");
 			}
 			sb.append("{");
  			HasChildren(children.get(children.size()-1),tree,sb);
  			sb.append("}");
	  		sb.append("]");
	 	}
	 	return sb.toString();
	}
	
}

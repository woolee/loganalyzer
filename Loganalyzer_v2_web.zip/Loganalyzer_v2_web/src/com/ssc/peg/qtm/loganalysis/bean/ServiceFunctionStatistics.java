package com.ssc.peg.qtm.loganalysis.bean;

public class ServiceFunctionStatistics {
	private float percentageByRoot;
	private int countInIdf;
	private float avgTimeInIdf;
	private float totalTime;
	private long maxTimeInIdf;
	private long minTimeInIdf;
	private float selfAvgTime;
	private float selfPercentageByRoot;
	private float totalSelfTime;
	public float getPercentageByRoot() {
		return percentageByRoot;
	}
	public void setPercentageByRoot(float percentageByRoot) {
		this.percentageByRoot = percentageByRoot;
	}
	public float getAvgTimeInIdf() {
		return avgTimeInIdf;
	}
	public void setAvgTimeInIdf(float avgTimeInIdf) {
		this.avgTimeInIdf = avgTimeInIdf;
	}
	public int getCountInIdf() {
		return countInIdf;
	}
	public void setCountInIdf(int countInIdf) {
		this.countInIdf = countInIdf;
	}
	public long getMaxTimeInIdf() {
		return maxTimeInIdf;
	}
	public void setMaxTimeInIdf(long maxTimeInIdf) {
		this.maxTimeInIdf = maxTimeInIdf;
	}
	public long getMinTimeInIdf() {
		return minTimeInIdf;
	}
	public void setMinTimeInIdf(long minTimeInIdf) {
		this.minTimeInIdf = minTimeInIdf;
	}
	public float getSelfAvgTime() {
		return selfAvgTime;
	}
	public void setSelfAvgTime(float selfAvgTime) {
		this.selfAvgTime = selfAvgTime;
	}
	public float getSelfPercentageByRoot() {
		return selfPercentageByRoot;
	}
	public void setSelfPercentageByRoot(float selfPercentageByRoot) {
		this.selfPercentageByRoot = selfPercentageByRoot;
	}
	public float getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(float totalTime) {
		this.totalTime = totalTime;
	}
	public float getTotalSelfTime() {
		return totalSelfTime;
	}
	public void setTotalSelfTime(float totalSelfTime) {
		this.totalSelfTime = totalSelfTime;
	}
	
	@Override
	public String toString() {
		return "ServiceFunctionStatistics [percentageByRoot=" + percentageByRoot + ", countInIdf=" + countInIdf + ",avgTimeInIdf=" + avgTimeInIdf + ", totalTime="
				+ totalTime + ", maxTimeInIdf=" + maxTimeInIdf + ", minTimeInIdf="
				+ minTimeInIdf  + ", selfAvgTime=" + selfAvgTime + ", selfPercentageByRoot="
				+ selfPercentageByRoot + ", totalSelfTime=" + totalSelfTime +"]";
	}
}

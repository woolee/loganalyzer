package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

public interface FunctionStatisticsMapper<T> extends SqlMapper{
	public void addFunctionStatistics(T entity);
	public T getFunctionStaById(int id);
	public T getFunctionStaByFunctionId(int functionId);
	public void addFunctionStatisticsList(List<T> list);
	public List<T> getFunctionStaByAnalysisId(int analysisId);
}

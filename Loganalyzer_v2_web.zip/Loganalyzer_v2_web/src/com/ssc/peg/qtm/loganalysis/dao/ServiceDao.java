package com.ssc.peg.qtm.loganalysis.dao;


public interface ServiceDao<T> {
	public boolean addService(T entity);
	public T getServiceById(int id);
	public T getServiceByName(String name);
}

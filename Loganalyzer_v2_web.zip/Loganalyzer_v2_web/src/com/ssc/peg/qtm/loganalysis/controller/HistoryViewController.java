package com.ssc.peg.qtm.loganalysis.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.AnalysisService;
import com.ssc.peg.qtm.loganalysis.service.FunctionService;
import com.ssc.peg.qtm.loganalysis.service.FunctionStatisticsInServService;
import com.ssc.peg.qtm.loganalysis.service.FunctionStatisticsService;
import com.ssc.peg.qtm.loganalysis.service.PointService;
import com.ssc.peg.qtm.loganalysis.service.ServService;
import com.ssc.peg.qtm.loganalysis.service.ServiceStatisticsService;
import com.ssc.peg.qtm.loganalysis.service.ServiceTopNService;
import com.ssc.peg.qtm.loganalysis.service.TreeService;

/**
 * For view analysis history record.
 * @author a549324
 *
 */
@Controller
@RequestMapping("/history")
public class HistoryViewController {
	@Inject
	private AnalysisService<Analysis> analysisService;
	@Inject
	private FunctionStatisticsService<FunctionStatistics> functionStatisService;
	@Inject
	private ServiceStatisticsService<ServiceStatistics> serviceStatisService;
	@Inject
	private PointService<Point> pointService;
	@Inject
	private ServiceTopNService<ServiceTopN> serviceTopNService;
	@Inject
	private TreeService<Tree> treeService;
	@Inject
	private FunctionStatisticsInServService<ServiceFunction> functionStatisInIDFService;
	@Inject
	private FunctionService<Function> funcService;
	@Inject
	private ServService<Service> servService;
	/**
	 * get the analysis history execution list
	 * @param model
	 * @return
	 */
	@RequestMapping("/getAnalysiss")
	public String getAnalysisHistories(Model model)
	{
		List<Analysis> analysisList = analysisService.getAnalysis();
		model.addAttribute("analysisList", analysisList);
		return "../view/homepage.jsp";
	}
	
	/**
	 * get the analysis history execution list
	 * @param model
	 * @return
	 */
	@RequestMapping("/delanalysis")
	public String delAnalysis(HttpServletRequest request,Model model)
	{
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		analysisService.deleteAnalysis(analysisId);
		List<Analysis> analysisList = analysisService.getAnalysis();
		model.addAttribute("analysisList", analysisList);
		return "../view/homepage.jsp";
	}
	/**
	 * get the summary of functions, services, points for TPS and response time
	 * the informations for analyzer homepage
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/getSummaryInfo")
	public String getLogHomePage(HttpServletRequest request,HttpServletResponse response,Model model,HttpSession session)
	{
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		List<FunctionStatistics> funcStatisList = functionStatisService.getFunctionStaByAnalysisId(analysisId);
		List<ServiceStatistics> servStatisList = serviceStatisService.getServiceStatisListByAnalysisId(analysisId);
		List<Point> pointList = pointService.getTPSRespTimeByAnalysisServiceId(analysisId, 0);
		Map<Integer,Function> funcMap = funcService.getFunctionListByFunctionStatistic(funcStatisList);
		Map<Integer,Service> serviceMap = servService.getServiceByServiceStatics(servStatisList);
		/*for (FunctionStatistics funcStatis : funcStatisList) {
			Function function = funcService.getFunctionById(funcStatis.getFunctionId());
			if(!funcMap.containsKey(function.getFunctionId()))
				funcMap.put(function.getFunctionId(), function);
		}	*/	
		/*for (ServiceStatistics servStatis : servStatisList) {
			Service service = servService.getServiceById(servStatis.getServiceId());
			if(!serviceMap.containsKey(service.getServiceId()))
				serviceMap.put(service.getServiceId(), service);
		}*/
		
		List<String> time = new ArrayList<String>();
		List<Float> tps = new ArrayList<Float>();
		List<Float> responsetime = new ArrayList<Float>();
		List<Long> timestamp = new ArrayList<Long>();
		List<List> idftpsresponsetime = new ArrayList<List>();
		SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
		Collections.sort(pointList, new Comparator<Point>() {

			@Override
			public int compare(Point o1, Point o2) {
				if(o1.getPointTime().getTime() < o2.getPointTime().getTime())
				return -1;
				else if(o1.getPointTime().getTime() == o2.getPointTime().getTime())
					return 0;
				else return 1;
			}
		});
		for(Point point : pointList){
			
			time.add(sdf.format(point.getPointTime())); //get time 
			tps.add(point.getTps());//get tps
			responsetime.add(point.getRespTime()/1000000);//get responsetime
			timestamp.add(point.getPointTime().getTime());
		}
		
		idftpsresponsetime.add(0, time);
		idftpsresponsetime.add(1, tps);
		idftpsresponsetime.add(2, responsetime);
		idftpsresponsetime.add(3, timestamp);
		
		List<String> countlist = new ArrayList<String>();
		List<String> timelist = new ArrayList<String>();
		for(ServiceStatistics servStatis : servStatisList){
			StringBuffer countStrBulder = new StringBuffer();
			countStrBulder.append("[\"");
			Service service = serviceMap.get(servStatis.getServiceId());
			countStrBulder.append(service.getServiceName());
			countStrBulder.append("\",");
			countStrBulder.append(servStatis.getCount());
			countStrBulder.append("]");
			countlist.add(countStrBulder.toString());
			
			StringBuffer timeStrBulder = new StringBuffer();
			timeStrBulder.append("[\"");
			timeStrBulder.append(service.getServiceName());
			timeStrBulder.append("\",");
			timeStrBulder.append(servStatis.getAvgTime());
			timeStrBulder.append("]");
			timelist.add(timeStrBulder.toString());
		}
//		System.out.println(JSONArray.fromObject(strlist).toString());
		float ratio = 0.1f;
		
		//key: service id; value: list of function statistics in service 
		Map<Integer,List<ServiceFunction>> functionStatisFilterMap = functionStatisInIDFService.getFuncStatisMapByRatio(analysisId, ratio, serviceMap.keySet());
		
		/*for (Integer serviceId : serviceMap.keySet()) {
			List<ServiceFunction>  functionStatisInService = functionStatisInIDFService.getFunctionStatisticBiggerThan(analysisId, serviceId, ratio);
			functionStatisFilterMap.put(serviceId, functionStatisInService);
		}*/
		
		model.addAttribute("functionStatisFilterMap", functionStatisFilterMap);
		model.addAttribute("funcMap", funcMap);
		model.addAttribute("serviceMap", serviceMap);
		model.addAttribute("funcStatisList", funcStatisList);
		model.addAttribute("servStatisList", servStatisList);
		model.addAttribute("pointList", pointList);
		model.addAttribute("pointJson", JSONArray.fromObject(idftpsresponsetime).toString());
		model.addAttribute("serviceCountJson",JSONArray.fromObject(countlist).toString());
		model.addAttribute("serviceTimeJson",JSONArray.fromObject(timelist).toString());
		session.setAttribute("analysisId", analysisId);
		return "../view/showHistorySummary.jsp";
	}
	
	/**
	 * export the service statistics summary to CSV file
	 * @param response
	 * @param request
	 * @param model
	 * @throws Throwable
	 */
	@RequestMapping("/exportSerivce")
    public void exportServicesToCSV(HttpServletResponse response,HttpServletRequest request,Model model) throws Throwable {
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		
		List<FunctionStatistics> funcStatisList = functionStatisService.getFunctionStaByAnalysisId(analysisId);
		List<ServiceStatistics> servStatisList = serviceStatisService.getServiceStatisListByAnalysisId(analysisId);
		Map<Integer,Function> funcMap = funcService.getFunctionListByFunctionStatistic(funcStatisList);
		Map<Integer,Service> serviceMap = servService.getServiceByServiceStatics(servStatisList);
		float ratio = 0.1f;
		//key: service id; value: list of function statistics in service 
		Map<Integer,List<ServiceFunction>> functionStatisFilterMap = functionStatisInIDFService.getFuncStatisMapByRatio(analysisId, ratio, serviceMap.keySet());
		
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"service_summary.csv\"");
	    try
	    {
	        OutputStream outputStream = response.getOutputStream();
	        StringBuilder outputResult = new StringBuilder();
	        outputResult.append("Service Name,Hot spots(self ratio),Max(ms),Avg(ms),Min(ms),90% Line(ms),Avg TPS,Call count,Total Time(ms)\n");
	        for (ServiceStatistics statistic : servStatisList) {
	        	String serviceName = serviceMap.get(statistic.getServiceId()).getServiceName();
	        	outputResult.append(
	        			serviceName + ","
	        			
	        			);
	        	for (ServiceFunction serviceFunction : functionStatisFilterMap.get(statistic.getServiceId())) {
	        		Function function = funcMap.get(serviceFunction.getFunctionId());
	        		outputResult.append(function.getFunctionName() + " - " + function.getFunctionDescription() + "(" + serviceFunction.getSelfRatio() * 100  + "%)   ");
				}
	        	outputResult.append(
	        	"," + statistic.getMaxTime()/Math.pow(10, 6) + ","
    			+ statistic.getAvgTime()/Math.pow(10, 6) + ","
    			+ statistic.getMinTime()/Math.pow(10, 6) + ","
    			+ statistic.getNintyTime()/Math.pow(10, 6) + ","
    			+ statistic.getAvgTps() + ","
    			+ statistic.getCount() + ","
    			+ statistic.getCount()/statistic.getAvgTps()*Math.pow(10, 6) + "\n");
			}
	        outputStream.write(outputResult.toString().getBytes());
	        outputStream.flush();
	        outputStream.close();
	    }
	    catch(Exception e)
	    {
	    	throw e;
	    }
    }
	
	/**
	 * Export the hot function summary table to CSV file
	 * @param response
	 * @param request
	 * @param model
	 * @throws Throwable
	 */
	@RequestMapping("/exportFunction")
    public void exportFunctionToCSV(HttpServletResponse response,HttpServletRequest request,Model model) throws Throwable {
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		
		List<FunctionStatistics> funcStatisList = functionStatisService.getFunctionStaByAnalysisId(analysisId);
		Map<Integer,Function> funcMap = funcService.getFunctionListByFunctionStatistic(funcStatisList);
		
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"function_summary.csv\"");
	    try
	    {
	        OutputStream outputStream = response.getOutputStream();
	        StringBuilder outputResult = new StringBuilder();
	        outputResult.append("Function Name,Issue Score(Rms-Std),Max(ms),Avg(ms),Min(ms),Count\n");
	        for (FunctionStatistics statistic : funcStatisList) {
	        	Function function = funcMap.get(statistic.getFunctionId());
	        	outputResult.append(
	        			function.getFunctionName() + " - " + function.getFunctionDescription() + ","
	        			+ statistic.getScore() + ","
	        			+ statistic.getMaxTime()/Math.pow(10, 6) + ","
	        			+ statistic.getAvgTime()/Math.pow(10, 6) + ","
	        			+ statistic.getMinTime()/Math.pow(10, 6) + ","
	        			+ statistic.getCount() + "\n"
	        			);
			}
	        outputStream.write(outputResult.toString().getBytes());
	        outputStream.flush();
	        outputStream.close();
	    }
	    catch(Exception e)
	    {
	    	throw e;
	    }
    }
	
	/**
	 * export top n function in specify service to CSV file
	 * @param response
	 * @param request
	 * @param model
	 * @throws Throwable
	 */
	@RequestMapping("/export")
    public void exportTopNFunctionToCSV(HttpServletResponse response,HttpServletRequest request,Model model) throws Throwable {
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		int serviceId = Integer.parseInt(request.getParameter("serviceId"));
		List<ServiceFunction> serviceFunctionList = functionStatisInIDFService.gettopNfunctioninservice(analysisId, serviceId,30);
		/*Map<Integer,Function> functionMap = new HashMap<Integer,Function>();
		for (ServiceFunction serviceFunction : serviceFunctionList) {
			
			functionMap.put(serviceFunction.getFunctionId(),funcService.getFunctionById(serviceFunction.getFunctionId()));
		}*/
		Map<Integer,Function> functionMap = funcService.getFunctionListByServiceFunction(serviceFunctionList);
		response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\""+ servService.getServiceById(serviceId).getServiceName() +".csv\"");
	    try
	    {
	        OutputStream outputStream = response.getOutputStream();
	        StringBuilder outputResult = new StringBuilder();
	        outputResult.append("Function Name,Max(ms),Avg(ms),Min(ms),ratio(%),self(%),Calls\n");
	        for (ServiceFunction serviceFunction : serviceFunctionList) {
	        	int functionId = serviceFunction.getFunctionId();
	        	Function function = functionMap.get(functionId);
	        	outputResult.append(function.getFunctionName() + " - " + function.getFunctionDescription() + ","
	        			+ (float)serviceFunction.getMaxTime()/1000000 + ","
	        			+ (float)serviceFunction.getAvgTime()/1000000 + ","
	        			+ (float)serviceFunction.getMinTime()/1000000 + ","
	        			+ serviceFunction.getRatio()*100 + ","
	        			+ serviceFunction.getSelfRatio()*100 + ","
	        			+ serviceFunction.getCount() + "\n");
			}
	        outputStream.write(outputResult.toString().getBytes());
	        outputStream.flush();
	        outputStream.close();
	    }
	    catch(Exception e)
	    {
	    	throw e;
	    }
    }
	
	
	/**
	 * The action will redirect to history/getServiceStatis.do
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/servStat")
	public String servStat(HttpServletRequest request,Model model,HttpSession session)
	{
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		String serviceName = request.getParameter("serviceName");
		Service service = servService.getServiceByName(serviceName);
		model.addAttribute("analysisId", analysisId);
		session.setAttribute("serviceId", service.getServiceId());
//		request.setAttribute("serviceId", service.getServiceId());
		
		return "../history/getServiceStatis.do";
	}
	/**
	 * get the merge tree list for specify service
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/getServiceStatis")
	public String getMergeTreeForService(HttpServletRequest request,Model model,HttpSession session)
	{
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		int serviceId = (int) session.getAttribute("serviceId");
//		Tree allStrucMergedTree = treeService.getMergeTreeForService(analysisId, serviceId, true, true).get(0);
//		List<Tree> singleStrucMergeTree = treeService.getMergeTreeForService(analysisId, serviceId, true, false);
		int totalStuctureCount = treeService.getCountOfMergeTreeForService(analysisId, serviceId, true, false);
		String serviceName = servService.getServiceById(serviceId).getServiceName();
//		int totalStuctureCount = singleStrucMergeTree.size();
		
		List<ServiceTopN> serviceTopNList = serviceTopNService.getTopNByAnalyIdAndServiceId(analysisId, serviceId);
		List<Tree> treeList = treeService.getTreeListByServiceTopN(serviceTopNList);
		/*List<Tree> treeList = new ArrayList<Tree>();
		for (ServiceTopN serviceTopN : serviceTopNList) {
			Tree tree = treeService.getTreeByTreeUUID(serviceTopN.getTreeUUID());
			treeList.add(tree);
		}*/
		
		List<Point> pointList = pointService.getTPSRespTimeByAnalysisServiceId(analysisId, serviceId);
		List<String> serviceList = new ArrayList<String>();
		serviceList.add(""+serviceId);
		
		List<String> time = new ArrayList<String>();
		List<Float> tps = new ArrayList<Float>();
		List<Float> responsetime = new ArrayList<Float>();
		List<Long> timestamp = new ArrayList<Long>();
		List<List> serviceJsonList = new ArrayList<List>();//save time, idfnumber, tps, reqponsetime
		SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
//		Map<Long, Map<String, TPSResponseTime>> map = DataMapSelector.selectCommonMap(uuid).getStatisMap();
		Collections.sort(pointList, new Comparator<Point>() {

			@Override
			public int compare(Point o1, Point o2) {
				// TODO Auto-generated method stub
				return (int) (o1.getPointTime().getTime() - o2.getPointTime().getTime());
			}
		});
		for(Point point : pointList){
			time.add(sdf.format(point.getPointTime())); //get time 
				tps.add(point.getTps());//get tps
				responsetime.add( point.getRespTime()/1000000);//get responsetime
				timestamp.add(point.getPointTime().getTime());	
		}
		
		serviceJsonList.add(0, time);
		serviceJsonList.add(1, tps);
		serviceJsonList.add(2, responsetime);
		serviceJsonList.add(3, serviceList);
		serviceJsonList.add(4,timestamp);
		/*String allStrucMergeStr = new String(allStrucMergedTree.getTreeStructure()); */
		
		List<ServiceFunction> serviceFunctionList = functionStatisInIDFService.gettopNfunctioninservice(analysisId, serviceId,30);
		Map<Integer,Function> functionMap = funcService.getFunctionListByServiceFunction(serviceFunctionList);

		model.addAttribute("totalStuctureCount", totalStuctureCount);
		model.addAttribute("serviceName", serviceName);
		model.addAttribute("treeList", treeList);
		session.setAttribute("analysisId", analysisId);
		session.setAttribute("serviceId", serviceId);
		model.addAttribute("serviceJson", JSONArray.fromObject(serviceJsonList).toString());
		model.addAttribute("serviceFunctionList",serviceFunctionList);
		model.addAttribute("functionMap", functionMap);
		System.out.println(serviceFunctionList.size());
		return "../view/showServiceStatis.jsp";
	}
	@RequestMapping("/mergetree_level")
	public void getMergeTree(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws IOException
	{
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		int serviceId = Integer.parseInt(request.getParameter("serviceId"));
		Tree allStrucMergedTree = treeService.getMergeTreeForServiceMerge(analysisId, serviceId, true, true).get(0);
		List<Tree> strucMergedTreeList = treeService.getMergeTreeForService(analysisId, serviceId, true, false);
//		strucMergedTreeList.add(0, allStrucMergedTree);
		String allStrucMergeStr = new String(allStrucMergedTree.getTreeStructure()); 
		session.setAttribute("strucMergedTreeList", strucMergedTreeList);
//		session.setAttribute("mergetreeSize",strucMergedTreeList.size()-1);
		JsonParser parser = new JsonParser();
		JsonElement jsonE = parser.parse(allStrucMergeStr);
	    JsonObject json = jsonE.getAsJsonObject();
	    response.getWriter().print(json);
	}
	@RequestMapping("/getServiceStatisByName")
	public String getServiceByName(HttpServletRequest request,Model model)
	{
		
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		String serviceName = request.getParameter("serviceName");
		int serviceId = servService.getServiceByName(serviceName).getServiceId();
		model.addAttribute("analysisId", analysisId);
		model.addAttribute("serviceId", serviceId);
		return "../history/getServiceStatis.do?serviceId="+serviceId+"&analysisId="+analysisId;
	}
	/**
	 * get the function statistics in service(inverted index)
	 * and top n by ratio
	 * and top n by execution time
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/getFuncStatisInService")
	public String getFunctionStatisInService(HttpServletRequest request,Model model)
	{
		int functionId = Integer.parseInt(request.getParameter("functionId"));
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		
		
		model.addAttribute("analysisId", analysisId);
		model.addAttribute("functionId", functionId);
		return "../view/showHistoryFuncInverted.jsp";
	}
	
	
	@RequestMapping("/getFunctionRatioInService")
	public void getFunctionRationInService(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		int functionId = Integer.parseInt(request.getParameter("functionId"));
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		
		List<List> idfnumber_and_percentage = functionStatisService.getFunctionRatioInService(functionId, analysisId);
		response.getWriter().print(JSONArray.fromObject(idfnumber_and_percentage).toString());
		
		
	}
	
	/**
	 * function ratio top N in provided service
	 * @param request
	 * @param model
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/getFuncRatioTopN")
	public void getFuncTopN(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		int functionId = Integer.parseInt(request.getParameter("functionId"));
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		String serviceName = request.getParameter("serviceName");
		
		List<List> top5request = functionStatisService.getFuncRatioTopN(functionId, analysisId, serviceName);
		response.getWriter().print(JSONArray.fromObject(top5request).toString());
	}
	
	/**
	 * function time top N in provided service
	 * @param request
	 * @param model
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/getFuncTimeTopN")
	public void getFuncTimeTopN(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		int functionId = Integer.parseInt(request.getParameter("functionId"));
		int analysisId = Integer.parseInt(request.getParameter("analysisId"));
		String serviceName = request.getParameter("serviceName");

		List<List> top5request = functionStatisService.getFuncTimeTopN(functionId, analysisId, serviceName);
		response.getWriter().print(JSONArray.fromObject(top5request).toString());
	}
	
	/**
	 * information sended to the single tree structure show page.
	 * @param request
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/getTree")
	public String getTree(HttpServletRequest request,Model model) throws IOException
	{
		int treeId = Integer.parseInt(request.getParameter("treeId"));
		Tree tree = treeService.getTreeById(treeId);
		Service service = servService.getServiceById(tree.getServiceId());
		String serviceName = service.getServiceName();
		model.addAttribute("idfnumber", serviceName);
		model.addAttribute("treeId", treeId);
		model.addAttribute("requestId", tree.getRequestId());
		return "../view/showTrees.jsp";
	}
	
	/**
	 * information sended to the single tree structure show page.
	 * @param request
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/getTreeStrucByReqId")
	public String getTreeStrucByRequestId(HttpServletRequest request,Model model) throws IOException
	{
		String requestId = request.getParameter("requestId");
		Tree tree = treeService.getTreeByRequestId(requestId);
//		Tree tree = treeService.getTreeById(treeId);
		Service service = servService.getServiceById(tree.getServiceId());
		String serviceName = service.getServiceName();
		model.addAttribute("idfnumber", serviceName);
		model.addAttribute("treeId", tree.getTreeId());
		model.addAttribute("requestId", tree.getRequestId());
		return "../view/showTrees.jsp";
	}
	
	/**
	 * get single tree structure for top N tree
	 * @param request
	 * @param response
	 * @param session
	 * @throws IOException
	 */
	@RequestMapping("/treeStucture")
	public void getTreeStucture(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws IOException
	{
		int treeId = Integer.parseInt(request.getParameter("treeId"));
		Tree tree = treeService.getTreeById(treeId);
		JsonParser parser = new JsonParser();
        JsonElement jsonE = parser.parse(new String(tree.getTreeStructure()));
	    JsonObject json = jsonE.getAsJsonObject();
		response.getWriter().print(json);
	}
	/**
	 * get the merged tree structure
	 * @param request
	 * @param response
	 * @param session
	 * @throws IOException
	 */
	@RequestMapping("/serviceStructTree")
	public void getServiceStructTree(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws IOException
	{
		int structnumber = Integer.parseInt(request.getParameter("structnumber"));
		List<Tree> stuctureList = (List<Tree>) session.getAttribute("strucMergedTreeList");
//		int serviceId = (Integer) session.getAttribute("serviceId");
//		int analysisId = (Integer) session.getAttribute("analysisId");
//		List<Tree> stuctureList = treeService.getMergeTreeForService(analysisId, serviceId, true, false);
		Tree tree = stuctureList.get(structnumber);
		JsonParser parser = new JsonParser();
        JsonElement jsonE = parser.parse(new String(tree.getTreeStructure()));
	    JsonObject json = jsonE.getAsJsonObject();
		response.getWriter().print(json);
	}
	
}

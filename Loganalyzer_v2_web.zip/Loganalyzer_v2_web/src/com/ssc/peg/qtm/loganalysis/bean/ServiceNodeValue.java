package com.ssc.peg.qtm.loganalysis.bean;

public class ServiceNodeValue {
	private String level;
	private long executionTime;
	private float percentageAbsolute;
	private float percentageRelative;
	private String functionName;
	private String funcationDescription;
	private long selfExecutionTime;
	public long getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(long executionTime) {
		this.executionTime = executionTime;
	}
	public float getPercentageAbsolute() {
		return percentageAbsolute;
	}
	public void setPercentageAbsolute(float percentageAbsolute) {
		this.percentageAbsolute = percentageAbsolute;
	}
	public float getPercentageRelative() {
		return percentageRelative;
	}
	public void setPercentageRelative(float percentageRelative) {
		this.percentageRelative = percentageRelative;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getFuncationDescription() {
		return funcationDescription;
	}
	public void setFuncationDescription(String funcationDescription) {
		this.funcationDescription = funcationDescription;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	
	public long getSelfExecutionTime() {
		return selfExecutionTime;
	}
	public void setSelfExecutionTime(long selfExecutionTime) {
		this.selfExecutionTime = selfExecutionTime;
	}
	@Override
	public String toString() {
		return "NodeValue [level=" + level + ", executionTime=" + executionTime + ", percentageAbsolute="
				+ percentageAbsolute + ", percentageRelative=" + percentageRelative + ", functionName="
				+ functionName + ", funcationDescription=" + funcationDescription +  "]";
	}
}

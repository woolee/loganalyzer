package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.AnalysisDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.AnalysisMapper;

@Repository
public class AnalysisDaoImp<T extends Analysis> implements AnalysisDao<T> {
	
	@Inject
	private AnalysisMapper<T> mapper;
	
	@Override
	public boolean addAnalysis(T entity) throws DataAccessException {
		boolean flag = false;
		try
		{
			mapper.addAnalysis(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Analysis to database",e);
		}
		return flag;
	}

	@Override
	public T getAnalysisById(int id) throws DataAccessException {
		return mapper.getAnalysisById(id);
	}

	@Override
	public T getAnalysisByUUID(String uuid) throws DataAccessException {
		return  mapper.getAnalysisByUUID(uuid);
	}

	@Override
	public List<T> getAnalysis() {
		return mapper.getAnalysis();
	}

	@Override
	public boolean deleteAnalysis(int analysisId) {
		boolean flag = false;
		try
		{
			mapper.deleteAnalysis(analysisId);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while delete Analysis from database",e);
		}
		return flag;
	}

}

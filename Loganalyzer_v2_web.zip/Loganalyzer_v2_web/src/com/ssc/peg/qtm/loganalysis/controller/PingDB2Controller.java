package com.ssc.peg.qtm.loganalysis.controller;

import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.peg.qtm.loganalysis.constants.Constants;
import com.ssc.peg.qtm.loganalysis.db.AFCConnectionFactory;

@Controller
@RequestMapping("ping")
public class PingDB2Controller {
	private Logger logger = Logger.getLogger(this.getClass());
	@RequestMapping("get")
	public void getPingTime(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String from = request.getParameter("datefrom");
		String to = request.getParameter("dateto");
		
		String server = request.getParameter("server");
		String port = request.getParameter("port");
		String db = request.getParameter("db");
		String user = request.getParameter("user");
		String password = request.getParameter("pwd");
		String context = request.getParameter("context");
		
		AFCConnectionFactory.setServer(server.trim());
		AFCConnectionFactory.setPort(port.trim());
		AFCConnectionFactory.setDb(db.trim());
		AFCConnectionFactory.setUser(user.trim());
		AFCConnectionFactory.setPassword(password.trim());
		
		final String PLATFORM_CD = "CLOUD";
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.AFC_LOG_DATA_FORMAT);
		if(from != null && !from.isEmpty() && to != null && !to.isEmpty() ){
			
			String sql = "SELECT " +                       
					"ALDID.TASK_NM,ALDID.START_TS,"+                        
					"ALDID.END_TS,ALDID.TIME_SPENT_NUM "+
					"FROM U1K.AFC_DIAGNOSTICS_INFO ADI "+          
					"LEFT JOIN "+                              
					"U1K.AFC_LOG_DIAGNOSTICS_INFO_DETAILS ALDID "+ 
					"ON ADI.UUID = ALDID.UUID "+
					"WHERE ADI.PLATFORM_CD = '"+PLATFORM_CD + "' "+            
					"AND ADI.CONTEXT_NM = '"+context+"' AND ALDID.START_TS >= '"+from+"' AND ALDID.END_TS <= '"+to+"' "
					+"AND ALDID.TASK_NM='Ping db2'";
			
			response.setContentType("text/csv");
		    response.setHeader("Content-Disposition", "attachment; filename=\"ping.csv\"");
		    StringBuilder resultOutput = new StringBuilder();
		    resultOutput.append("TASK_NM,START_TS,TIME_SPENT_NUM\n");
			//get the all request UUID form DB2
			Connection conn = AFCConnectionFactory.getConnection();
			PreparedStatement ptst;
			try {
				ptst = conn.prepareStatement(sql);
				logger.info("Execute SQL:" + sql );
				ptst.setFetchSize(500);

				ResultSet rs = ptst.executeQuery();
				while(rs.next()){
					String funcDesc = rs.getString("TASK_NM");
					Date startTime= rs.getDate("START_TS");
					long execuTime = rs.getLong("TIME_SPENT_NUM");
					resultOutput.append(funcDesc+","+dateFormat.format(startTime)+","+execuTime+"\n");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try
		    {
		        OutputStream outputStream = response.getOutputStream();
		        outputStream.write(resultOutput.toString().getBytes());
		        outputStream.flush();
		        outputStream.close();
		    }
		    catch(Exception e)
		    {
		    	throw e;
		    }
		}
	}
}

package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.ServiceStatisticsDao;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.ServiceStatisticsMapper;

@Repository
public class ServiceStatisticsDaoImp<T extends ServiceStatistics > implements ServiceStatisticsDao<T>{
	
	@Inject
	private ServiceStatisticsMapper<T> mapper;
	@Override
	public boolean addServiceStatistics(T entity)
	{
		boolean flag = false;
		try
		{
			mapper.addServiceStatistics(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add ServiceStatistics to database",e);
		}
		return flag;
	};
	@Override
	public boolean addServiceStatisticsList(List<T> list)
	{
		boolean flag = false;
		try
		{
			mapper.addServiceStatisticsList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add ServiceStatistics to database",e);
		}
		return flag;
	}
	@Override
	public List<T> getServiceStatisListByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getServiceStatisListByAnalysisId(analysisId);
	};

}

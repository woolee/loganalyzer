package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsDao;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.FunctionStatisticsMapper;

@Repository
public class FunctionStatisticsDaoImp<T extends FunctionStatistics> implements FunctionStatisticsDao<T> {

	@Inject
	private FunctionStatisticsMapper<T> mapper;
	
	@Override
	public boolean addFunctionStatistics(T entity) {
		boolean flag = false;
		try
		{
			mapper.addFunctionStatistics(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add FunctionStatistics to database",e);
		}
		return flag;
	}

	@Override
	public T getFunctionStaById(int id) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaById(id);
	}

	@Override
	public T getFunctionStaByFunctionId(int functionId) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaByFunctionId(functionId);
	}

	@Override
	public boolean addFunctionStatisticsList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addFunctionStatisticsList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add FunctionStatistics list to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getFunctionStaByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getFunctionStaByAnalysisId(analysisId);
	}

}

package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;
import java.util.Map;

import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;

public interface FunctionService<T> {
	public Map<Integer,Function> getFunctionListByServiceFunction(List<ServiceFunction> serviceFunctionList);
	public Map<Integer,Function> getFunctionListByFunctionStatistic(List<FunctionStatistics> funcStatisList);
}

package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class ServiceStatistics implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3929314849564823635L;
	private int statisticsId;
	private long maxTime;
	private long minTime;
	private float avgTime;
	private long nintyTime;
	private float avgTps;
	private int count;
	private int analysisId;
	private int serviceId;
	public long getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(long maxTime) {
		this.maxTime = maxTime;
	}
	public long getMinTime() {
		return minTime;
	}
	public void setMinTime(long minTime) {
		this.minTime = minTime;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getStatisticsId() {
		return statisticsId;
	}
	public void setStatisticsId(int statisticsId) {
		this.statisticsId = statisticsId;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public long getNintyTime() {
		return nintyTime;
	}
	public void setNintyTime(long nintyTime) {
		this.nintyTime = nintyTime;
	}
	public float getAvgTps() {
		return avgTps;
	}
	public void setAvgTps(float avgTps) {
		this.avgTps = avgTps;
	}
	
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;


public interface FuncTimeTopNDao<T> {
	public boolean addFuncTimeTopN(T entity);
	public boolean addFuncTimeTopNList(List<T> list);
	public List<T> getTopNByFunctionServiceId(int functionId,int serviceId,int analysisId);
}

package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;

import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;

public interface TreeService<T> {
	public T getTreeById(int id);
	public List<T> getMergeTreeForService(int analysisId,int serviceId,boolean isMerged,boolean isAllStructure);
	public List<T> getTreeListByServiceTopN(List<ServiceTopN> serviceTopNList);
	public int getCountOfMergeTreeForService(int analysisId,int serviceId,boolean isMerged,boolean isAllStructure);
	public List<T> getMergeTreeForServiceMerge(int analysisId,int serviceId,boolean isMerged,boolean isAllStructure);
	public T getTreeByRequestId(String requestId);
	
}

package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class NodeValue implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -9052041932989606661L;
	private int valueId;
	private String level;
	private long executionTime;
	private int functionId;
//	private int nodeId;
	private String nodeUUID;
	private long selfExcutionTime;
	private float ablRatio;
	private float relRatio;
	public int getValueId() {
		return valueId;
	}
	public void setValueId(int valueId) {
		this.valueId = valueId;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public long getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(long executionTime) {
		this.executionTime = executionTime;
	}
//	public int getNodeId() {
//		return nodeId;
//	}
//	public void setNodeId(int nodeId) {
//		this.nodeId = nodeId;
//	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public long getSelfExcutionTime() {
		return selfExcutionTime;
	}
	public void setSelfExcutionTime(long selfExcutionTime) {
		this.selfExcutionTime = selfExcutionTime;
	}
	public float getAblRatio() {
		return ablRatio;
	}
	public void setAblRatio(float ablRatio) {
		this.ablRatio = ablRatio;
	}
	public float getRelRatio() {
		return relRatio;
	}
	public void setRelRatio(float relRatio) {
		this.relRatio = relRatio;
	}
	public String getNodeUUID() {
		return nodeUUID;
	}
	public void setNodeUUID(String nodeUUID) {
		this.nodeUUID = nodeUUID;
	}
	
}

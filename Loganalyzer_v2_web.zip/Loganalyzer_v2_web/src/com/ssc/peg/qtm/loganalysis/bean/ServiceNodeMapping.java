package com.ssc.peg.qtm.loganalysis.bean;

import java.util.Map;

public class ServiceNodeMapping {
	private Map<ServiceNode,ServiceNodeValue> nodeMappingMap;

	public Map<ServiceNode, ServiceNodeValue> getNodeMappingMap() {
		return nodeMappingMap;
	}

	public void setNodeMappingMap(Map<ServiceNode, ServiceNodeValue> nodeMappingMap) {
		this.nodeMappingMap = nodeMappingMap;
	}
	
}

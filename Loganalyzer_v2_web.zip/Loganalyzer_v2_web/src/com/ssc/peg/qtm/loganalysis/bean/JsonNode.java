package com.ssc.peg.qtm.loganalysis.bean;

import java.util.List;

public class JsonNode {
	private List<JsonNode> nodeChildren;
	private String nodeName;
	private String nodeLevel;
	private JsonNode parentNode;
	private int deep;
	public String getNodeLevel() {
		return nodeLevel;
	}
	public void setNodeLevel(String nodeLevel) {
		this.nodeLevel = nodeLevel;
	}
	public List<JsonNode> getNodeChildren() {
		return nodeChildren;
	}
	public void setNodeChildren(List<JsonNode> nodeChildren) {
		this.nodeChildren = nodeChildren;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	
	public JsonNode getParentNode() {
		return parentNode;
	}
	public void setParentNode(JsonNode parentNode) {
		this.parentNode = parentNode;
	}
	public int getDeep() {
		return deep;
	}
	public void setDeep(int deep) {
		this.deep = deep;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "JsonNode=[nodeName="+ nodeName + ", nodeLevel=" + nodeLevel + ", nodeChildren=" + nodeChildren + ",parentNode=" + parentNode + ",deep=" + deep +"]";
	}
	
	
}

package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;
import java.util.concurrent.BlockingQueue;

import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;

public interface AnalysisService<T> {
	public List<T> getAnalysis();
//	public Analysis saveToAll(String analysisName,String uuid,BlockingQueue<FunctionStatisticsTree> funcStatisIntree) throws Exception;
	public boolean deleteAnalysis(int analysisId);
	public List<T> getAnalysisList(List<Integer> analysisIdList);
}

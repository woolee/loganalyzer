package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

public class FuncTimeTopN implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3310407859226620964L;
	private int id;
	private int functionId;
	private int serviceId;
//	private int treeId;
	private String treeUUID;
	private int analysisId;
	private float executionTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
//	public int getTreeId() {
//		return treeId;
//	}
//	public void setTreeId(int treeId) {
//		this.treeId = treeId;
//	}
	public String getTreeUUID() {
		return treeUUID;
	}
	public void setTreeUUID(String treeUUID) {
		this.treeUUID = treeUUID;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	public float getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(float executionTime) {
		this.executionTime = executionTime;
	}
	
}

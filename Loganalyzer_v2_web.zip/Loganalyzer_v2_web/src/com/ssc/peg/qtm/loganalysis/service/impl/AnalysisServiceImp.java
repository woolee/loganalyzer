package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.analysis.IDFData;
import com.ssc.peg.qtm.loganalysis.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceFunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceMergeTree;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TPSResponseTime;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;
import com.ssc.peg.qtm.loganalysis.concurrent.SqlProcessorManager;
import com.ssc.peg.qtm.loganalysis.dao.AnalysisDao;
import com.ssc.peg.qtm.loganalysis.dao.FuncRatioTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FuncTimeTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsTreeDao;
import com.ssc.peg.qtm.loganalysis.dao.PointDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceFunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceStatisticsDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncRatioTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncTimeTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;
import com.ssc.peg.qtm.loganalysis.db.bean.Node;
import com.ssc.peg.qtm.loganalysis.db.bean.NodeValue;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.AnalysisService;
@org.springframework.stereotype.Service
public class AnalysisServiceImp<T extends Analysis> implements AnalysisService<T> {

	@Inject
	private AnalysisDao<Analysis> dao;
	
	
	Logger logger = Logger.getLogger(getClass());


	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAnalysis() {
		return (List<T>) dao.getAnalysis();
	}
	

	@Override
	public boolean deleteAnalysis(int analysisId) {
		// TODO Auto-generated method stub
		return dao.deleteAnalysis(analysisId);
	}

	@Override
	public List<T> getAnalysisList(List<Integer> analysisIdList) {
		// TODO Auto-generated method stub
		List<T> list = new ArrayList<T>();
		for (Integer id : analysisIdList) {
			list.add((T)dao.getAnalysisById(id));
		}
		return list;
	}
}

package com.ssc.peg.qtm.loganalysis.service.impl;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.transaction.annotation.Transactional;


import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.ssc.peg.qtm.loganalysis.bean.JsonNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.dao.FuncRatioTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FuncTimeTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceFunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncRatioTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncTimeTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.JsonService;
@org.springframework.stereotype.Service
public class JsonServiceImp implements JsonService{

	@Inject
	private FunctionDao<Function> funcDao;
	
	@Inject
	private ServiceFunctionDao<ServiceFunction> functionStatisInIDFDao;
	
	@Inject
	private ServiceDao<Service> servDao;
	
	@Inject
	private FuncRatioTopNDao<FuncRatioTopN> funcRatioDao;
	
	@Inject
	private TreeDao<Tree> treeDao;
	
	@Inject
	private FuncTimeTopNDao<FuncTimeTopN> funcTimeDao;
	
	@Override
	@Transactional
	public List<List> getFunctionRatioInService(int functionId, int analysisId) {
		Function function = funcDao.getFunctionById(functionId);
		String functionName = function.getFunctionName() + " - " + function.getFunctionDescription();
		List<String> functionnamelist = new ArrayList<String>();
		functionnamelist.add(functionName);
		List<String> strlist_idfnumber = new ArrayList<String>();
		List<Float> strlist_percentageabs = new ArrayList<Float>();
		List<Float> strlist_selfpercentageabs = new ArrayList<Float>();
		List<Float> strlist_childpercentageabs = new ArrayList<Float>();
		List<Float> strlist_totalavgTime = new ArrayList<Float>();
		List<Float> strlist_selfavgTime = new ArrayList<Float>();
		List<Float> strlist_childrenavgTime = new ArrayList<Float>();
		List<Integer> function_id_list = new ArrayList<Integer>();
		List<Integer> service_id_list = new ArrayList<Integer>();
		List<List> idfnumber_and_percentage = new ArrayList<List>();
		
		List<ServiceFunction> functStatisInService = functionStatisInIDFDao.getServiceFuncByFunctionAnalysisId(analysisId, functionId);
//		Set<Service> serviceList = new HashSet<Service>();
		for(ServiceFunction functionInService : functStatisInService){
			//too many operations of get service id
			Service service = servDao.getServiceById(functionInService.getServiceId()); 
			strlist_idfnumber.add(service.getServiceName());
//			serviceList.add(service);
			strlist_percentageabs.add( functionInService.getRatio()*100);
			strlist_selfpercentageabs.add( functionInService.getSelfRatio()*100);
			System.out.println("(functionInService.getRatio()-functionInService.getSelfRatio())*100=" + (functionInService.getRatio()-functionInService.getSelfRatio())*100);
			strlist_childpercentageabs.add( (functionInService.getRatio()-functionInService.getSelfRatio())*100);
			strlist_totalavgTime.add(functionInService.getAvgTime()/1000000);
			strlist_selfavgTime.add(functionInService.getSelfAvgTime()/1000000);
			strlist_childrenavgTime.add((functionInService.getAvgTime()-functionInService.getSelfAvgTime())/1000000);
			function_id_list.add(functionInService.getFunctionId());
			service_id_list.add(functionInService.getServiceId());
		}
		
		idfnumber_and_percentage.add(0, strlist_idfnumber);
		idfnumber_and_percentage.add(1, strlist_percentageabs);
		idfnumber_and_percentage.add(2, functionnamelist);
		idfnumber_and_percentage.add(3, strlist_selfpercentageabs);
		idfnumber_and_percentage.add(4, strlist_childpercentageabs);
		idfnumber_and_percentage.add(5, strlist_totalavgTime);
		idfnumber_and_percentage.add(6, strlist_selfavgTime);
		idfnumber_and_percentage.add(7, strlist_childrenavgTime);
		idfnumber_and_percentage.add(8, function_id_list);
		idfnumber_and_percentage.add(9, service_id_list);
		return idfnumber_and_percentage;
	}
	@Override
	@Transactional
	public List<List> getFuncRatioTopN(int functionId, int analysisId,
			String serviceName) {
		List<String> requestid = new ArrayList<String>();
		List<Float> requestpercentage = new ArrayList<Float>();//function percentage in request
		List<List> top5request = new ArrayList<List>();
		
		int serviceId = servDao.getServiceByName(serviceName).getServiceId();
		List<FuncRatioTopN>  funcRatioTopNInService = funcRatioDao.getTopNByFunctionServiceId(functionId, serviceId,analysisId);
		
		for (FuncRatioTopN funcRatioTopN : funcRatioTopNInService) {
			Tree topNTree = treeDao.getTreeByTreeUUID(funcRatioTopN.getTreeUUID());
			requestid.add(topNTree.getRequestId());
			requestpercentage.add(funcRatioTopN.getRatio()*100);
		}
		top5request.add(0, requestid);
		top5request.add(1, requestpercentage);
		return top5request;
	}
	@Override
	@Transactional
	public List<List> getFuncTimeTopN(int functionId, int analysisId,
			String serviceName) {
		List<String> requestid = new ArrayList<String>();
		List<Float> requesttime = new ArrayList<Float>();//function avgTime in request
		List<List> top5request = new ArrayList<List>();
		
		int serviceId = servDao.getServiceByName(serviceName).getServiceId();
		List<FuncTimeTopN>  funcTimeTopNInService = funcTimeDao.getTopNByFunctionServiceId(functionId, serviceId, analysisId);
		
		for (FuncTimeTopN funcTimeTopN : funcTimeTopNInService) {
			Tree topNTree = treeDao.getTreeByTreeUUID(funcTimeTopN.getTreeUUID());
			requestid.add(topNTree.getRequestId());
			requesttime.add(funcTimeTopN.getExecutionTime()/1000000);
		}
		top5request.add(0, requestid);
		top5request.add(1, requesttime);
		return top5request;
	}

	
	@Override
	@Transactional
	public void saveAsjsonNodeByAnaly(Map<Integer,Map<JsonNode,ServiceNodeStatistics>> jsonMapByAnaly,Map<Integer,JsonNode> rootNodeByAnaly,List<Analysis> analysisList,int serviceId){
for (Analysis analysis : analysisList) {
			
			Tree tree = treeDao.getMergeTreeForServiceMerge(analysis.getAnalysisId(), serviceId, true, true).get(0);
			String str = new String(tree.getTreeStructure());
			
			JsonParser parser = new JsonParser();
			JsonElement jsonE = parser.parse(str);
		    JsonObject json = jsonE.getAsJsonObject();
		    
		    JsonNode rootNode = new JsonNode();
		    ServiceNodeStatistics rootNodeStat = new ServiceNodeStatistics();
		    rootNodeByAnaly.put(analysis.getAnalysisId(), rootNode);
		    
		    Map<JsonNode,ServiceNodeStatistics> jsonMap = new HashMap<JsonNode,ServiceNodeStatistics>();
		    jsonMap.put(rootNode, rootNodeStat);
		    jsonMapByAnaly.put(analysis.getAnalysisId(), jsonMap);
		    
		    String name = json.get("name").getAsString();
		    float avgTime = json.get("avg_time").getAsFloat()*1000000;
		    float selfAvgTime = json.get("self_avg_time").getAsFloat()*100000;
		    long minTime = (long) (json.get("min_time").getAsFloat()*1000000);
		    long maxTime = (long) (json.get("max_time").getAsFloat()*1000000);
		    int count = json.get("count").getAsInt();
		    float percentageAbl = json.get("abl_ratio").getAsFloat();
		    float percentageRel = json.get("rel_ratio").getAsFloat();
		    float selfPercentageAbl = json.get("self_abl_ratio").getAsFloat();
		    float totalSelfTime = json.get("total_self_time").getAsFloat()*1000000;
		    float totalTime = json.get("total_time").getAsFloat()*1000000;
		    
		    JsonElement childrenEle = json.get("children");
		    
		    rootNode.setNodeName(name);
		    rootNode.setNodeLevel("0");
		    rootNode.setDeep(0);
		    rootNodeStat.setAvgTime(avgTime);
		    rootNodeStat.setSelfAvgTime(selfAvgTime);
		    rootNodeStat.setMinTime(minTime);
		    rootNodeStat.setMaxTime(maxTime);
		    rootNodeStat.setCount(count);
		    rootNodeStat.setPercentageAbl(percentageAbl);
		    rootNodeStat.setPercentageRel(percentageRel);
		    rootNodeStat.setSelfPercentageAbl(selfPercentageAbl);
		    rootNodeStat.setTotalSelfTime(totalSelfTime);
		    rootNodeStat.setTotalTime(totalTime);
		    
//		    String c = b.substring(1,b.length() - 1);
//		    System.out.println(c);
		    if(childrenEle != null && !"".equals(childrenEle.toString())){
		    	JsonReader reader = new JsonReader(new StringReader(childrenEle.toString()));
				reader.setLenient(true);
				
				List<Map<String, Object>> childList = new Gson().fromJson(reader, new TypeToken<List>() {}.getType());
		    	combineJsonTree(jsonMap, rootNode, childList);
		    }
		    
		}
	}
	
	private void combineJsonTree(Map<JsonNode,ServiceNodeStatistics> jsonMap, JsonNode parentNode,List<Map<String, Object>> childList){
//		JsonReader reader = new JsonReader(new StringReader(children));
//		reader.setLenient(true);
//		
//		List<Map<String, Object>> childList = new Gson().fromJson(reader, new TypeToken<List>() {}.getType());
		for (int i = 0; i < childList.size(); i++) {
			
    		JsonNode node = new JsonNode();
    		ServiceNodeStatistics nodeStat = new ServiceNodeStatistics();
    		jsonMap.put(node, nodeStat);
    		
    		if(parentNode.getNodeChildren() != null){
    			parentNode.getNodeChildren().add(node);
    		}else{
    			List<JsonNode> childrenNode = new ArrayList<JsonNode>();
    			childrenNode.add(node);
    			parentNode.setNodeChildren(childrenNode);
    		}
    		if("0".equals(parentNode.getNodeLevel())){
    			node.setNodeLevel(""+(i+1));
    		}
    		else{
    			node.setNodeLevel(parentNode.getNodeLevel() + "." + (i+1));
    		}
    		node.setDeep(parentNode.getDeep()+1);
    		node.setParentNode(parentNode);
    		node.setNodeName(childList.get(i).get("name").toString());
    		nodeStat.setAvgTime(Float.parseFloat(childList.get(i).get("avg_time").toString())*1000000);
    		nodeStat.setSelfAvgTime(Float.parseFloat(childList.get(i).get("self_avg_time").toString())*1000000);
    		nodeStat.setMinTime((long)(Float.parseFloat(childList.get(i).get("min_time").toString())*1000000));
    		nodeStat.setMaxTime((long)(Float.parseFloat(childList.get(i).get("max_time").toString())*1000000));
    		nodeStat.setCount(Integer.parseInt(childList.get(i).get("count").toString()));
    		nodeStat.setPercentageAbl(Float.parseFloat(childList.get(i).get("abl_ratio").toString()));
    		nodeStat.setPercentageRel(Float.parseFloat(childList.get(i).get("rel_ratio").toString()));
    		nodeStat.setSelfPercentageAbl(Float.parseFloat(childList.get(i).get("self_abl_ratio").toString()));
    		nodeStat.setTotalSelfTime(Float.parseFloat(childList.get(i).get("total_self_time").toString())*1000000);
    		nodeStat.setTotalTime(Float.parseFloat(childList.get(i).get("total_time").toString())*1000000);
    		
    		if(childList.get(i).get("children") != null){
    			combineJsonTree(jsonMap, node, (List)childList.get(i).get("children"));  
    		}
    	}
	}
}

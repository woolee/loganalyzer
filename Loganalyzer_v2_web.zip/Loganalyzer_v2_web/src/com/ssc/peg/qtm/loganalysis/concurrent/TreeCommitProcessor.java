package com.ssc.peg.qtm.loganalysis.concurrent;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;

public class TreeCommitProcessor implements Runnable {

	private List<Tree> treeList = null;
	private TreeDao<Tree> treeDao ;
	private AtomicBoolean treeCommitFlag;
	public TreeCommitProcessor(List<Tree> treeList,TreeDao<Tree> treeDao) {
		this.treeList = treeList;
		this.treeDao = treeDao;
	}

	public void run() {
		while(true)
		{
				treeDao.addTreeList(treeList);
		}
	}

}
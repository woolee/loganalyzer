package com.ssc.peg.qtm.loganalysis.bean;

/**
 * The class is entity class which contains function statistics information.
 * @author a549324
 *
 */
public class FunctionStatistics {
	private float score;
	private long maxTime;
	private long minTime;
	private float avgTime;
	private int count;
	private float ratio;
	private float nintyTime;
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public long getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(long maxTime) {
		this.maxTime = maxTime;
	}
	public long getMinTime() {
		return minTime;
	}
	public void setMinTime(long minTime) {
		this.minTime = minTime;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public float getNintyTime() {
		return nintyTime;
	}
	public void setNintyTime(float nintyTime) {
		this.nintyTime = nintyTime;
	}
	@Override
	public String toString() {
		return "FunctionStatistics [score=" + score + ", maxTime=" + maxTime + ",minTime=" + minTime + ", avgTime="
				+ avgTime + ", count=" + count + ", ratio="
				+ ratio  +"]";
	}
}

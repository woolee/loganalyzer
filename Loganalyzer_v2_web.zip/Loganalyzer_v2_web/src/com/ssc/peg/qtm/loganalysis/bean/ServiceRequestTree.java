package com.ssc.peg.qtm.loganalysis.bean;

import java.util.Map;



public class ServiceRequestTree {
	private int treeId;
	private String requestId;
	private String threadName;
	private String entityName;
	private String criteria;
	private String idfNumber;
	private String callerId;
	private String certificateID;
	private String clientRequestId;
	private int functionHashcode;
	private long startTime;
	private long endTime;
	private int mergeTreeCount;
	private int recordSequenceId;
	private ServiceNode rootNode;
	private ServiceNodeMapping nodeMapping;
	private Map<String,FunctionStatistics> functionStatistics;
	public String getClientRequestId() {
		return clientRequestId;
	}

	public void setClientRequestId(String clientRequestId) {
		this.clientRequestId = clientRequestId;
	}


	public String getIdfNumber() {
		return idfNumber;
	}

	public int getRecordSequenceId() {
		return recordSequenceId;
	}

	public void setRecordSequenceId(int recordSequenceId) {
		this.recordSequenceId = recordSequenceId;
	}

	public void setIdfNumber(String idfNumber) {
		this.idfNumber = idfNumber;
	}


	public int getTreeId() {
		return treeId;
	}

	public void setTreeId(int treeId) {
		this.treeId = treeId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getThreadName() {
		return threadName;
	}

	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public String getCallerId() {
		return callerId;
	}

	public void setCallerId(String callerId) {
		this.callerId = callerId;
	}

	public String getCertificateID() {
		return certificateID;
	}

	public void setCertificateID(String certificateID) {
		this.certificateID = certificateID;
	}

	public ServiceNode getRootNode() {
		return rootNode;
	}

	public void setRootNode(ServiceNode rootNode) {
		this.rootNode = rootNode;
	}

	public ServiceNodeMapping getNodeMapping() {
		return nodeMapping;
	}

	public void setNodeMapping(ServiceNodeMapping nodeMapping) {
		this.nodeMapping = nodeMapping;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public int getFunctionHashcode() {
		return functionHashcode;
	}

	public void setFunctionHashcode(int functionHashcode) {
		this.functionHashcode = functionHashcode;
	}

	public int getMergeTreeCount() {
		return mergeTreeCount;
	}

	public void setMergeTreeCount(int mergeTreeCount) {
		this.mergeTreeCount = mergeTreeCount;
	}

	public Map<String, FunctionStatistics> getFunctionStatistics() {
		return functionStatistics;
	}

	public void setFunctionStatistics(
			Map<String, FunctionStatistics> functionStatistics) {
		this.functionStatistics = functionStatistics;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "tree[rootNode="+ rootNode+"]";
	}


	
}

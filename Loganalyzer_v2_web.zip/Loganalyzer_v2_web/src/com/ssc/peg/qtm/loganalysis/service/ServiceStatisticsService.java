package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;


public interface ServiceStatisticsService<T> {
	public List<T> getServiceStatisListByAnalysisId(int analysisId);
}

package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class FunctionStatistics implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8164607098638232859L;
	private int statisticsId;
	private float score;
	private float maxTime;
	private float minTime;
	private float avgTime;
	private int count;
	private int functionId;
	private float ratio;
	private int analysisId;
	private float nintyTime;
	public int getStatisticsId() {
		return statisticsId;
	}
	public void setStatisticsId(int statisticsId) {
		this.statisticsId = statisticsId;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public float getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(float maxTime) {
		this.maxTime = maxTime;
	}
	public float getMinTime() {
		return minTime;
	}
	public void setMinTime(float minTime) {
		this.minTime = minTime;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	public float getNintyTime() {
		return nintyTime;
	}
	public void setNintyTime(float nintyTime) {
		this.nintyTime = nintyTime;
	}
	@Override
	public String toString(){
		return "FunctionStatistics[score="+ score + ", maxTime=" + maxTime + ",minTime= " + minTime + ", avgTime=" + avgTime + ", ratio=" + ratio + ", nintyTime= " + nintyTime + "]";
	}
}

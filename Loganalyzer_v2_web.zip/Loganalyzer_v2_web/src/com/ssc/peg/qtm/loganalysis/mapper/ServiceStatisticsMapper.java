package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;


public interface ServiceStatisticsMapper<T> extends SqlMapper {
	public void addServiceStatistics(T entity);
	public void addServiceStatisticsList(List<T> list);
	public List<T> getServiceStatisListByAnalysisId(int analysisId);
	
}

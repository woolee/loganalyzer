package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.NodeValueDao;
import com.ssc.peg.qtm.loganalysis.db.bean.NodeValue;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.NodeValueMapper;

@Repository
public class NodeValueDaoImp<T extends NodeValue> implements NodeValueDao<T> {

	@Inject
	private NodeValueMapper<T> mapper;
	
	@Override
	public boolean addNodeValue(T entity) {
		boolean flag = false;
		try
		{
			mapper.addNodeValue(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add NodeValue to database",e);
		}
		return flag;
	}

	@Override
	public T getNodeValueByValueId(int valueId) {
		// TODO Auto-generated method stub
		return  mapper.getNodeValueByValueId(valueId);
	}

	@Override
	public T getNodeValueByNodeUUID(String uuid) {
		// TODO Auto-generated method stub
		return mapper.getNodeValueByNodeUUID(uuid);
	}

	@Override
	public boolean addNodeValueList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addNodeValueList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add NodeValue list to database",e);
		}
		return flag;
	}

}

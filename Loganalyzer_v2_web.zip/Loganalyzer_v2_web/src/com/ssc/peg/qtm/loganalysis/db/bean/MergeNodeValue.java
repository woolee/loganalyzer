package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class MergeNodeValue implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6990805251164653120L;
	private int valueId;
	private String nodeLevel;
	private int functionId;
	private float maxTime;
	private float avgTime;
	private float minTime;
	private int count;
	private float ablPercentage;
	private float relativePercentage;
//	private int nodeId;
	private String nodeUUID;
	public float getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(float maxTime) {
		this.maxTime = maxTime;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	public float getMinTime() {
		return minTime;
	}
	public void setMinTime(float minTime) {
		this.minTime = minTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getAblPercentage() {
		return ablPercentage;
	}
	public void setAblPercentage(float ablPercentage) {
		this.ablPercentage = ablPercentage;
	}
	public float getRelativePercentage() {
		return relativePercentage;
	}
	public void setRelativePercentage(float relativePercentage) {
		this.relativePercentage = relativePercentage;
	}
//	public int getNodeId() {
//		return nodeId;
//	}
//	public void setNodeId(int nodeId) {
//		this.nodeId = nodeId;
//	}
	public int getValueId() {
		return valueId;
	}
	public void setValueId(int valueId) {
		this.valueId = valueId;
	}
	public String getNodeLevel() {
		return nodeLevel;
	}
	public void setNodeLevel(String nodeLevel) {
		this.nodeLevel = nodeLevel;
	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public String getNodeUUID() {
		return nodeUUID;
	}
	public void setNodeUUID(String nodeUUID) {
		this.nodeUUID = nodeUUID;
	}
}

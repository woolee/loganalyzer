package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.analysis.IDFData;
import com.ssc.peg.qtm.loganalysis.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceFunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceMergeTree;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TPSResponseTime;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;
import com.ssc.peg.qtm.loganalysis.concurrent.SqlProcessorManager;
import com.ssc.peg.qtm.loganalysis.dao.AnalysisDao;
import com.ssc.peg.qtm.loganalysis.dao.FuncRatioTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FuncTimeTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsDao;
import com.ssc.peg.qtm.loganalysis.dao.FunctionStatisticsTreeDao;
import com.ssc.peg.qtm.loganalysis.dao.PointDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceFunctionDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceStatisticsDao;
import com.ssc.peg.qtm.loganalysis.dao.ServiceTopNDao;
import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncRatioTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncTimeTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;
import com.ssc.peg.qtm.loganalysis.db.bean.Node;
import com.ssc.peg.qtm.loganalysis.db.bean.NodeValue;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.ResultStoreService;

@org.springframework.stereotype.Service
public class ResultStoreServiceImp implements ResultStoreService{
	private BlockingQueue<FunctionStatisticsTree> funcStatisQueue;
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private AnalysisDao<Analysis> dao;
	@Inject
	private TreeDao<Tree> treeDao;
	@Inject
	private FunctionDao<Function> functionDao;
	@Inject
	private ServiceDao<Service> servDao;
	@Inject
	private PointDao<Point> pointDao;
	@Inject
	private FunctionStatisticsDao<com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics> fsDao;
	@Inject
	private ServiceFunctionDao<ServiceFunction> serviceFuncDao;
	@Inject
	private ServiceTopNDao<ServiceTopN> serviceTopNDao;
	@Inject
	private FuncRatioTopNDao<FuncRatioTopN> funcRatioTopNDao;
	@Inject
	private FuncTimeTopNDao<FuncTimeTopN> funcTimeTopNDao;
	@Inject
	private FunctionStatisticsTreeDao<FunctionStatisticsTree> fucStatisTreeDao;
	@Inject
	private ServiceStatisticsDao<ServiceStatistics> servStatisDao;
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Analysis saveToAll(String analysisName,String uuid,BlockingQueue<FunctionStatisticsTree> funcStatisQueue) throws Exception
	{
		this.funcStatisQueue = funcStatisQueue;
		Map<String,Function> functionDBMap = new HashMap<String,Function>();
		Map<String,Service> serviceDBMap = new HashMap<String,Service>();
		
		
		Analysis analysis = new Analysis();
		analysis.setAnalysisName(analysisName);
		analysis.setAnalysisUUID(uuid);
		dao.addAnalysis( analysis);
//		analysis = dao.getAnalysisByUUID(uuid);
		
		//The method must execute first
		saveInvertedTree(analysis,functionDBMap, serviceDBMap);
		
		AtomicBoolean processorFinishFlag = new AtomicBoolean(false);
		SqlProcessorManager sqlProcessorManager = new SqlProcessorManager(funcStatisQueue,5, processorFinishFlag,fucStatisTreeDao);
		Thread processorThread = new Thread(sqlProcessorManager);
		processorThread.setName("Function Statistcis in sigle tree thread");
		processorThread.start();
		
		try {
			saveTopNTree(analysis,functionDBMap,serviceDBMap);
			saveTreeFunctionRatioTopNInIdf(analysis,functionDBMap,serviceDBMap);
			saveTreeFunctionTimeTopNInIdf(analysis,functionDBMap,serviceDBMap);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		saveMergeTree(analysis,functionDBMap,serviceDBMap);
		savePonitTPSTime(analysis,serviceDBMap);
		saveFunctionScore(analysis,functionDBMap);
		saveServiceStatistics(analysis,serviceDBMap);
		return analysis;
	}
	
	private void saveServiceStatistics(Analysis analysis,Map<String,Service> serviceDBMap)
	{
		Map<String, IDFData> idfMap = DataMapSelector.selectCommonMap(analysis.getAnalysisUUID()).getIdfMap();
		Set<String> serviceNames = idfMap.keySet();
		List<ServiceStatistics> statisList = new ArrayList<ServiceStatistics>();
		for (String serviceName : serviceNames) {
			IDFData statisticsData = idfMap.get(serviceName);
			ServiceStatistics statistic = new ServiceStatistics();
			statistic.setAnalysisId(analysis.getAnalysisId());
			statistic.setAvgTime(statisticsData.getAvgTime());
			statistic.setMinTime(statisticsData.getMinTime());
			statistic.setMaxTime(statisticsData.getMaxTime());
			statistic.setCount(statisticsData.getCount());
			statistic.setNintyTime(statisticsData.getNintyPercentTime());
			statistic.setAvgTps(statisticsData.getAvgTps());
			int serviceId = serviceDBMap.get(serviceName).getServiceId();
			statistic.setServiceId(serviceId);
			statisList.add(statistic);
		}
		servStatisDao.addServiceStatisticsList(statisList);
		
	}
	
	/**
	 * Converts the ServiceFunctionStatistics class to ServiceFunction class,
	 * save ServiceFunction list to database.
	 * ServiceFunction: the function statistics information in single service.
	 * 
	 * @param analysis
	 * @param functionDBMap
	 * @param serviceDBMap
	 */
	private void saveInvertedTree(Analysis analysis,Map<String,Function> functionDBMap,Map<String,Service> serviceDBMap) {
		logger.info("Start save inverted index request tree");
		ConcurrentHashMap<String, Map<String, ServiceFunctionStatistics>> functionInvertedMap = DataMapSelector.selectConcurrentMap(analysis.getAnalysisUUID()).getInvertedIdfTreeMap();
		List<ServiceFunction> servFuncList = new ArrayList<ServiceFunction>();
		List<Function> addfuncList = new ArrayList<Function>();
		List<Function> existFuncList = functionDao.getFunctionList();
		if(existFuncList.size() != 0)
		{
			for (Function existFunction : existFuncList) {
				String functionName = (existFunction.getFunctionName() + " - " + existFunction.getFunctionDescription()).intern();
				functionDBMap.put(functionName, existFunction);
			}
		}
		for(String function : functionInvertedMap.keySet())
		{
			Function dbFunction = null;
			if(functionDBMap.containsKey(function))
				dbFunction = functionDBMap.get(function);
			else
			{
				dbFunction = new Function();
				int index = function.indexOf(" - ");
				
				String name = (function.substring(0,index)).intern();
				String decription = (function.substring(index + " - ".length())).intern();
				dbFunction.setFunctionName(name);
				dbFunction.setFunctionDescription(decription);
				
				addfuncList.add(dbFunction);
				functionDBMap.put(function, dbFunction);
			}
		}
		
		if(addfuncList.size() != 0)
		{
			logger.info("Add functions to DB");
			functionDao.addFunctionList(addfuncList);
			logger.info("Add functions over!");
			addfuncList = functionDao.getFunctionListByNameAndDescription(addfuncList);
			for (Function function : addfuncList) {
				String functionName = (function.getFunctionName() + " - " + function.getFunctionDescription()).intern();
				functionDBMap.put(functionName, function);
			}
		}
		for(String function : functionInvertedMap.keySet())
		{
			Map<String, ServiceFunctionStatistics> idfStatistcs = functionInvertedMap.get(function);
			int functionId = functionDBMap.get(function).getFunctionId();
			
			for(String idf : idfStatistcs.keySet())
			{
				Service service = null;
				if(serviceDBMap.containsKey(idf))
					service = serviceDBMap.get(idf);
				else
				{
					service = servDao.getServiceByName(idf);
					if(service == null)
					{
						service = new Service();
						service.setServiceName(idf);
						servDao.addService(service);
					}
					serviceDBMap.put(idf, service);
				}
				int serviceId = service.getServiceId();
				ServiceFunctionStatistics sfs = idfStatistcs.get(idf);
				ServiceFunction sf = new ServiceFunction();
				sf.setAnalysisId(analysis.getAnalysisId());
				sf.setAvgTime(sfs.getAvgTimeInIdf());
				sf.setCount(sfs.getCountInIdf());
				sf.setFunctionId(functionId);
				sf.setRatio(sfs.getPercentageByRoot());
				sf.setMaxTime(sfs.getMaxTimeInIdf());
				sf.setMinTime(sfs.getMinTimeInIdf());
				sf.setSelfRatio(sfs.getSelfPercentageByRoot());
				sf.setSelfAvgTime(sfs.getSelfAvgTime());
				sf.setServiceId(serviceId);
				servFuncList.add(sf);
			}
		}
		functionInvertedMap = null;
		serviceFuncDao.addServiceFunctionList(servFuncList);
		servFuncList = null;
	}

	/**
	 * Get the top n trees(the execution time is top n), and save the Table TREE and SERV_TOPN
	 * 
	 * @param analysis
	 * @param functionDBMap
	 * @param serviceDBMap
	 * @throws InterruptedException
	 */
	private void saveTopNTree(Analysis analysis,Map<String,Function> functionDBMap,Map<String,Service> serviceDBMap) throws InterruptedException {
		ConcurrentHashMap<String, List<ServiceRequestTree>> idfTimeTopNTree = DataMapSelector.selectConcurrentMap(analysis.getAnalysisUUID()).getTopNMap();
		List<NodeValue> nodeValueList = new ArrayList<NodeValue>();
		List<Node> nodeList = new ArrayList<Node>();
		List<Tree> treeList = new ArrayList<Tree>();
		List<FunctionStatisticsTree> funcStaticTreeList = new ArrayList<FunctionStatisticsTree>();
		List<ServiceTopN> topNList = new ArrayList<ServiceTopN>();
		for (String idf : idfTimeTopNTree.keySet()) {
			List<ServiceRequestTree> serviceTreeList = idfTimeTopNTree.get(idf);
			for (ServiceRequestTree tree : serviceTreeList) {
				Tree dbTree = saveTree(tree,analysis,functionDBMap,serviceDBMap,nodeValueList,funcStaticTreeList,nodeList);
				treeList.add(dbTree);
				int serviceId = dbTree.getServiceId();
				ServiceTopN topN = new ServiceTopN();
				topN.setServiceId(serviceId);
				topN.setTreeUUID(dbTree.getTreeUUID());
				topN.setAnalysisId(analysis.getAnalysisId());
				topNList.add(topN);
			}
		}
		idfTimeTopNTree = null;
		
		treeDao.addTreeList(treeList);
		treeList = null;
		serviceTopNDao.addServiceTopNList(topNList);
		topNList = null;
		funcStaticTreeList = null;
	}
	
	/**
	 * 
	 * @param tree
	 * @param analysis
	 * @param functionDBMap
	 * @param serviceDBMap
	 * @param nodeValueList
	 * @param funcStaticTreeList
	 * @param nodeList
	 * @return
	 * @throws InterruptedException
	 */
	private Tree saveTree(ServiceRequestTree tree,Analysis analysis,Map<String,Function> functionDBMap,Map<String,Service> serviceDBMap,List<NodeValue> nodeValueList,List<FunctionStatisticsTree> funcStaticTreeList,List<Node> nodeList) throws InterruptedException
	{
		Tree dbTree = null;
		StringBuilder sb = new StringBuilder();
		spliceNode(sb, tree.getRootNode(), tree.getNodeMapping().getNodeMappingMap());
		String serviceName = tree.getIdfNumber();
		Service service = serviceDBMap.get(serviceName);
		dbTree = new Tree();
		dbTree.setAllStructure(false);
		dbTree.setAnalysisId(analysis.getAnalysisId());
		dbTree.setCallerId(tree.getCallerId().intern());
//		dbTree.setCertificateId(tree.getCertificateID().intern());
		dbTree.setEntityName(tree.getEntityName().intern());
		dbTree.setMerged(false);
//		dbTree.setRecordSequenceId(""+tree.getRecordSequenceId());
		dbTree.setRequestId(tree.getRequestId());
		dbTree.setServiceId(service.getServiceId());
		dbTree.setCriteria(tree.getCriteria());
//		dbTree.setThreadName(tree.getThreadName());
		String treeUUID = UUID.randomUUID().toString();
		dbTree.setTreeUUID(treeUUID);
		ServiceNodeValue rootNodeValue = tree.getNodeMapping().getNodeMappingMap().get(tree.getRootNode());
		dbTree.setExecutionTime(rootNodeValue.getExecutionTime());
		dbTree.setTreeStructure(sb.toString().getBytes());
		
		saveFunctonStatisInTree(tree.getFunctionStatistics(),dbTree.getTreeUUID(),analysis.getAnalysisId(),functionDBMap,funcStaticTreeList);
		return dbTree;
	}
	

	/**
	 * 
	 * @param functionStatisticMap
	 * @param treeUUID
	 * @param analysisId
	 * @param functionDBMap
	 * @param funcStaticTreeList
	 * @throws InterruptedException
	 */
	private void saveFunctonStatisInTree(Map<String, FunctionStatistics> functionStatisticMap,String treeUUID,int analysisId,Map<String,Function> functionDBMap,List<FunctionStatisticsTree> funcStaticTreeList) throws InterruptedException
	{
		for(String function : functionStatisticMap.keySet())
		{
			Function dbFunction = functionDBMap.get(function);
			int functionId = dbFunction.getFunctionId();
			FunctionStatistics funcStatistics = functionStatisticMap.get(function);
			FunctionStatisticsTree fst = new FunctionStatisticsTree();
			fst.setAnalysisId(analysisId);
			fst.setTreeUUID(treeUUID);
			fst.setFunctionId(functionId);
			fst.setAvgTime(funcStatistics.getAvgTime());
			fst.setCount(funcStatistics.getCount());
			fst.setMaxTime(funcStatistics.getMaxTime());
			fst.setMinTime(funcStatistics.getMinTime());
			fst.setRatio(funcStatistics.getRatio());
			funcStaticTreeList.add(fst);
			funcStatisQueue.put(fst);
		}
	}
	
	/**
	 * 
	 * @param analysis
	 * @param functionDBMap
	 * @param serviceDBMap
	 * @throws InterruptedException
	 */
	private void saveTreeFunctionRatioTopNInIdf(Analysis analysis,Map<String,Function> functionDBMap,Map<String,Service> serviceDBMap) throws InterruptedException
	{
		ConcurrentHashMap<String, Map<String, List<ServiceRequestTree>>> funcRatioTopNMap = DataMapSelector.selectConcurrentMap(analysis.getAnalysisUUID()).getFunctionRatioTopN();
		List<NodeValue> nodeValueList = new ArrayList<NodeValue>();
		List<FunctionStatisticsTree> funcStaticTreeList = new ArrayList<FunctionStatisticsTree>();
		List<FuncRatioTopN> topNList = new ArrayList<FuncRatioTopN>();
		List<Node> nodeList = new ArrayList<Node>();
		List<Tree> treeList = new ArrayList<Tree>();
//		Set<String> treeRequestIdSet = new HashSet<String>();
		Map<String, Tree> treeMapInRequestId = getExistTrees(analysis.getAnalysisId());
		for(String function : funcRatioTopNMap.keySet())
		{
			int functionId = functionDBMap.get(function).getFunctionId();
			
			Map<String, List<ServiceRequestTree>> idfTreeMap = funcRatioTopNMap.get(function);
			for (String idf : idfTreeMap.keySet()) {
				List<ServiceRequestTree> list = idfTreeMap.get(idf);
				for (ServiceRequestTree tree : list) {
					Tree dbTree = null;
					if(!treeMapInRequestId.containsKey(tree.getRequestId()))
					{
						dbTree = saveTree(tree,analysis,functionDBMap,serviceDBMap,nodeValueList,funcStaticTreeList,nodeList);
						treeList.add(dbTree);
						treeMapInRequestId.put(dbTree.getRequestId(), dbTree);
//						treeRequestIdSet.add(tree.getRequestId());
					}
					else
					{
						dbTree = treeMapInRequestId.get(tree.getRequestId());
					}
					int serviceId = dbTree.getServiceId();
					FuncRatioTopN topN = new FuncRatioTopN();
					topN.setServiceId(serviceId);
					topN.setTreeUUID(dbTree.getTreeUUID());
					topN.setFunctionId(functionId);
					topN.setAnalysisId(analysis.getAnalysisId());
					topN.setRatio(tree.getFunctionStatistics().get(function).getRatio());
					topNList.add(topN);
				}
			}
		}
		
		if(treeList.size() != 0)
			treeDao.addTreeList(treeList);
		treeList = null;
		funcRatioTopNDao.addFuncRatioTopNList(topNList);
		topNList = null;
		funcStaticTreeList = null;
	}
	
	/**
	 * 
	 * @param analysis
	 * @param functionDBMap
	 * @param serviceDBMap
	 * @throws InterruptedException
	 */
	private void saveTreeFunctionTimeTopNInIdf(Analysis analysis,Map<String,Function> functionDBMap,Map<String,Service> serviceDBMap) throws InterruptedException
	{
		ConcurrentHashMap<String, Map<String, List<ServiceRequestTree>>> funcTopNMap = DataMapSelector.selectConcurrentMap(analysis.getAnalysisUUID()).getFunctionTimeTopN();
		List<NodeValue> nodeValueList = new ArrayList<NodeValue>();
		List<FunctionStatisticsTree> funcStaticTreeList = new ArrayList<FunctionStatisticsTree>();
		List<FuncTimeTopN> funcTimeTopNList = new ArrayList<FuncTimeTopN>();
		List<Node> nodeList = new ArrayList<Node>();
		List<Tree> treeList = new ArrayList<Tree>();
//		Set<String> treeRequestIdSet = new HashSet<String>();
		Map<String, Tree> treeMapInRequestId = getExistTrees(analysis.getAnalysisId());
		for(String function : funcTopNMap.keySet())
		{
			int functionId = functionDBMap.get(function).getFunctionId();
			
			Map<String, List<ServiceRequestTree>> idfTreeMap = funcTopNMap.get(function);
			for (String idf : idfTreeMap.keySet()) {
				List<ServiceRequestTree> list = idfTreeMap.get(idf);
				for (ServiceRequestTree tree : list) {
					Tree dbTree = null;
					if(!treeMapInRequestId.containsKey(tree.getRequestId()))
					{
						
						dbTree = saveTree(tree,analysis,functionDBMap,serviceDBMap,nodeValueList, funcStaticTreeList,nodeList);
						treeList.add(dbTree);
						treeMapInRequestId.put(dbTree.getRequestId(), dbTree);
					}
					else
					{
						dbTree = treeMapInRequestId.get(tree.getRequestId());
					}
					int serviceId = dbTree.getServiceId();
					FuncTimeTopN topN = new FuncTimeTopN();
					topN.setServiceId(serviceId);
					topN.setTreeUUID(dbTree.getTreeUUID());
					topN.setFunctionId(functionId);
					topN.setAnalysisId(analysis.getAnalysisId());
					topN.setExecutionTime(tree.getFunctionStatistics().get(function).getAvgTime());
					funcTimeTopNList.add(topN);
				}
			}
		}
		
		if(treeList.size() != 0)
			treeDao.addTreeList(treeList);
		treeList = null;
		funcTimeTopNDao.addFuncTimeTopNList(funcTimeTopNList);
		funcTimeTopNList = null;
		funcStaticTreeList = null;
	}
	
	/**
	 * 
	 * @param analysis
	 * @param functionDBMap
	 */
	private void saveFunctionScore(Analysis analysis,Map<String,Function> functionDBMap)
	{
		Map<String, FunctionStatistics> functionScoreMap = DataMapSelector.selectCommonMap(analysis.getAnalysisUUID()).getFunctionScoreMap();
		List<com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics> funcStatisList = new ArrayList<com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics>();
		for(String function : functionScoreMap.keySet())
		{
			if("com.ssc.afc.common.dataaccess.util.AFCDBConnectionFactory - GenConnectionPool".equals(function))
				System.out.println();
			int functionId = functionDBMap.get(function).getFunctionId();
			FunctionStatistics funcStatistic = functionScoreMap.get(function);
			com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics fs = new com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics();
			fs.setAnalysisId(analysis.getAnalysisId());
			fs.setAvgTime(funcStatistic.getAvgTime());
			fs.setCount(funcStatistic.getCount());
			fs.setMaxTime(funcStatistic.getMaxTime());
			fs.setMinTime(funcStatistic.getMinTime());
			fs.setNintyTime(funcStatistic.getNintyTime());
//			if(funcStatistic.getMinTime() == 0)
//			{
//				System.out.println();
//			}
			fs.setScore(funcStatistic.getScore());
			fs.setFunctionId(functionId);
//			System.out.println(fs);
			funcStatisList.add(fs);
		}
		fsDao.addFunctionStatisticsList(funcStatisList);
		funcStatisList = null;
	}
	
	/**
	 * 
	 * @param analysis
	 * @param serviceDBMap
	 */
	private void savePonitTPSTime(Analysis analysis,Map<String,Service> serviceDBMap)
	{
		Map<Long, Map<String, TPSResponseTime>> pointsMap = DataMapSelector.selectCommonMap(analysis.getAnalysisUUID()).getStatisMap();
		List<Point> pointList = new ArrayList<Point>();
		for (Long time : pointsMap.keySet()) {
			Map<String, TPSResponseTime> idfPoints = pointsMap.get(time);
			for (String idf : idfPoints.keySet()) {
				Service service = serviceDBMap.get(idf);
				Point point = new Point();
				TPSResponseTime tpsTime = idfPoints.get(idf);
				point.setPointTime(new Date(time));
				point.setRespTime(tpsTime.getResponseTime());
				point.setTps(tpsTime.getTps());
				point.setAnalysisId(analysis.getAnalysisId());
				if(service != null)
					point.setServiceId(service.getServiceId());
				pointList.add(point);
//				System.out.println(point);
			}
		}
		if(pointList.size() !=0)
		pointDao.addPointList(pointList);
		pointList = null;
	}
	
	/**
	 * 
	 * @param analysis
	 * @param functionDBMap
	 * @param serviceDBMap
	 */
	private void saveMergeTree(Analysis analysis,Map<String,Function> functionDBMap,Map<String,Service> serviceDBMap) {
		
		 /* save service merge tree map*/
		 
		Map<String, ServiceMergeTree> serviceMergeTreeMap = DataMapSelector.selectCommonMap(analysis.getAnalysisUUID()).getIdfMergeTreeMap();
		Map<String, Map<ServiceNodeValue, ServiceNodeStatistics>> mergeNodeStatisticMap = DataMapSelector.selectCommonMap(analysis.getAnalysisUUID()).getIdgMergeNodeStatisticsMap();
		 
		Set<String> idfNumbers = serviceMergeTreeMap.keySet();
		List<Tree> treeList = new ArrayList<Tree>();
		for (String idfNumber : idfNumbers) {
			
			ServiceMergeTree mergeTree = serviceMergeTreeMap.get(idfNumber);
			ServiceRequestTree allStrcMergeTree = mergeTree.getAllMergeTree();
			StringBuilder strBuilder = new StringBuilder();
			Tree dbAllStrcTree = new Tree();
			spliceMergeNode(strBuilder, allStrcMergeTree.getRootNode(), allStrcMergeTree.getNodeMapping().getNodeMappingMap(), mergeNodeStatisticMap.get(idfNumber));
			
			Service service = serviceDBMap.get(idfNumber);
			
			String treeUUID = UUID.randomUUID().toString();
			dbAllStrcTree.setAnalysisId(analysis.getAnalysisId());
			dbAllStrcTree.setServiceId(service.getServiceId());
			dbAllStrcTree.setMerged(true);
			dbAllStrcTree.setAllStructure(true);
			dbAllStrcTree.setTreeUUID(treeUUID);
			dbAllStrcTree.setTreeStructure(strBuilder.toString().getBytes());
			dbAllStrcTree.setExecutionTime(allStrcMergeTree.getNodeMapping().getNodeMappingMap().get(allStrcMergeTree.getRootNode()).getExecutionTime());
			/* do something
			 * save tree
			 * get tree*/
			treeList.add(dbAllStrcTree);
			strBuilder.setLength(0);
			
			List<ServiceRequestTree> strucTreeList = mergeTree.getStructureMergeTree();
			for (ServiceRequestTree serviceRequestTree : strucTreeList) {
				Tree dbStrcTree = new Tree();
				String treeStrcUUID = UUID.randomUUID().toString();
				dbStrcTree.setAnalysisId(analysis.getAnalysisId());
				
				service = serviceDBMap.get(idfNumber);
				strBuilder = new StringBuilder();
				spliceMergeNode(strBuilder, serviceRequestTree.getRootNode(), serviceRequestTree.getNodeMapping().getNodeMappingMap(), mergeNodeStatisticMap.get(idfNumber));
				dbStrcTree.setServiceId(service.getServiceId());
				dbStrcTree.setMerged(true);
				dbStrcTree.setAllStructure(false);
				dbStrcTree.setTreeUUID(treeStrcUUID);
				dbStrcTree.setTreeStructure(strBuilder.toString().getBytes());
				dbStrcTree.setExecutionTime(serviceRequestTree.getNodeMapping().getNodeMappingMap().get(serviceRequestTree.getRootNode()).getExecutionTime());
				/* * do something
				 * save tree
				 * get tree*/
				treeList.add(dbStrcTree);
				
			}
		}
		if(treeList.size() != 0)
			treeDao.addTreeList(treeList);
		
	}
	
	/**
	 * 
	 * @param sb
	 * @param node
	 * @param map
	 */
	private void spliceNode(StringBuilder sb,ServiceNode node,Map<ServiceNode, ServiceNodeValue> map)
	{
		
		ServiceNodeValue nodeValue = map.get(node);
		sb.append("{");
		sb.append(("\"name\":\"").intern() + (map.get(node).getFunctionName() + " - " + nodeValue.getFuncationDescription() + "\",").intern());
		sb.append(("\"level\":\"").intern() + (nodeValue.getLevel() + "\",").intern());
		sb.append(("\"execution_time\":\"").intern() + nodeValue.getExecutionTime()+ "\",");
		sb.append(("\"self_execution_time\":\"").intern() + nodeValue.getSelfExecutionTime()+ "\",");
		sb.append(("\"abl_ratio\":\"").intern() +nodeValue.getPercentageAbsolute()+ "\",");
		sb.append(("\"rel_ratio\":\"").intern() + nodeValue.getPercentageRelative()+ "\"");
		if(node.getChildrenNode() != null)
		{
			List<ServiceNode> childList = node.getChildrenNode();
			sb.append(",\"children\":[");
			for (int i = 0; i < childList.size(); i++) {
				if(i != 0)
					sb.append(",");
				spliceNode(sb,childList.get(i), map);
			}
			
			sb.append("]");
		}
		sb.append("}");
	}
	
	/**
	 * Converts tree to JSON string
	 * @param sb
	 * @param node
	 * @param map
	 * @param statisMap
	 */
	private void spliceMergeNode(StringBuilder sb,ServiceNode node,Map<ServiceNode, ServiceNodeValue> map,Map<ServiceNodeValue, ServiceNodeStatistics> statisMap)
	{
		
		ServiceNodeValue nodeValue = map.get(node);
		ServiceNodeStatistics nodeStatis = statisMap.get(nodeValue);
		sb.append("{");
		sb.append(("\"name\":\"").intern() + (map.get(node).getFunctionName() + " - " + nodeValue.getFuncationDescription() + "\",").intern());
		sb.append(("\"avg_time\":\"").intern() + nodeStatis.getAvgTime()/Math.pow(10, 6)+ "\",");
		sb.append(("\"self_avg_time\":\"").intern() + nodeStatis.getSelfAvgTime()/Math.pow(10, 6)+ "\",");
		sb.append(("\"min_time\":\"").intern() + nodeStatis.getMinTime()/Math.pow(10, 6)+ "\",");
		sb.append(("\"max_time\":\"").intern() + nodeStatis.getMaxTime()/Math.pow(10, 6)+ "\",");
		sb.append(("\"count\":\"").intern() + nodeStatis.getCount()+ "\",");
		sb.append(("\"total_time\":\"").intern() + nodeStatis.getTotalTime()/Math.pow(10, 6)+ "\",");
		sb.append(("\"total_self_time\":\"").intern() + nodeStatis.getTotalSelfTime()/Math.pow(10, 6)+ "\",");
		sb.append(("\"abl_ratio\":\"").intern() + nodeStatis.getPercentageAbl()+ "\",");
		sb.append(("\"rel_ratio\":\"").intern() + nodeStatis.getPercentageRel()+ "\",");
		sb.append(("\"self_abl_ratio\":\"").intern() + nodeStatis.getSelfPercentageAbl()+ "\"");
		if(node.getChildrenNode() != null)
		{
			List<ServiceNode> childList = node.getChildrenNode();
			sb.append(",\"children\":[");
			for (int i = 0; i < childList.size(); i++) {
				if(i != 0)
					sb.append(",");
				spliceMergeNode(sb,childList.get(i), map,statisMap);
			}
			
			sb.append("]");
		}
		sb.append("}");
	}

	/**
	 * 
	 * @param analysisId
	 * @return
	 */
	private Map<String,Tree> getExistTrees(int analysisId)
	{
		List<Tree> treeList = treeDao.getTreeByAnalysisId(analysisId);
		//tree map -- key:request id
		Map<String,Tree> treeMap = new HashMap<String,Tree>();
		for (Tree tree : treeList) {
			treeMap.put(tree.getRequestId(), tree);
		}
		return treeMap;
	}

}

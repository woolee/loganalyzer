package com.ssc.peg.qtm.loganalysis.service;

import java.util.concurrent.BlockingQueue;

import com.ssc.peg.qtm.loganalysis.db.bean.Analysis;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatisticsTree;

public interface ResultStoreService {
	public Analysis saveToAll(String analysisName,String uuid,BlockingQueue<FunctionStatisticsTree> funcStatisIntree) throws Exception;
}

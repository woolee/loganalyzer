package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.PointDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Point;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.PointMapper;
@Repository
public class PointDaoImp<T extends Point> implements PointDao<T> {

	@Inject
	private PointMapper<T> mapper;
	@Override
	public boolean addPoint(T entity) {
		boolean flag = false;
		try
		{
			mapper.addTPSRespTime(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add TPSRespTime to database",e);
		}
		return flag;
	}

	@Override
	public T getTPSRespTimePoint(int pointId) {
		// TODO Auto-generated method stub
		return mapper.getTPSRespTimePoint(pointId);
	}

	@Override
	public List<T> getTPSRespTimeByAnalysisId(int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getTPSRespTimeByAnalysisId(analysisId);
	}

	@Override
	public boolean addPointList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addPointList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add TPSRespTime to database",e);
		}
		return flag;
		
	}

	@Override
	public List<T> getTPSRespTimeByAnalysisServiceId(int analysisId,
			int serviceId) {
		// TODO Auto-generated method stub
		return mapper.getTPSRespTimeByAnalysisServiceId(analysisId, serviceId);
	}

}

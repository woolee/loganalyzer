package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.dao.ServiceFunctionDao;
import com.ssc.peg.qtm.loganalysis.service.FunctionStatisticsInServService;

@Service
public class FunctionStatisticsInServServiceImp<T extends ServiceFunction> implements FunctionStatisticsInServService<T> {

	@Inject
	private ServiceFunctionDao<T> dao;


	@Override
	public T getServiceFuncByFuncAndService(int analysisId,int serviceId,int functionId) {
		// TODO Auto-generated method stub
		return dao.getServiceFuncByFuncAndService(analysisId,serviceId,functionId);
	}

	@Override
	public List<T> gettopNfunctioninservice(int analysisId,  
			int serviceId, int N) {
		// TODO Auto-generated method stub
		return dao.gettopNfunctioninservice(analysisId,  serviceId, N);
	}

	@Override
	public List<T> getFunctionStatisticBiggerThan(int analysisId, int serviceId,
			float ratio) {
		// TODO Auto-generated method stub
		return dao.getFunctionStatisticBiggerThan(analysisId, serviceId, ratio);
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Map<Integer, List<T>> getFuncStatisMapByRatio(
			int analysisId, float ratio, Set<Integer> serviceIdSet) {
		//key: service id; value: list of function statistics in service 
		Map<Integer,List<T>> functionStatisFilterMap = new HashMap<Integer, List<T>>();
		
		for (Integer serviceId : serviceIdSet) {
			List<T>  functionStatisInService = dao.getFunctionStatisticBiggerThan(analysisId, serviceId, ratio);
			functionStatisFilterMap.put(serviceId, functionStatisInService);
		}
		return functionStatisFilterMap;
	}

}

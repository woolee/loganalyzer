package com.ssc.peg.qtm.loganalysis.util;

import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;

public class NodeUtil {
	public static ServiceNode getRootNode(ServiceNode node)
	{
		ServiceNode rootNode = null;
		if(node.getParentNode() != null)
		{
			rootNode = getRootNode(node.getParentNode());
		}
		else
		{
			rootNode = node;
		}
		return rootNode;
	}
	
	/**
	 * get node parent node,if parent node is null return itself
	 * @param node
	 * @return
	 */
	public static ServiceNode getParentNode(ServiceNode node)
	{
		ServiceNode parentNode = null;
		if(node.getParentNode() != null)
			parentNode = node.getParentNode();
		else 
			parentNode = node;
		return parentNode;
	}
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;


public interface FuncRatioTopNDao<T> {
	public boolean addFuncRatioTopN(T entity);
	public boolean addFuncRatioTopNList(List<T> list);
	public List<T> getTopNByFunctionServiceId(int functionId, int serviceId,int analysisId);

}

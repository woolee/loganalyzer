package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;
import java.util.Map;

import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;


public interface ServService<T> {
	public T getServiceById(int id);
	public T getServiceByName(String name);
	public Map<Integer,Service> getServiceByServiceStatics(List<ServiceStatistics> servStatisList);
}

package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class Tree implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7992496825983275947L;
	private int treeId;
	private int serviceId;
	private String requestId;
	private String entityName;
	private String callerId;
	private String certificateId;
	private String recordSequenceId;
	private int analysisId;
	private String treeUUID;
	private String criteria;
//	private int rootNodeId;
	private String rootNodeUUID;
	private byte[] treeStructure;
	private boolean isMerged;
	private boolean isAllStructure;
	private String threadName;
	private long executionTime;
	private long startTime;
	public int getTreeId() {
		return treeId;
	}
	public void setTreeId(int treeId) {
		this.treeId = treeId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getCallerId() {
		return callerId;
	}
	public void setCallerId(String callerId) {
		this.callerId = callerId;
	}
	public String getCertificateId() {
		return certificateId;
	}
	public void setCertificateId(String certificateId) {
		this.certificateId = certificateId;
	}
	public String getRecordSequenceId() {
		return recordSequenceId;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public void setRecordSequenceId(String recordSequenceId) {
		this.recordSequenceId = recordSequenceId;
	}
	
	public boolean isMerged() {
		return isMerged;
	}
	public void setMerged(boolean isMerged) {
		this.isMerged = isMerged;
	}
	public boolean isAllStructure() {
		return isAllStructure;
	}
	public void setAllStructure(boolean isAllStructure) {
		this.isAllStructure = isAllStructure;
	}
	public String getTreeUUID() {
		return treeUUID;
	}
	public void setTreeUUID(String treeUUID) {
		this.treeUUID = treeUUID;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
//	public int getRootNodeId() {
//		return rootNodeId;
//	}
//	public void setRootNodeId(int rootNodeId) {
//		this.rootNodeId = rootNodeId;
//	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getRootNodeUUID() {
		return rootNodeUUID;
	}
	public void setRootNodeUUID(String rootNodeUUID) {
		this.rootNodeUUID = rootNodeUUID;
	}
	public byte[] getTreeStructure() {
		return treeStructure;
	}
	public void setTreeStructure(byte[] treeStructure) {
		this.treeStructure = treeStructure;
	}
	public String getThreadName() {
		return threadName;
	}
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}
	public long getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(long executionTime) {
		this.executionTime = executionTime;
	}
	public long getStartTime() {
		return startTime;
	}
	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}
	
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface FunctionStatisticsTreeDao<T> {
	public boolean addFunctionStatistics(T entity);
	public T getFunctionStaById(int id);
	public T getFunctionStaByFunctionId(int functionId);
	public T getFunctionStaByTreeUUID(String treeUUID);
	public List<T> getFunctionStaByAnalysisId(int analysisId);
	public boolean addFunctionStatisList(List<T> list);
	public boolean addFunctionStatisListStr(String str);
	public T getFunctionStaByFunctionAndTree(int functionId,String treeUUID);
}

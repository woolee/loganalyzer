package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

public interface NodeMapper <T> extends SqlMapper{
	public void addNode(T entity);
	public T getNodeByNodeId(int nodeId);
	public List<T> getNodeByParentUUID(String parentUUID);
	public T getNodeByUUID(String uuid);
	public void addNodeList(List<T> list);
	public List<T> getNodeListByUUID(List<T> list);
	
}

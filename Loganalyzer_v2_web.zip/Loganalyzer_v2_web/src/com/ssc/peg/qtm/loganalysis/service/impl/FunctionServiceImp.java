package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.dao.FunctionDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Function;
import com.ssc.peg.qtm.loganalysis.db.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceFunction;
import com.ssc.peg.qtm.loganalysis.service.FunctionService;

@Service
public class FunctionServiceImp<T extends Function> implements FunctionService<T> {

	@Inject
	private FunctionDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Map<Integer,Function> getFunctionListByServiceFunction(
			List<ServiceFunction> serviceFunctionList) {
		Map<Integer,Function> functionMap = new HashMap<Integer,Function>();
		for (ServiceFunction serviceFunction : serviceFunctionList) {
			
			functionMap.put(serviceFunction.getFunctionId(),dao.getFunctionById(serviceFunction.getFunctionId()));
		}
		return functionMap;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Map<Integer, Function> getFunctionListByFunctionStatistic(
			List<FunctionStatistics> funcStatisList) {
		Map<Integer,Function> funcMap = new HashMap<Integer, Function>();
		for (FunctionStatistics funcStatis : funcStatisList) {
			Function function = dao.getFunctionById(funcStatis.getFunctionId());
			if(!funcMap.containsKey(function.getFunctionId()))
				funcMap.put(function.getFunctionId(), function);
		}	
		return funcMap;
	}

}

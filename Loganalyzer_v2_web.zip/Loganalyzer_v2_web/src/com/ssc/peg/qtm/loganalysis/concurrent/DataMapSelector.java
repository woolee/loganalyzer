package com.ssc.peg.qtm.loganalysis.concurrent;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import com.ssc.peg.qtm.loganalysis.bean.CommonMap;

public class DataMapSelector {
	private static Map<String,ConcurrentMapManager> concurrentMapSelector = new HashMap<String,ConcurrentMapManager>();
	private static Map<String,CommonMap> commonMapSelector = new HashMap<String,CommonMap>();
	private static Map<String,BlockingQueue> blockingQueueSelector = new HashMap<String,BlockingQueue>();
	public static ConcurrentMapManager selectConcurrentMap(String uuid)
	{
		ConcurrentMapManager manager = concurrentMapSelector.get(uuid);
		if(manager != null)
		{
			return manager;
		}
		else
		{
			manager = new ConcurrentMapManager();
			concurrentMapSelector.put(uuid, manager);
			return manager;
		}
	}
	
	public static CommonMap selectCommonMap(String uuid)
	{
		CommonMap commonMap = commonMapSelector.get(uuid);
		if(commonMap != null)
		{
			return commonMap;
		}
		else
		{
			commonMap = new CommonMap();
			commonMapSelector.put(uuid, commonMap);
			return commonMap;
		}
	}
	
	public static BlockingQueue selectBlockingQueue(String uuid)
	{
		BlockingQueue queue = blockingQueueSelector.get(uuid);
		if(queue != null)
		{
			return queue;
		}
		else
		{
//			queue = new ArrayBlockingQueue(10240);
			queue = new LinkedBlockingQueue(102400);
			blockingQueueSelector.put(uuid, queue);
			return queue;
		}
	}
}

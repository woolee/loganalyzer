package com.ssc.peg.qtm.loganalysis.service;

import java.util.List;

public interface FunctionStatisticsService<T> {
	public T getFunctionStaByFunctionId(int functionId);
	public List<T> getFunctionStaByAnalysisId(int analysisId);
	public List<List> getFunctionRatioInService(int functionId, int analysisId);
	public List<List> getFuncRatioTopN(int functionId,int analysisId,String serviceName);
	public List<List> getFuncTimeTopN(int functionId,int analysisId,String serviceName);
}

package com.ssc.peg.qtm.loganalysis.bean;

import java.io.Serializable;

public class TimePicker implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3416984420579485570L;
	private long dateFrom;
	private long dateTo;
	public long getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(long dateFrom) {
		this.dateFrom = dateFrom;
	}
	public long getDateTo() {
		return dateTo;
	}
	public void setDateTo(long dateTo) {
		this.dateTo = dateTo;
	}
	public TimePicker(long dateFrom,long dateTo)
	{
		this.dateFrom = dateFrom;
		this.dateTo = dateTo;
	}
}

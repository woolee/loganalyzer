package com.ssc.peg.qtm.loganalysis.analysis;

public class IDFData {
	private long maxTime;
	private long minTime;
	private float avgTime;
	private int count;
	private long nintyPercentTime;
	private float avgTps;
	public long getNintyPercentTime() {
		return nintyPercentTime;
	}
	public void setNintyPercentTime(long nintyPercentTime) {
		this.nintyPercentTime = nintyPercentTime;
	}
	public float getAvgTps() {
		return avgTps;
	}
	public void setAvgTps(float avgTps) {
		this.avgTps = avgTps;
	}
	public long getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(long maxTime) {
		this.maxTime = maxTime;
	}
	public long getMinTime() {
		return minTime;
	}
	public void setMinTime(long minTime) {
		this.minTime = minTime;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getAvgTime() {
		return avgTime;
	}
	public void setAvgTime(float avgTime) {
		this.avgTime = avgTime;
	}
	
}

package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.MergeNodeValueDao;
import com.ssc.peg.qtm.loganalysis.db.bean.MergeNodeValue;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.MergeNodeValueMapper;
@Repository
public class MergeNodeValueDaoImp<T extends MergeNodeValue > implements MergeNodeValueDao<T> {

	@Inject
	private MergeNodeValueMapper<T> mapper;
	
	@Override
	public boolean addNodeStatistics(T entity) {
		boolean flag = false;
		try
		{
			mapper.addNodeStatistics(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add MergeNodeValue to database",e);
		}
		return flag;
	}

	@Override
	public T getNodeStatisticsByStatisticsId(int statisticsId) {
		// TODO Auto-generated method stub
		return mapper.getNodeStatisticsByStatisticsId(statisticsId);
	}

	@Override
	public T getNodeStatisticsByNodeUUID(String nodeUUID) {
		// TODO Auto-generated method stub
		return mapper.getNodeStatisticsByNodeUUID(nodeUUID);
	}

	@Override
	public boolean addNodeValueList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addNodeValueList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add MergeNodeValue list to database",e);
		}
		return flag;
	}

}

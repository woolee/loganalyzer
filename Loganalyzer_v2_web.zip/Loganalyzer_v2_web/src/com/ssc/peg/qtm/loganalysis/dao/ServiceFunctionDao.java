package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface ServiceFunctionDao<T> {
	public boolean addServiceFunction(T entity);
	public T getServiceFuncById(int id);
	public List<T> getServiceFuncByFunction(int functionId);
	public List<T> getServiceFuncByService(int serviceId);
	public T getServiceFuncByFuncAndService(int analysisId,int serviceId,int functionId);
	public boolean addServiceFunctionList(List<T> list);
	public List<T> getServiceFuncByFunctionAnalysisId(int analysisId,int functionId);
	public List<T> gettopNfunctioninservice(int analysisId, int serviceId, int N);
	public List<T> getFunctionStatisticBiggerThan(int analysisId, int serviceId,
			float ratio);
}

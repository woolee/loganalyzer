package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;

@Entity
public class Analysis implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3651656806690894215L;
	private int analysisId;
	private Date analysisTime;
	private String analysisName;
	private String analysisUUID;
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	public Date getAnalysisTime() {
		return analysisTime;
	}
	public void setAnalysisTime(Date analysisTime) {
		this.analysisTime = analysisTime;
	}
	public String getAnalysisUUID() {
		return analysisUUID;
	}
	public void setAnalysisUUID(String analysisUUID) {
		this.analysisUUID = analysisUUID;
	}
	public String getAnalysisName() {
		return analysisName;
	}
	public void setAnalysisName(String analysisName) {
		this.analysisName = analysisName;
	}
	
}

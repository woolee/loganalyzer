package com.ssc.peg.qtm.loganalysis.concurrent;

import java.text.ParseException;

import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TimePicker;
import com.ssc.peg.qtm.loganalysis.exception.LogFormatException;
import com.ssc.peg.qtm.loganalysis.concurrent.TreeReader;

/**
 * The class implements Runnable to transfer the request tree String object to an RequestTree class we defined.
 * Then put the tree to ConcurrentMap object temporarily.
 * @author a549324
 *
 */
public class LogProcessor implements Runnable {

	private String queueString = null;
	private int topN = 10;
	private String uuid ;
	private TimePicker timePicker;
	public LogProcessor(String queueString,String uuid,int topN) {
		this.queueString = queueString;
		this.topN = topN;
		this.uuid = uuid;
		
		
	}

	public LogProcessor(String queueString,String uuid,TimePicker timePicker) {
		this.queueString = queueString;
		this.uuid = uuid;
		this.timePicker = timePicker;
	}
	public void run() {
//		System.out.println("process one -----");
		ServiceRequestTree tree = null;
		try {
			tree = new TreeReader(timePicker).strToTree(queueString);
//			if(tree.getIdfNumber() == null)
//				System.out.println(tree.getRequestId());
		} catch (LogFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		if("XXXXXX []".equals(tree.getIdfNumber()))
//		{
//			System.out.println();
//		}
		if (tree != null) {
			ConcurrentMapManager manager = DataMapSelector.selectConcurrentMap(uuid);
			manager.addToTopNMap(tree, topN);

			manager.addToIDFTreeMap(tree);

			manager.addToInvertedIdfTreeMap(tree);
			
			manager.addToFunctionRatioTopN(tree, 5);

			manager.addToFunctionTimeTopN(tree, 5);
		}
	}

	
}
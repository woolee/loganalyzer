package com.ssc.peg.qtm.loganalysis.util;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

public class FileZip
{
	private static final Logger logger = Logger.getLogger(FileZip.class);
	public static File zipDir;
	public static final String ZIP = ".zip";

	public static String unzip(String zipPath, String targetFolder) throws IOException
	{
		ZipEntry zipEntry = null;
		/*
		 * if there only one folder in the zip, set the folder path targetFolder
		 * + "/" + folderName else set the path with targetFolder
		 */
		String savedFolderPath = targetFolder;
		File folder = new File(targetFolder);
		ZipInputStream zipIn = null;
		BufferedWriter fileOut = null;
		try
		{
			File zipFile = new File(zipPath);
			zipIn = new ZipInputStream(new FileInputStream(zipFile));
			String tempRootFolderName = null;
			while ((zipEntry = zipIn.getNextEntry()) != null)
			{
				File file = new File(zipPath + File.separator + zipEntry.getName());

				//--- start ----
				/*
				 * in order to get the configuration folder path in case that the zip file name is different with the folder in the zip
				 */
				//get the entry root path except the zipNam path
				String rootFolderSub = file.getAbsolutePath().substring((zipPath + File.separator).length());
//				System.out.println(rootFolderSub); 
				int index = rootFolderSub.indexOf(File.separator);
				if (index != -1)
				{
					//get current entry root folder name
					String currentRootFolderName = rootFolderSub.substring(0, index);
					
					//compare with the temp root folder name, if they are same, get the  
					if (currentRootFolderName.equals(tempRootFolderName) || tempRootFolderName == null)
					{
						tempRootFolderName = currentRootFolderName;
						savedFolderPath = targetFolder + File.separator + tempRootFolderName;
					}
					else
					{
						savedFolderPath = targetFolder;
					}
				}
				else{
					if(rootFolderSub.equals(tempRootFolderName))
					{
						savedFolderPath = targetFolder + File.separator + rootFolderSub;
					}
					else{
						savedFolderPath = targetFolder;
					}
				}
				//----------------end------------------
				
				if (zipEntry.isDirectory())
				{
//					file.mkdirs();
					new File(targetFolder + File.separator + zipEntry.getName()).mkdirs();
				}
				else
				{
					File parent = file.getParentFile();

					if (!folder.exists())
					{
						folder.mkdir();
					}

					File readFile = null;
					if (parent.getName().equals(zipFile.getName()))
					{
						// System.out.println("---" + targetFolder+"/" +
						// file.getName());
						readFile = new File(targetFolder + File.separator + file.getName());
					}
					else
					{
						String parentPath = parent.getAbsolutePath().substring(zipPath.length() + 1);
						File targetParent = new File(folder, parentPath);

						if (!targetParent.exists())
						{
							targetParent.mkdirs();
						}
						String filePath = file.getAbsolutePath().substring(zipPath.length() + 1);
						// System.out.println(filePath);

						// readFile = new File(targetFolder+"/"+parent.getName()
						// + "/" + file.getName());
						readFile = new File(targetFolder + File.separator + filePath);

					}
					fileOut = new BufferedWriter(new FileWriter(readFile));
					IOUtils.copy(zipIn, fileOut);
//					int readedBytes;
//					while ((readedBytes = zipIn.read()) != -1)
//					{
//						fileOut.write(readedBytes);
//					}
//					fileOut.flush();
//					fileOut.close();
				}

				if(fileOut != null)
					fileOut.close();
				if(zipIn != null)
					zipIn.closeEntry();
			}
		}
		catch (FileNotFoundException e)
		{
			logger.error(e.getMessage());
			throw new FileNotFoundException();
		}
		catch (IOException e)
		{
			logger.error(e.getMessage());
			throw new IOException();
		}
		finally{
			if(fileOut != null)
				fileOut.close();
			if(zipIn != null)
				zipIn.close();
		}
		return savedFolderPath;
	}

	
	public static void doZip(String zipDirectory, String targetFile) throws Exception
	{
		// File zipDir ;
		ZipOutputStream zipOut = null;

		zipDir = new File(zipDirectory);
		String zipFileName = targetFile;// the file name after zip
		try
		{
			zipOut = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFileName)));
			handleDir(zipDir, zipOut);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage());
			throw new Exception();
		}
		finally{
			if(zipOut != null)
				zipOut.close();
		}
	}

	private static void handleDir(File dir, ZipOutputStream zipOut) throws Exception
	{
		FileInputStream fileIn;
		File[] files;

		// System.out.println("---" + dir.getAbsolutePath());
		files = dir.listFiles();
		if (files.length == 0)
		{
			zipOut.putNextEntry(new ZipEntry(dir.toString() + File.separator));
			zipOut.closeEntry();
		}
		else
		{
			for (File file : files)
			{
				if (file.isDirectory())
				{
					handleDir(file, zipOut);
				}
				else
				{
					// System.out.println(file.getAbsolutePath());
					// System.out.println("parent:" + new
					// File(file.getParent()).getName());
					fileIn = new FileInputStream(file);
					String name = dir.getName();
					if (zipDir.getPath().equals(dir.getPath()))
						zipOut.putNextEntry(new ZipEntry(zipDir.getName() + File.separator + file.getName().toString()));
					else
						zipOut.putNextEntry(new ZipEntry(zipDir.getName() + File.separator + name + File.separator + file.getName().toString()));

					byte[] buf = new byte[(int) file.length()];
					int readedBytes;
					while ((readedBytes = fileIn.read(buf)) > 0)
					{
						zipOut.write(buf, 0, readedBytes);
					}
					zipOut.closeEntry();
					
				}
			}
		}
	}

/*	public static void main(String[] args) throws IOException {
		FileZip.unzip("C:\\apms\\CDT.zip", "C:\\apms");
	}*/
}

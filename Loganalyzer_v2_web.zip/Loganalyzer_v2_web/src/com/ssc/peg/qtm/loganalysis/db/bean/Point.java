package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;

@Entity
public class Point implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7039481784039211085L;
	private int pointId;
	private Date pointTime;
	private int serviceId;
	private float tps;
	private float respTime;
	private int analysisId;
	public int getPointId() {
		return pointId;
	}
	public void setPointId(int pointId) {
		this.pointId = pointId;
	}
	public Date getPointTime() {
		return pointTime;
	}
	public void setPointTime(Date pointTime) {
		this.pointTime = pointTime;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public float getTps() {
		return tps;
	}
	public void setTps(float tps) {
		this.tps = tps;
	}
	public float getRespTime() {
		return respTime;
	}
	public void setRespTime(float respTime) {
		this.respTime = respTime;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	
	@Override
	public String toString(){
		return "Point[pointTime="+ pointTime + ", serviceId=" + serviceId + ",tps= " + tps + ", respTime=" + respTime + ", analysisId=" + analysisId + "]";
	}
}

package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceTopN;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.service.TreeService;

@Service
public class TreeServiceImp<T extends Tree> implements TreeService<T> {

	@Inject
	private TreeDao<T> dao;

	@Override
	public T getTreeById(int id) {
		// TODO Auto-generated method stub
		return dao.getTreeByTreeId(id);
	}


	@Override
	public List<T> getMergeTreeForService(int analysisId, int serviceId,
			boolean isMerged, boolean isAllStructure) {
		// TODO Auto-generated method stub
		return dao.getMergeTreeForService(analysisId, serviceId, isMerged, isAllStructure);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getTreeListByServiceTopN(List<ServiceTopN> serviceTopNList) {
		List<T> treeList = new ArrayList<T>();
		for (ServiceTopN serviceTopN : serviceTopNList) {
			T tree = dao.getTreeByTreeUUID(serviceTopN.getTreeUUID());
			treeList.add(tree);
		}
		return treeList;
	}

	@Override
	public int getCountOfMergeTreeForService(int analysisId, int serviceId,
			boolean isMerged, boolean isAllStructure) {
		// TODO Auto-generated method stub
		return dao.getCountOfMergeTreeForService(analysisId, serviceId, isMerged, isAllStructure);
	}

	@Override
	public List<T> getMergeTreeForServiceMerge(int analysisId, int serviceId,
			boolean isMerged, boolean isAllStructure) {
		// TODO Auto-generated method stub
		return dao.getMergeTreeForServiceMerge(analysisId, serviceId, isMerged, isAllStructure);
	}


	@Override
	public T getTreeByRequestId(String requestId) {
		// TODO Auto-generated method stub
		return dao.getTreeByRequestId(requestId);
	}

}

package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.FuncTimeTopNDao;
import com.ssc.peg.qtm.loganalysis.db.bean.FuncTimeTopN;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.FuncTimeTopNMapper;

@Repository
public class FuncTimeTopNDaoImp<T extends FuncTimeTopN> implements
		FuncTimeTopNDao<T> {

	@Inject
	private FuncTimeTopNMapper<T> mapper;

	@Override
	public boolean addFuncTimeTopN(T entity) {
		boolean flag = false;
		try {
			mapper.addFuncTimeTopN(entity);
			flag = true;
		} catch (Exception e) {
			flag = false;
			throw new DaoException(
					"Exception while add FuncTimeTopN to database", e);
		}
		return flag;

	}

	@Override
	public boolean addFuncTimeTopNList(List<T> list) {
		boolean flag = false;
		try {
			mapper.addFuncTimeTopNList(list);
			flag = true;
		} catch (Exception e) {
			flag = false;
			throw new DaoException(
					"Exception while add FuncTimeTopN list to database", e);
		}
		return flag;
	}

	@Override
	public List<T> getTopNByFunctionServiceId(int functionId, int serviceId,int analysisId) {
		// TODO Auto-generated method stub
		return mapper.getTopNByFunctionServiceId(functionId, serviceId,analysisId);
	}

}

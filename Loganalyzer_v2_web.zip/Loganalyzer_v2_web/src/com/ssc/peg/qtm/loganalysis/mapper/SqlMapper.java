package com.ssc.peg.qtm.loganalysis.mapper;

public interface SqlMapper
{

}

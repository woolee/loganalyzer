package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class Function implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7317417393809356254L;
	private int functionId;
	private String functionName;
	private String functionDescription;
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getFunctionDescription() {
		return functionDescription;
	}
	public void setFunctionDescription(String functionDescription) {
		this.functionDescription = functionDescription;
	}
	@Override
	public String toString(){
		return "Function[functionId="+ functionId + ", functionName=" + functionName + ",functionDescription= " + functionDescription +  "]";
	}
}

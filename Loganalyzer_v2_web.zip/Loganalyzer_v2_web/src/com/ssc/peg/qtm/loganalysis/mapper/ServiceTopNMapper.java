package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;


public interface ServiceTopNMapper<T> extends SqlMapper {
	public void addServiceTopN(T entity);
	public void addServiceTopNList(List<T> list);
	public List<T> getServiceTopNByAnalysisId(int analysisId);
	public List<T> getTopNByAnalyIdAndServiceId(@Param("analysisId")int analysisId, @Param("serviceId")int serviceId) ;
}

package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface TreeMapper<T> extends SqlMapper{
	public void addTree(T entity);
	public T getTreeByTreeId(int id);
	public List<T> getTreeByAnalysisId(int analysisId);
	public T getTreeByTreeUUID(String treeUUID);
	public T getTreeByRequestId(String requestId);
	public void addTreeList(List<T> list);
	public List<T> getMergeTreeForServiceMerge(@Param("analysisId")int analysisId,@Param("serviceId")int serviceId,@Param("isMerged")boolean isMerged,@Param("isAllStructure")boolean isAllStructure);
	public List<T> getMergeTreeForService(@Param("analysisId")int analysisId,@Param("serviceId")int serviceId,@Param("isMerged")boolean isMerged,@Param("isAllStructure")boolean isAllStructure);
	public int getCountOfMergeTreeForService(@Param("analysisId")int analysisId,@Param("serviceId")int serviceId,@Param("isMerged")boolean isMerged,@Param("isAllStructure")boolean isAllStructure);
}

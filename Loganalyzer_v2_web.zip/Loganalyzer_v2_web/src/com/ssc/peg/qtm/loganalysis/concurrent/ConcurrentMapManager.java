package com.ssc.peg.qtm.loganalysis.concurrent;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.ssc.peg.qtm.loganalysis.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceFunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceMergeTree;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeMapping;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;


/**
 * The class is called by LogProcessor class, store all the RequestTree object and inverted index of function temporarily.
 * @author a549324
 *
 */
public class ConcurrentMapManager {
	private Logger logger = Logger.getLogger(getClass());
	private int TOP_SIZE = 10;
	/**10 slowest execution time of trees. [key: IDF number,value: top 10 request tree list]*/ 
	private  volatile ConcurrentHashMap<String,List<ServiceRequestTree>> topNMap = new ConcurrentHashMap<String, List<ServiceRequestTree>>();
	
	/**all request tree. [key : Idf number,value: request tree list]*/
	private  volatile ConcurrentHashMap<String,List<ServiceRequestTree>> idfTreeMap = new ConcurrentHashMap<String, List<ServiceRequestTree>>();
	
	/**Inverted index map of idfTreeMap  [KEY:function,VALUE:[KEY:service name, VALUE: function statistics in service]]*/
	private  volatile ConcurrentHashMap<String,Map<String,ServiceFunctionStatistics>> invertedIdfTreeMap = new ConcurrentHashMap<String,Map<String,ServiceFunctionStatistics>>(10240);
	
	private  volatile ConcurrentHashMap<String,Map<String,List<ServiceRequestTree>>> functionRatioTopN = new ConcurrentHashMap<String,Map<String,List<ServiceRequestTree>>>(10240);
	
	private  volatile ConcurrentHashMap<String,Map<String,List<ServiceRequestTree>>> functionTimeTopN = new ConcurrentHashMap<String, Map<String,List<ServiceRequestTree>>>(10240);
	
//	public ConcurrentMapManager instance = new ConcurrentMapManager();
//	public static ConcurrentMapManager getInstance(String uuid)
//	{
//		return instance;
//	}
//	private RequestTree tree ;
	
//	public ConcurrentMapManager(RequestTree tree)
//	{
//		this.tree = tree;
//	}
	/**
	 * 
	 * @param tree
	 * @param topN
	 */
	public void addToFunctionRatioTopN(ServiceRequestTree tree, int topN)
	{
		Map<String, FunctionStatistics> funcStatisMap = tree.getFunctionStatistics();
		String idfNumber = tree.getIdfNumber();
		Set<String> fuctions = funcStatisMap.keySet();
		for (String function : fuctions) {
			Map<String, List<ServiceRequestTree>> idfStatisMap = functionRatioTopN.get(function.intern());
			if(idfStatisMap != null)
			{
				List<ServiceRequestTree> treeList = idfStatisMap.get(idfNumber);
				if(treeList != null)
				{
//					List<ServiceRequestTree> treeList = functionRatioTopN.get(function).get(idfNumber);
					
					synchronized (treeList) {
					if(treeList.size() < topN)
						treeList.add(tree);
					else
					{
						float minRatio = Float.MAX_VALUE;
						ServiceRequestTree minTree = null;
							for (ServiceRequestTree containsTree : treeList) {
								float ratio = containsTree.getFunctionStatistics().get(function).getRatio();
								if(ratio < minRatio)
								{	minRatio = ratio;
								minTree = containsTree;
								}
							}
							if(funcStatisMap.get(function).getRatio() > minRatio)
							{
								treeList.remove(minTree);
								treeList.add(tree);
							}
						}
					}
				}
				else
				{
					treeList = new ArrayList<ServiceRequestTree>();
					treeList.add(tree);
					idfStatisMap.put(idfNumber, treeList);
				}
			}
			else
			{
				List<ServiceRequestTree> treeList = new ArrayList<ServiceRequestTree>(topN);
				treeList.add(tree);
				Map<String,List<ServiceRequestTree>> map = new HashMap<String, List<ServiceRequestTree>>();
				map.put(idfNumber.intern(), treeList);
				functionRatioTopN.putIfAbsent(function.intern(), map);
			}
		}
	}
	
	/**
	 * 
	 * @param tree
	 * @param topN
	 */
	public void addToFunctionTimeTopN(ServiceRequestTree tree, int topN)
	{
		Map<String, FunctionStatistics> funcStatisMap = tree.getFunctionStatistics();
		String idfNumber = tree.getIdfNumber().intern();
		Set<String> functions = funcStatisMap.keySet();
		for (String function : functions) {
			Map<String, List<ServiceRequestTree>> idfStatisMap = functionTimeTopN.get(function.intern());
			if(idfStatisMap != null)
			{
				List<ServiceRequestTree> treeList = idfStatisMap.get(idfNumber);
				if(treeList != null)
				{
//					List<ServiceRequestTree> treeList = functionTimeTopN.get(function.intern()).get(idfNumber);
					
					synchronized (treeList) {
					if(treeList.size() < topN)
						treeList.add(tree);
					else
					{
						float minTime = Float.MAX_VALUE;
						ServiceRequestTree minTree = null;
							for (ServiceRequestTree containsTree : treeList) {
								float avgTime = containsTree.getFunctionStatistics().get(function.intern()).getAvgTime();
								if(avgTime < minTime)
								{	minTime = avgTime;
								minTree = containsTree;
								}
							}
							if(funcStatisMap.get(function.intern()).getAvgTime() > minTime)
							{
								treeList.remove(minTree);
								treeList.add(tree);
							}
						
						}
					}
				}
				else
				{
					treeList = new ArrayList<ServiceRequestTree>(topN);
					treeList.add(tree);
					idfStatisMap.put(idfNumber, treeList);
				}
			}
				
			else
			{
				List<ServiceRequestTree> treeList = new ArrayList<ServiceRequestTree>(topN);
				treeList.add(tree);
				Map<String,List<ServiceRequestTree>> map = new HashMap<String, List<ServiceRequestTree>>();
				map.put(idfNumber, treeList);
				functionTimeTopN.putIfAbsent(function.intern(), map);
				
			}
				
		}
	}
	
	/**
	 * add tree to topNMap if the execution time is more than trees in current top 10 map 
	 * @param tree
	 * @return boolean true:add to the map
	 */
	public boolean addToTopNMap(ServiceRequestTree tree,int topN)
	{
		TOP_SIZE = topN;
		String idfNumber = tree.getIdfNumber().intern();
		List<ServiceRequestTree> currentTreeList = topNMap.get(idfNumber);
		
		//if topNMap doesn't have the idf number as key, create a new list
		if(currentTreeList == null)
		{
			List<ServiceRequestTree> list = new ArrayList<ServiceRequestTree>(TOP_SIZE);
			list.add(tree);
			List<ServiceRequestTree> returnList = topNMap.putIfAbsent(idfNumber,list);
		}
		else
		{
				
				//if the size of top10 list has not reach the 10, add the tree
				if(currentTreeList.size() < TOP_SIZE)
				{
					currentTreeList.add(tree);
				}
				else
				{
					ServiceNode firstTreeRootNode = currentTreeList.get(0).getRootNode();
					Map<ServiceNode, ServiceNodeValue> firstTreeMappingMap = currentTreeList.get(0).getNodeMapping().getNodeMappingMap();
					long smallestTime = firstTreeMappingMap.get(firstTreeRootNode).getExecutionTime();
					ServiceRequestTree smallestTree = currentTreeList.get(0);
					//foreach the list of the IDF number, get the smallest of execution time and tree
					for (int i = 1; i < currentTreeList.size(); i++) {
						ServiceRequestTree currentTree = currentTreeList.get(i);
						long currentTime = currentTree.getNodeMapping().getNodeMappingMap().get(currentTree.getRootNode()).getExecutionTime();
						if(currentTime < smallestTime)
						{
							smallestTree = currentTree;
							smallestTime = currentTime;
						}
					}
					
					long treeExecTime = tree.getNodeMapping().getNodeMappingMap().get(tree.getRootNode()).getExecutionTime();
					//if the input tree execution time is bigger than the smallest, remove the smallest from list and add the input tree
					if(treeExecTime > smallestTime)
					{
						synchronized(currentTreeList){
						currentTreeList.remove(smallestTree);
						currentTreeList.add(tree);
						}
						
					}
					else{
						return false;
					}
					
				}
			
		}
		return true;
		
	}
	
	/**
	 * 
	 * @param tree
	 * @return true:add success, failed: exits in the map, fail to add
	 */
	public boolean addToIDFTreeMap(ServiceRequestTree tree)
	{
		String idfNumber = tree.getIdfNumber().intern();
		List<ServiceRequestTree> currentTreeList = idfTreeMap.get(idfNumber);
		if(currentTreeList == null)
		{
			List<ServiceRequestTree> list = new ArrayList<ServiceRequestTree>();
			list.add(tree);
			List<ServiceRequestTree> returnList = idfTreeMap.putIfAbsent(idfNumber,list);
		}
		else
		{
			currentTreeList.add(tree);
			List<ServiceRequestTree> returnList = idfTreeMap.replace(idfNumber, currentTreeList);
		}
		return true; 
	}
	
	
	/**
	 * add tree to Inverted index map
	 * @param tree
	 */
	public boolean addToInvertedIdfTreeMap(ServiceRequestTree tree)
	{
		ServiceNode rootNode = tree.getRootNode();
		ServiceNodeMapping mapping = tree.getNodeMapping();
		String idfNumber = tree.getIdfNumber().intern();
		
		queryChildToInvertedMap(rootNode, mapping, idfNumber);
		return true;
	}

	
	private void queryChildToInvertedMap(ServiceNode parentNode,ServiceNodeMapping mapping,String idfNumber)
	{
		List<ServiceNode> childrenNode = parentNode.getChildrenNode();
		ServiceNodeValue nodeValue = mapping.getNodeMappingMap().get(parentNode);
		String function = (nodeValue.getFunctionName() + " - " + nodeValue.getFuncationDescription()).intern();
		if(invertedIdfTreeMap.containsKey(function))
		{
			Map<String,ServiceFunctionStatistics> currentIdfMap = invertedIdfTreeMap.get(function);
			if(!currentIdfMap.containsKey(idfNumber))
			{
				currentIdfMap.put(idfNumber, null);
			}
		}
		else
		{
			Map<String,ServiceFunctionStatistics> idfMap = new HashMap<String,ServiceFunctionStatistics>();
			idfMap.put(idfNumber,null);
			invertedIdfTreeMap.putIfAbsent(function, idfMap);
		}
		if(childrenNode != null)
		{
			for (ServiceNode child : childrenNode) {
				queryChildToInvertedMap(child,mapping,idfNumber);
			}
		}
	}
	
	
	private void setFunStatistics(ServiceNode parentNode, ServiceNodeMapping mapping,Map<String,
			Map<ServiceNodeValue,ServiceNodeStatistics>> idfMergeNodeStatisticsMap,String idfNumber,ServiceNodeStatistics rootNodeStatis)
	{
		ServiceNodeValue parentNodeValue = mapping.getNodeMappingMap().get(parentNode);
		ServiceNodeStatistics parentNodeStatis = idfMergeNodeStatisticsMap.get(idfNumber).get(parentNodeValue);
		String function = (parentNodeValue.getFunctionName() + " - " + parentNodeValue.getFuncationDescription()).intern();
		ServiceFunctionStatistics funcStatis = invertedIdfTreeMap.get(function).get(idfNumber);
		if(!checkAncestorContainsFunction(function, mapping, parentNode)){
			if(funcStatis == null)
			{
				funcStatis = new ServiceFunctionStatistics();
				funcStatis.setMaxTimeInIdf(parentNodeStatis.getMaxTime());
				funcStatis.setMinTimeInIdf(parentNodeStatis.getMinTime());
				funcStatis.setAvgTimeInIdf(parentNodeStatis.getAvgTime());
				funcStatis.setCountInIdf(parentNodeStatis.getCount());
				funcStatis.setSelfAvgTime(parentNodeStatis.getSelfAvgTime());
				funcStatis.setPercentageByRoot(parentNodeStatis.getPercentageAbl());
				funcStatis.setSelfPercentageByRoot(parentNodeStatis.getSelfPercentageAbl());
				if(parentNodeStatis.getSelfPercentageAbl() > 1)
				System.out.println("concurrentMapManager.setFunStatistics()="+(funcStatis.getPercentageByRoot() - funcStatis.getSelfPercentageByRoot()));
				funcStatis.setTotalTime(parentNodeStatis.getTotalTime());
				funcStatis.setTotalSelfTime(parentNodeStatis.getTotalSelfTime());
				invertedIdfTreeMap.get(function).put(idfNumber, funcStatis);
			}
			else
			{
				if(parentNodeStatis.getMaxTime() > funcStatis.getMaxTimeInIdf())
					funcStatis.setMaxTimeInIdf(parentNodeStatis.getMaxTime());
				if(parentNodeStatis.getMinTime() < funcStatis.getMinTimeInIdf())
					funcStatis.setMinTimeInIdf(parentNodeStatis.getMinTime());
				
				int previousCount = funcStatis.getCountInIdf();
				funcStatis.setCountInIdf(previousCount + parentNodeStatis.getCount());
				funcStatis.setTotalTime(funcStatis.getTotalTime() + parentNodeStatis.getTotalTime() );
				funcStatis.setTotalSelfTime(funcStatis.getTotalSelfTime() + parentNodeStatis.getTotalSelfTime());
				funcStatis.setAvgTimeInIdf(funcStatis.getTotalTime() / funcStatis.getCountInIdf());
				funcStatis.setSelfAvgTime(funcStatis.getTotalSelfTime() / funcStatis.getCountInIdf());
				funcStatis.setPercentageByRoot(funcStatis.getTotalTime()  / rootNodeStatis.getTotalTime());
				funcStatis.setSelfPercentageByRoot(funcStatis.getTotalSelfTime() / rootNodeStatis.getTotalTime());
				invertedIdfTreeMap.get(function).put(idfNumber, funcStatis);
				System.out.println("concurrentMapManager.setFunStatistics()="+(funcStatis.getPercentageByRoot() - funcStatis.getSelfPercentageByRoot()));
			}
		}
		
		if(parentNode.getChildrenNode() != null)
		{
			for (ServiceNode childNode : parentNode.getChildrenNode()) {
				
				setFunStatistics(childNode, mapping, idfMergeNodeStatisticsMap, idfNumber, rootNodeStatis);
			}
			
		}
	}
	
	private void setFunction90Line(Map<String,FunctionStatistics> scoreMap)
	{
		Set<String> serviceNames = idfTreeMap.keySet();
		//[KEY: function,VALUE: execution time list]
		Map<String,List<Float>> executionTimeMap = new HashMap<String, List<Float>>();
		for (String serviceName : serviceNames) {
			List<ServiceRequestTree> treeList = idfTreeMap.get(serviceName);
			for (ServiceRequestTree tree : treeList) {
				Map<ServiceNode, ServiceNodeValue> mappingMap = tree.getNodeMapping().getNodeMappingMap();
				ServiceNode rootNode = tree.getRootNode();
				statisFunctionExecutionTime(executionTimeMap,mappingMap, rootNode);
			}
		}
		for(String function : executionTimeMap.keySet())
		{
			List<Float> timeList = executionTimeMap.get(function);
			Collections.sort(timeList,new Comparator<Float>() {

				@Override
				public int compare(Float o1, Float o2) {
					// TODO Auto-generated method stub
					/*if(o1 > o2 )
					{
					    return 1;
					} 
					else if(o1 == o2)
					{
					    return 0;
					} 
					else */return (int) (o1-o2);
				}
			});
			float nintyTime = timeList.get((int) Math.round(timeList.size() * 0.9) -1 );
			scoreMap.get(function).setNintyTime(nintyTime);
		}
	}
	
	private void statisFunctionExecutionTime(Map<String,List<Float>> executionTimeMap,Map<ServiceNode, ServiceNodeValue> mappingMap,ServiceNode node)
	{
		ServiceNodeValue value = mappingMap.get(node);
		String functionStr = (value.getFunctionName() + " - " + value.getFuncationDescription()).intern();
		List<Float> timeList = executionTimeMap.get(functionStr);
		if(timeList == null)
		{
			timeList = new ArrayList<Float>();
			timeList.add(Float.valueOf(value.getExecutionTime()));
			executionTimeMap.put(functionStr, timeList);
		}
		else
			timeList.add(Float.valueOf(value.getExecutionTime()));
		if(node.getChildrenNode() != null)
		{
			for (ServiceNode childNode : node.getChildrenNode()) {
				statisFunctionExecutionTime(executionTimeMap, mappingMap, childNode);
			}
		}
	}
	
	private boolean checkAncestorContainsFunction(String function,ServiceNodeMapping mapping,ServiceNode node)
	{
		boolean contains = false;
		if(node.getParentNode() != null)
		{
			ServiceNodeValue parentNodeValue = mapping.getNodeMappingMap().get(node.getParentNode());
			String parentFunction = (parentNodeValue.getFunctionName() + " - " + parentNodeValue.getFuncationDescription()).intern();
			if(function.equals(parentFunction))
				contains = true;
			else
			{
				contains = checkAncestorContainsFunction(function, mapping, node.getParentNode());
			}
		}
		return contains;
	}
	
	/**
	 * calculate call count, AVG, MIN, MAX response time and percentage of function in one IDF number;
	 * @param idfMergeTreeMap
	 * @param idfMergeNodeStatisticsMap
	 */
	public void setFunctionStatisticsInInvertMap(Map<String,ServiceMergeTree> idfMergeTreeMap,
			Map<String,Map<ServiceNodeValue,ServiceNodeStatistics>> idfMergeNodeStatisticsMap,String uuid)
	{
		Set<String> idfNumbers = idfMergeTreeMap.keySet();
		for (String idfNumber : idfNumbers) {
			
			ServiceRequestTree tree = idfMergeTreeMap.get(idfNumber).getAllMergeTree();
			ServiceNode rootNode = tree.getRootNode();
			ServiceNodeValue nodeValue = tree.getNodeMapping().getNodeMappingMap().get(rootNode);
			ServiceNodeStatistics rootNodeStatis = idfMergeNodeStatisticsMap.get(idfNumber).get(nodeValue);
			setFunStatistics(rootNode,tree.getNodeMapping(),idfMergeNodeStatisticsMap,tree.getIdfNumber(), rootNodeStatis);
			System.out.println();
		}
	}
	
	public Map<String,Float> calAvg()
	{
		Set<String> functions = invertedIdfTreeMap.keySet();
		Map<String,Float> map = new HashMap<String,Float>();
		for (String function : functions) {
			Map<String, ServiceFunctionStatistics> funcStatisticMap = invertedIdfTreeMap.get(function);
			Set<String> idfs = funcStatisticMap.keySet();
			int size = idfs.size();
			float total = 0;
			for (String idf : idfs) {
				ServiceFunctionStatistics funcStatistic = funcStatisticMap.get(idf);
				if("TX_ACCT_PRIOR_KEY_FIN_STATS [FUND_ID=VAA5 AND DATE=03/04/2015]".equals(idf)){
					logger.warn(function);
				}
				try{
					
					total = total + funcStatistic.getSelfPercentageByRoot();
				}
				catch(NullPointerException e){
					logger.error("function: " + function + " --------- service:" + idf , e);
					throw e;
				}
			}
//			System.out.println("avg:" + total/size);
			map.put(function, total/size);
		}
		return map;
	}
	
	public Map<String,Float> calRms()
	{
		Set<String> functions = invertedIdfTreeMap.keySet();
		Map<String,Float> map = new HashMap<String,Float>();
		for (String function : functions) {
			Map<String, ServiceFunctionStatistics> funcStatisticMap = invertedIdfTreeMap.get(function);
			Set<String> idfs = funcStatisticMap.keySet();
			float totalPowerOf2 = 0;
			int size = idfs.size();
			for (String idf : idfs) {
				ServiceFunctionStatistics funcStatistic = funcStatisticMap.get(idf);
//				if(funcStatistic.getPercentageByRoot() > 1)
//					System.out.println(funcStatistic.getPercentageByRoot());
				totalPowerOf2 = (float)(totalPowerOf2 + Math.pow(funcStatistic.getSelfPercentageByRoot(),2));
			}
//			if(Math.sqrt(totalPowerOf2/size) > 1)
//			System.out.println(function + "  rms =" + Math.sqrt(totalPowerOf2/size));
			map.put(function.intern(), (float)Math.sqrt(totalPowerOf2/size));
		}
		return map;
	}
	
	/*public Map<String,Float> calEula()
	{
		Set<String> functions = invertedIdfTreeMap.keySet();
		Map<String,Float> map = new HashMap<String,Float>();
		for (String function : functions) {
			Map<String, ServiceFunctionStatistics> funcStatisticMap = invertedIdfTreeMap.get(function);
			Set<String> idfs = funcStatisticMap.keySet();
			float totalPowerOf2 = 0;
			int size = idfs.size();
			for (String idf : idfs) {
				ServiceFunctionStatistics funcStatistic = funcStatisticMap.get(idf);
//				if(funcStatistic.getPercentageByRoot() > 1)
//					System.out.println(funcStatistic.getPercentageByRoot());
				totalPowerOf2 = (float)(totalPowerOf2 + Math.pow(funcStatistic.getSelfAvgTime()/1000000,2));
			}
//			if(Math.sqrt(totalPowerOf2/size) > 1)
//			System.out.println(function + "  rms =" + Math.sqrt(totalPowerOf2/size));
			map.put(function.intern(), (float)Math.sqrt(totalPowerOf2));
		}
		return map;
	}*/
	
	public Map<String,FunctionStatistics> calFunctionScore(Map<String,FunctionStatistics> scoreMap)
	{
		Map<String,Float> stdMap = calStd();
		Map<String,Float> rmsMap = calRms();
//		Map<String,Float> eulaMap = calEula();
		Set<String> functions = stdMap.keySet();
//		Set<String> functions = eulaMap.keySet(); 
		for (String function : functions) {
			FunctionStatistics statistics = new FunctionStatistics();
			float std = stdMap.get(function);
			float rms = rmsMap.get(function);
			statistics.setScore(rms-std);
//			statistics.setScore(eulaMap.get(function));
//			System.out.println("score:" + (rms-std));
			Map<String, ServiceFunctionStatistics> serviceFunctionByService = invertedIdfTreeMap.get(function);
			Set<String> services = serviceFunctionByService.keySet();
			int totalCount = 0;
			float totalTime = 0;
			long maxTime = Long.MIN_VALUE;
			long minTime = Long.MAX_VALUE;
			for (String seriveName : services) {
				ServiceFunctionStatistics serviceFuncStatistics = serviceFunctionByService.get(seriveName);
				totalTime = totalTime + serviceFuncStatistics.getAvgTimeInIdf() * serviceFuncStatistics.getCountInIdf();
				totalCount = totalCount + serviceFuncStatistics.getCountInIdf();
				if(serviceFuncStatistics.getMaxTimeInIdf() > maxTime)
					maxTime = serviceFuncStatistics.getMaxTimeInIdf();
				if(serviceFuncStatistics.getMinTimeInIdf() < minTime)
					minTime = serviceFuncStatistics.getMinTimeInIdf();
			}
			statistics.setCount(totalCount);
			statistics.setMaxTime(maxTime);
			statistics.setMinTime(minTime);
			statistics.setAvgTime(totalTime/totalCount);
			scoreMap.put(function.intern(), statistics);
		}
		setFunction90Line(scoreMap);
		return scoreMap;
	}
	public Map<String,Float> calStd()
	{
		Map<String,Float> avgMap = calAvg();
		Map<String,Float> map = new HashMap<String,Float>();
		Set<String> functions = invertedIdfTreeMap.keySet();
		for (String function : functions) {
			Map<String, ServiceFunctionStatistics> funcStatisticMap = invertedIdfTreeMap.get(function);
			Set<String> idfs = funcStatisticMap.keySet();
			float total = 0;
			int size = 0;
			size = idfs.size();
			float avg = avgMap.get(function);
			for (String idf : idfs) {
				ServiceFunctionStatistics funcStatistic = funcStatisticMap.get(idf);
				total = (float) (total + Math.pow(funcStatistic.getSelfPercentageByRoot() - avg,2));
			}
//			System.out.println(function + "  std =" + Math.sqrt(total/size));
			map.put(function.intern(), (float)Math.sqrt(total/size));
			System.out.println(size + "----" + (float)Math.sqrt(total/size));
		}
		return map;
	}
	
	public ConcurrentHashMap<String, List<ServiceRequestTree>> getTopNMap() {
		return topNMap;
	}


	public ConcurrentHashMap<String, List<ServiceRequestTree>> getIdfTreeMap() {
		return idfTreeMap;
	}

	public  ConcurrentHashMap<String, Map<String, ServiceFunctionStatistics>> getInvertedIdfTreeMap() {
		return invertedIdfTreeMap;
	}

	public  void setTopNMap(
		ConcurrentHashMap<String, List<ServiceRequestTree>> topNMap) {
		this.topNMap = topNMap;
	}

	public  void setIdfTreeMap(
		ConcurrentHashMap<String, List<ServiceRequestTree>> idfTreeMap) {
		this.idfTreeMap = idfTreeMap;
	}

	public  void setInvertedIdfTreeMap(
		ConcurrentHashMap<String, Map<String, ServiceFunctionStatistics>> invertedIdfTreeMap) {
		this.invertedIdfTreeMap = invertedIdfTreeMap;
	}

	public ConcurrentHashMap<String, Map<String, List<ServiceRequestTree>>> getFunctionRatioTopN() {
		return functionRatioTopN;
	}

	public void setFunctionRatioTopN(
			ConcurrentHashMap<String, Map<String, List<ServiceRequestTree>>> functionRatioTopN) {
		this.functionRatioTopN = functionRatioTopN;
	}

	public ConcurrentHashMap<String, Map<String, List<ServiceRequestTree>>> getFunctionTimeTopN() {
		return functionTimeTopN;
	}

	public void setFunctionTimeTopN(
			ConcurrentHashMap<String, Map<String, List<ServiceRequestTree>>> functionTimeTopN) {
		this.functionTimeTopN = functionTimeTopN;
	}


	
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface TreeDao<T> {
	public boolean addTree(T entity);
	public T getTreeByTreeId(int id);
	public List<T> getTreeByAnalysisId(int analysisId);
	public T getTreeByTreeUUID(String treeUUID);
	public T getTreeByRequestId(String requestId);
	public boolean addTreeList(List<T> list);
	public List<T> getMergeTreeForService(int analysisId,int serviceId,boolean isMerged,boolean isAllStructure);
	public int getCountOfMergeTreeForService(int analysisId,int serviceId,boolean isMerged,boolean isAllStructure);
	public List<T> getMergeTreeForServiceMerge(int analysisId,int serviceId,boolean isMerged,boolean isAllStructure);
}

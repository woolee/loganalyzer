package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface NodeValueDao<T> {
	public boolean addNodeValue(T entity);
	public T getNodeValueByValueId(int valueId);
	public T getNodeValueByNodeUUID(String uuid);
	public boolean addNodeValueList(List<T> list);
}

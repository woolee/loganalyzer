package com.ssc.peg.qtm.loganalysis.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.peg.qtm.loganalysis.db.bean.Service;
import com.ssc.peg.qtm.loganalysis.db.bean.ServiceStatistics;
import com.ssc.peg.qtm.loganalysis.dao.ServiceDao;
import com.ssc.peg.qtm.loganalysis.service.ServService;

@org.springframework.stereotype.Service
public class ServServiceImp<T extends Service> implements ServService<T> {

	@Inject
	private ServiceDao<T> dao;
	@Override
	public T getServiceById(int id) {
		// TODO Auto-generated method stub
		return dao.getServiceById(id);
	}

	@Override
	public T getServiceByName(String name) {
		// TODO Auto-generated method stub
		return dao.getServiceByName(name);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Map<Integer, Service> getServiceByServiceStatics(
			List<ServiceStatistics> servStatisList) {
		Map<Integer,Service> serviceMap = new HashMap<Integer, Service>();
		for (ServiceStatistics servStatis : servStatisList) {
			Service service = dao.getServiceById(servStatis.getServiceId());
			if(!serviceMap.containsKey(service.getServiceId()))
				serviceMap.put(service.getServiceId(), service);
		}
		return serviceMap;
	}


}

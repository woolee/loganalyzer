package com.ssc.peg.qtm.loganalysis.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ssc.peg.qtm.loganalysis.bean.ServiceMergeTree;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TPSResponseTime;
import com.ssc.peg.qtm.loganalysis.concurrent.ConcurrentMapManager;
import com.ssc.peg.qtm.loganalysis.concurrent.DataMapSelector;

@Controller
@RequestMapping("/topN")
public class TopNRequestController {
	
//	Map<String,RequestTree> idfMergeTreeMap = new HashMap<String, RequestTree>();
//	Map<String,Map<NodeValue,NodeStatistics>> idfMergeNodeStatisticsMap = new HashMap<String, Map<NodeValue,NodeStatistics>>();
	
	
	/*@RequestMapping("/mergetree")
	public String mergetree(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model){    
		String uuid = (String) session.getAttribute("uuid");
		String idfnumber=request.getParameter("idfNumber");	
		
		session.setAttribute("idfNumber", idfnumber);
		
		ServiceMergeTree tree = DataMapSelector.selectCommonMap(uuid).getIdfMergeTreeMap().get(idfnumber);
		List<ServiceRequestTree> mergetreelist = tree.getStructureMergeTree();
		List<Integer> mergetreeSizelist=new ArrayList<Integer>();
		for (int i = 1; i <= mergetreelist.size(); i++) {
			mergetreeSizelist.add(i);
		}
		model.addAttribute("StructureMergeTreeLengthList", mergetreeSizelist);
		session.setAttribute("StructureMergeTreeLengthList", mergetreeSizelist);
				
		return "../view/showIDFtree.jsp";
				
	}*/
	
	@RequestMapping("/mergetree_level")
	public void mergetreelevel(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model){ 
		String uuid = (String) session.getAttribute("uuid");
		String idfnumber=(String)session.getAttribute("idfNumber");	
		System.out.println("json-idfNumber:"+idfnumber);
		ServiceMergeTree tree = DataMapSelector.selectCommonMap(uuid).getIdfMergeTreeMap().get(idfnumber);
		ServiceNode rootNode = tree.getAllMergeTree().getRootNode();	
		StringBuffer sb = new StringBuffer();
		sb.append("{");
		
//		JSONObject obj = new JSONObject();
		
		String json1 = HasChildren(rootNode, tree.getAllMergeTree(),idfnumber,sb,uuid);
//		System.out.println("topNjsonobj:"+obj.toString());
//		sb.append(json1);
		sb.append("}");
		
//		String mergetreefilepath = session.getServletContext().getRealPath("/")+"json/mergetree.json";
//		System.out.println("filepath:"+mergetreefilepath);
//		File file=new File(mergetreefilepath);
//		
//		JSONObject obj1 = new JSONObject();
//		obj.put("obj", sb.toString());
//		JsonReader jsonReader = Json.createReader(new StringReader(sb.toString()));
//		JsonObject object = jsonReader.readObject();
//		jsonReader.close();
		
//		JSONParser parser = new JSONParser();
//		org.json.simple.JSONObject object = new org.json.simple.JSONObject();
//		
//			object = (org.json.simple.JSONObject)parser.parse(sb.toString());
		
//		JSONObject json = new JSONObject(sb.toString());
		session.setAttribute("0", sb.toString());
		JsonParser parser = new JsonParser();
        JsonElement jsonE = parser.parse(sb.toString());
	    JsonObject json = jsonE.getAsJsonObject();
	      
		
//		System.out.println("response.getWriter().print(JSONObject.fromObject(sb).toString()):"+json.toString());
		
		try {
			response.getWriter().print(json);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
//		BufferedWriter bw=null;
//		try {
//			bw=new BufferedWriter(new FileWriter(file));
//			bw.write(sb.toString());
//			bw.flush();
//			bw.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			 System.out.println("Exception ");
//		}
//		 
		
	}
	
	@RequestMapping("/IDFstructtree")
	public void IDFstructtree(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {    
		String uuid = (String) session.getAttribute("uuid");
		String idfnumber=(String)session.getAttribute("idfNumber");	
		String structnumber = request.getParameter("structnumber");
		session.setAttribute("structnumber", structnumber);
		ServiceMergeTree mergetree = DataMapSelector.selectCommonMap(uuid).getIdfMergeTreeMap().get(idfnumber);
		List<ServiceRequestTree> requesttreelist = mergetree.getStructureMergeTree();
		
//		JSONObject obj = new JSONObject();
		for (int i = 0; i < requesttreelist.size(); i++) {
			
			ServiceRequestTree tree = requesttreelist.get(i);
			ServiceNode rootNode = tree.getRootNode();
			StringBuffer sb = new StringBuffer();
			sb.append("{");
			
			HasChildren(rootNode, tree, idfnumber, sb,uuid);
			sb.append("}");
			
//			String structtreejsonname = "json/idfstruct_"+(i+1)+".json";
			 
		      
			session.setAttribute(""+(i+1), sb.toString());
//			System.out.println("response.getWriter().print(JSONObject.fromObject(sb).toString()):"+json.toString());
			
			
		}
		
		String getstring = (String)session.getAttribute(""+structnumber);
		JsonParser parser = new JsonParser();
        JsonElement jsonE = parser.parse(getstring);
	    JsonObject json = jsonE.getAsJsonObject();
	    try {
			response.getWriter().print(json);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			
	}
	
	private String HasChildren(ServiceNode rootNode,ServiceRequestTree tree,String idfnumber,StringBuffer sb,String uuid) {
		// TODO Auto-generated method stub
		ServiceNodeValue  parentNodeValue = tree.getNodeMapping().getNodeMappingMap().get(rootNode);
	  	Map<ServiceNodeValue, ServiceNodeStatistics> map = DataMapSelector.selectCommonMap(uuid).getIdgMergeNodeStatisticsMap().get(idfnumber);
	  	
	  	String lastString = null;
	 	ServiceNodeStatistics statis =  map.get(parentNodeValue);
//	 	if(!map.containsKey(parentNodeValue))
//	 	{
//	 		for (ServiceNodeValue nodeValue : map.keySet()) {
//				System.out.println(nodeValue.hashCode());
//			}
//	 		System.out.print("------" + parentNodeValue.hashCode());
//	 	}
	 	String function= parentNodeValue.getFunctionName()+" - "+parentNodeValue.getFuncationDescription();
	 	if(statis == null)
	 	{
	 		System.out.print("null");
	 	}
	 	double avgTime = statis.getAvgTime();
	 	
	 	//double percentagerel=statis.getPercentageRel();
	 	double percentageabs=statis.getPercentageAbl();
	 	
//	 	if(array!=null){
//	 		JSONObject objchild = new JSONObject();
//	 		objchild.put("name", function);
//	 		objchild.put("avgTime", avgTime/1000000);
//	 		objchild.put("percentageabs", percentageabs);
//	 		array.add(objchild);
//		 	
//	 	}else{
//	 		obj.put("name", function);
//		 	obj.put("avgTime", avgTime/1000000);
//		 	obj.put("percentageabs", percentageabs);
//	 	}
	 	
	 	sb.append("\"name\""+":");
	 	sb.append("\""+function+"\"");
	 	sb.append(",");
	 	sb.append("\"avgTime\""+":");
	 	sb.append("\""+avgTime/1000000+"\"");
	 	sb.append(",");
	 	//sb.append("\"percentagerel\""+":");
	 	//sb.append("\""+percentagerel+"\"");
	 	sb.append("\"percentageabs\""+":");
	 	sb.append("\""+percentageabs+"\"");
	 	
	 	//test results
/*	 	System.out.println("-----------------");
	 	System.out.println("function:"+function);
	 	System.out.println("avgtime:"+avgTime/1000000);
	 	System.out.println("percentagerel"+percentagerel);*/
	 	//test results
	 	
	 	if(rootNode.getChildrenNode()!= null){
	 		
	 		
//	 		JSONArray arraylist = new JSONArray();
//	 		JSONObject objchild = new JSONObject();
//	 		objchild.put("name", "self");
//	 		objchild.put("avgTime", statis.getSelfAvgTime()/1000000);
//	 		objchild.put("percentageabs", statis.getSelfPercentageAbl());
//	 		arraylist.add(objchild);
//	 		
	 		
	 		sb.append(","+"\"children\""+":"+"[");
	 		sb.append("{");
	 		sb.append("\"name\""+":");
		 	sb.append("\""+function+" -self\"");
		 	sb.append(",");
		 	sb.append("\"avgTime\""+":");
		 	sb.append("\""+statis.getSelfAvgTime()/1000000+"\"");
		 	sb.append(",");
		 	sb.append("\"percentageabs\""+":");
		 	sb.append("\""+statis.getSelfPercentageAbl()+"\"");
		 	sb.append("},"); 
		 	
	 		List<ServiceNode> children = rootNode.getChildrenNode();
	 		for(int j=0;j<children.size()-1;j++){
	 			sb.append("{");
		  		HasChildren(children.get(j),tree,idfnumber,sb,uuid);
		  		sb.append("},");
	 		}
	 		sb.append("{");
	  		HasChildren(children.get(children.size()-1),tree,idfnumber,sb,uuid);
	  		sb.append("}");  		
	  		sb.append("]");
	 	}
	 	return sb.toString();
	}

	@RequestMapping("/request")
	public String showidf(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {    
		String uuid = (String) session.getAttribute("uuid");
		String idfnumber=request.getParameter("idfNumber");
		session.setAttribute("idfNumber", idfnumber);
//		System.out.println("request:"+idfnumber);
		ConcurrentMapManager instance = DataMapSelector.selectConcurrentMap(uuid);		
		List<ServiceRequestTree> top10_requests = instance.getTopNMap().get(idfnumber);
//		System.out.println(top10_requests.size());
		model.addAttribute("topNrequest", top10_requests);
		session.setAttribute("topNrequest", top10_requests);//it will work when show one of the top 10 request tree
		return "../view/top10_requestsDetails.jsp?idfNumber="+idfnumber;
				
	}
	
	@RequestMapping("/tpsresponsetime")
	public void tpsresponsetime(HttpServletResponse response,
			HttpServletRequest request, HttpSession session, Model model) {
		
//		String idfnumber = request.getParameter("idfNumber");
		String idfnumber = (String) session.getAttribute("idfNumber");	
		List<String> idflist = new ArrayList<String>();
		idflist.add(idfnumber);
		
		List<String> time = new ArrayList<String>();
		List<Double> tps = new ArrayList<Double>();
		List<Double> responsetime = new ArrayList<Double>();
		
		
		List<List> idftpsresponsetime = new ArrayList<List>();//save time, idfnumber, tps, reqponsetime
		String uuid = (String) session.getAttribute("uuid");
		SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
		Map<Long, Map<String, TPSResponseTime>> map = DataMapSelector.selectCommonMap(uuid).getStatisMap();
		for(Entry<Long,Map<String,TPSResponseTime>> entry : map.entrySet()){
			
			time.add(sdf.format(new Date(entry.getKey()))); //get time 

			
			Map<String,TPSResponseTime> idftpsresponse  = entry.getValue();
			
			TPSResponseTime tpsresponse = idftpsresponse.get(idfnumber);//get total idf if idfnumber=="0"

			if(tpsresponse!=null){
				tps.add((double) tpsresponse.getTps());//get tps
//				System.out.println("tps: "+tpsresponse.getTps());
				responsetime.add((double) (tpsresponse.getResponseTime()/1000000));//get responsetime
//				System.out.println("getResponseTime: "+tpsresponse.getResponseTime()/1000000);
			}else{
				System.out.println("null object");
				tps.add(0.0);//get tps
				responsetime.add(0.0);//get responsetime
			}
						
		}
		
		idftpsresponsetime.add(0, time);
		idftpsresponsetime.add(1, tps);
		idftpsresponsetime.add(2, responsetime);
		idftpsresponsetime.add(3, idflist);
		
//		System.out.println("idftpsresponsetime: "+JSONArray.fromObject(idftpsresponsetime).toString());
//		model.addAttribute("time", time);
//		model.addAttribute("tps", tps);
//		model.addAttribute("responsetime", responsetime);
		model.addAttribute("idftpsresponsetime", idftpsresponsetime);
		try {
			response.getWriter().print(JSONArray.fromObject(idftpsresponsetime).toString());
			//session.setAttribute("idftpsresponsetime", JSONArray.fromObject(idftpsresponsetime).toString());
			//response.getWriter().print(jsonarray);
		} catch (IOException e) {
			
			System.out.println("Exception");
			e.printStackTrace();
		}
	}
	
//	@RequestMapping("/testjson")
//	public void testjson(HttpServletResponse response,
//			HttpServletRequest request, HttpSession session, Model model) {
//		String flag = request.getParameter("var");
//		System.out.println("var:"+flag);
//		/*List<String> recived = new ArrayList<String>();
//		recived.add("xixi");
//		recived.add("haha");*/
//		JSONObject obj = new JSONObject();
//		JSONObject objchild1 = null;
//		JSONObject objchild2 = null;
//		try {
//			obj.put("name", "mkyong.com");
//			obj.put("percentageabs", 56.98);
//			obj.put("avgTime", 556.98);
// 
//			objchild1 = new JSONObject();
//			objchild1.put("name", "1.com");
//			objchild1.put("percentageabs", 36.98);
//			objchild1.put("avgTime", 456.98);
//			
//			objchild2 = new JSONObject();
//			objchild2.put("name", "2.com");
//			objchild2.put("percentageabs", 26.98);
//			objchild2.put("avgTime", 56.98);
//		} catch (JSONException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		JSONArray list = new JSONArray();
//		list.add(objchild1);
//		list.add(objchild2);
////		list.add("msg 1");
////		list.add("msg 2");
////		list.add("msg 3");
//	 
//		try {
//			obj.put("children", list);
//		} catch (JSONException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		try {
//			response.getWriter().print(obj);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
		
}

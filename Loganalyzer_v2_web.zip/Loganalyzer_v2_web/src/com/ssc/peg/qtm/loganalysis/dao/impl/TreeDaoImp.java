package com.ssc.peg.qtm.loganalysis.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssc.peg.qtm.loganalysis.dao.TreeDao;
import com.ssc.peg.qtm.loganalysis.db.bean.Tree;
import com.ssc.peg.qtm.loganalysis.exception.DaoException;
import com.ssc.peg.qtm.loganalysis.mapper.TreeMapper;
@Repository
public class TreeDaoImp<T extends Tree> implements TreeDao<T> {

	@Inject
	private TreeMapper<T> mapper;
	
	@Override
	public boolean addTree(T entity) {
		boolean flag = false;
		try
		{
			mapper.addTree(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Tree to database",e);
		}
		return flag;
		
	}

	@Override
	public T getTreeByTreeId(int id) {
		return mapper.getTreeByTreeId(id);
	}

	@Override
	public List<T> getTreeByAnalysisId(int analysisId) {
		return mapper.getTreeByAnalysisId(analysisId);
	}

	@Override
	public T getTreeByTreeUUID(String treeUUID) {
		return mapper.getTreeByTreeUUID(treeUUID);
	}

	@Override
	public T getTreeByRequestId(String requestId) {
		return mapper.getTreeByRequestId(requestId);
	}

	@Override
	public boolean addTreeList(List<T> list) {
		boolean flag = false;
		try
		{
			mapper.addTreeList(list);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			throw new DaoException("Exception while add Tree list to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getMergeTreeForService(int analysisId, int serviceId,
			boolean isMerged, boolean isAllStructure) {
		// TODO Auto-generated method stub
		return mapper.getMergeTreeForService(analysisId, serviceId, isMerged, isAllStructure);
	}

	@Override
	public int getCountOfMergeTreeForService(int analysisId, int serviceId,
			boolean isMerged, boolean isAllStructure) {
		// TODO Auto-generated method stub
		return mapper.getCountOfMergeTreeForService(analysisId, serviceId, isMerged, isAllStructure);
	}

	@Override
	public List<T> getMergeTreeForServiceMerge(int analysisId, int serviceId,
			boolean isMerged, boolean isAllStructure) {
		// TODO Auto-generated method stub
		return mapper.getMergeTreeForServiceMerge(analysisId, serviceId, isMerged, isAllStructure);
	}

}

package com.ssc.peg.qtm.loganalysis.concurrent.db2;

import static com.ssc.peg.qtm.loganalysis.constants.LogPattern.idfPattern;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ssc.peg.qtm.loganalysis.bean.FunctionStatistics;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNode;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeMapping;
import com.ssc.peg.qtm.loganalysis.bean.ServiceNodeValue;
import com.ssc.peg.qtm.loganalysis.bean.ServiceRequestTree;
import com.ssc.peg.qtm.loganalysis.bean.TimePicker;
import com.ssc.peg.qtm.loganalysis.exception.LogFormatException;

public class TreeTransfer {
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	private TimePicker timePicker;
	public TreeTransfer(TimePicker timePicker)
	{
		this.timePicker = timePicker;
	}
	
	public ServiceRequestTree rsToMemory(String queueString) throws SQLException, LogFormatException, ParseException{
		String [] processArray = Pattern.compile("\n").split(queueString);
		ServiceRequestTree  tree = null;
				tree = rsToTree(processArray);
		return tree;
	}
	public ServiceRequestTree rsToTree(String [] processArray) throws LogFormatException, ParseException, SQLException
	{
		ServiceNodeMapping mapping = null;
		StringBuilder functionSb = new StringBuilder();
		ServiceRequestTree tree = new ServiceRequestTree();
		//generate the root node and set parent node null
			setRootNode(processArray[0],functionSb,tree);
			mapping = tree.getNodeMapping();
		
		if(tree.getRootNode() == null)
			return null;
		boolean over = generateBranchNode(processArray, mapping, tree, functionSb);
		
		tree.setFunctionHashcode(functionSb.toString().hashCode());
//		if(!over)
//			tree = null;
		functionSb.setLength(0);
		functionSb=null;
//		processArray = null;
		return tree;
	}
	
	
	/**
	 * 
	 * @param rs
	 * @param mapping
	 * @param tree
	 * @param functionSb
	 * @return tree over, meet another tree
	 * @throws SQLException
	 * @throws ParseException 
	 */
	private boolean generateBranchNode(String [] processArray,ServiceNodeMapping mapping,ServiceRequestTree tree,StringBuilder functionSb) throws SQLException, ParseException
	{
		ServiceNode rootNode = tree.getRootNode();
		ServiceNodeValue rootNodeValue = mapping.getNodeMappingMap().get(rootNode);
		//generate child node ,set parent node and child node to parent 
		for (int i = 1; i < processArray.length; i++) {
			String [] rootArr = processArray[i].split(",");
			String uuid = rootArr[0];
			String entityName = rootArr[1].intern();
			String functionName = rootArr[2].intern();
			String funcationDesc = rootArr[3].intern();
			String criteria = rootArr[4].intern();
			String callerId = rootArr[5].intern();
			Date startTime = sdf.parse(rootArr[6]);
			Date endTime = sdf.parse(rootArr[7]);
			String level = rootArr[8];
			long execuTime = Long.parseLong(rootArr[9]);

				//get the process level and transform to array 
				String levelWithDot = level +".";
				String [] levelArr = levelWithDot.split("\\.");
				ServiceNode node = new ServiceNode();
				ServiceNodeValue nodeVaule = new ServiceNodeValue();
				
				//get parent level 
				int [] parentLevel = getParentLevel(levelArr);
				
				nodeVaule.setLevel(level);
				nodeVaule.setFunctionName(functionName);
//				String decs = branchMatcher.group(3).intern();
//				if(decs.contains("output row count"))
//					decs = decs.split(",")[0];
				nodeVaule.setFuncationDescription(funcationDesc);
				nodeVaule.setExecutionTime(execuTime);
				nodeVaule.setSelfExecutionTime(execuTime);
				nodeVaule.setPercentageAbsolute((float)execuTime/rootNodeValue.getExecutionTime());
				
				functionSb.append(nodeVaule.getLevel()+nodeVaule.getFunctionName() + " - " + nodeVaule.getFuncationDescription() + "\n");
				
				ServiceNode parentNode = getParentNode2(parentLevel,rootNode,mapping);
//				if(parentNode == null)
//					return false;
				if(parentNode.getChildrenNode() == null)
				{
					List<ServiceNode> keyChildNode = new ArrayList<ServiceNode>();
					keyChildNode.add(node);
					parentNode.setChildrenNode(keyChildNode);
				}
				else
					parentNode.getChildrenNode().add(node);
				
				ServiceNodeValue parentNodeValue = mapping.getNodeMappingMap().get(parentNode);
				parentNodeValue.setSelfExecutionTime(parentNodeValue.getSelfExecutionTime() - nodeVaule.getExecutionTime());
				
				nodeVaule.setPercentageRelative((float)execuTime/parentNodeValue.getExecutionTime());
				mapping.getNodeMappingMap().put(node, nodeVaule);
			String function = nodeVaule.getFunctionName() + " - " + nodeVaule.getFuncationDescription();
			FunctionStatistics fs = tree.getFunctionStatistics().get(function);
			if(fs == null)
			{
				fs = new FunctionStatistics();
				fs.setAvgTime(nodeVaule.getExecutionTime());
				fs.setMaxTime(nodeVaule.getExecutionTime());
				fs.setMinTime(nodeVaule.getExecutionTime());
				fs.setRatio((float)nodeVaule.getExecutionTime() / rootNodeValue.getExecutionTime());
				fs.setCount(1);
				tree.getFunctionStatistics().put(function.intern(), fs);
			}
			else
			{
				if(nodeVaule.getExecutionTime() > fs.getMaxTime())
					fs.setMaxTime(nodeVaule.getExecutionTime());
				if(nodeVaule.getExecutionTime() < fs.getMinTime())
					fs.setMinTime(nodeVaule.getExecutionTime());
				fs.setAvgTime((fs.getAvgTime() * fs.getCount() + nodeVaule.getExecutionTime())/ (fs.getCount() + 1));
				fs.setCount(fs.getCount() + 1);
				fs.setRatio((float)fs.getAvgTime() * fs.getCount() / rootNodeValue.getExecutionTime());
			}
		
		}
		return true;
		}
//		for (int i = 1; i < processArray.length; i++) {
//			Matcher branchMatcher = branchPattern.matcher(processArray[i]);
					
			//if matches the branchPatten
							
//		}	
//	}
	private ServiceNode getParentNode(int[] parentLevel,ServiceNode rootNode) {
		if(parentLevel[0] == 0)
			return rootNode;
		else 
		{
			ServiceNode parentNode = rootNode;
			for (int i = 0; i < parentLevel.length; i++) {
				try{
					List<ServiceNode>  list = parentNode.getChildrenNode();
				parentNode = parentNode.getChildrenNode().get(parentLevel[i] - 1);
				}catch(IndexOutOfBoundsException e)
				{
					System.out.println("Exception occur........");
				}
			}
			return parentNode;
		}
		// TODO Auto-generated method stub
	}

	private ServiceNode getParentNode2(int[] parentLevel,ServiceNode rootNode,ServiceNodeMapping mapping) {
		
		if(parentLevel[0] == 0)
			return rootNode;
		
		else 
		{
			try{
				String level = "";
				for (int i = 0; i < parentLevel.length; i++){
					level = level+parentLevel[i]+".";
				}
				level = level.substring(0,level.length()-1);
				
				for (ServiceNode node : mapping.getNodeMappingMap().keySet()) {
					if(level.equals(mapping.getNodeMappingMap().get(node).getLevel()))
					{
						return node;
					}
				}
				
			}
			catch(IndexOutOfBoundsException e)
			{
				System.out.println("Exception occur........");
			}
			return null;
		}
		// TODO Auto-generated method stub
	}
	private boolean isIDFTree(String treeStr) {
		Matcher idMatcher = idfPattern.matcher(treeStr);
		boolean isTree = true;
		if(!idMatcher.find())
		{
			isTree = false;
		}
		return isTree;
	}

	private int[] getParentLevel(String [] levelArr)
	{
		
		if(levelArr.length != 1)
		{
			int [] parentLevel = new int[levelArr.length-1];
			for (int j = 0; j < levelArr.length -1 ; j++) {
				parentLevel[j] = Integer.parseInt(levelArr[j]);
			}
			return parentLevel;
		}
		else
		{
			int [] parentLevel = {0};
			return parentLevel;
		}
	}
	
	/**
	 * check the tree is executed during the timePicker time
	 * @param rootMatcher
	 * @return
	 * @throws ParseException
	 */
	private boolean checkTime(Matcher rootMatcher) throws ParseException
	{
		boolean flag = false;
		long startTime = sdf.parse(rootMatcher.group(1)).getTime() - Long.parseLong(rootMatcher.group(10)) / 1000000;
		// date from maybe 0 or timestamp 
		if(startTime> timePicker.getDateFrom())
		{
			if(startTime < timePicker.getDateTo() || timePicker.getDateTo() == 0)
				flag = true;
		}
		return flag;
	}
	
	/**
	 * matcher informations of the root node
	 * @param rootMatcher
	 * @param functionSb
	 * @param tree
	 * @return
	 * @throws ParseException
	 * @throws SQLException 
	 */
	private ServiceNode setRootNode(String rootString,StringBuilder functionSb,ServiceRequestTree tree) throws ParseException, SQLException
	{
		ServiceNode rootNode = new ServiceNode();
		rootNode.setParentNode(null);
		ServiceNodeValue rootNodeValue = new ServiceNodeValue();
		String [] rootArr = rootString.split(",");
		String uuid = rootArr[0];
		String entityName = rootArr[1].intern();
		String functionName = rootArr[2].intern();
		String funcationDesc = rootArr[3].intern();
		String criteria = rootArr[4].intern();
		String callerId = rootArr[5].intern();
		Date startTime = sdf.parse(rootArr[6]);
		Date endTime = sdf.parse(rootArr[7]);
		String level = rootArr[8].intern();
		long execuTime = Long.parseLong(rootArr[9]);
		
		rootNodeValue.setFunctionName(functionName);
		rootNodeValue.setFuncationDescription(funcationDesc);
		rootNodeValue.setExecutionTime(execuTime);
		rootNodeValue.setSelfExecutionTime(execuTime);
		rootNodeValue.setPercentageAbsolute(1);
		rootNodeValue.setPercentageRelative(1);
		rootNodeValue.setLevel("0");
		
		functionSb.append(rootNodeValue.getFunctionName() + " - " + rootNodeValue.getFuncationDescription() + "\n");
		ServiceNodeMapping mapping = new ServiceNodeMapping();
		Map<ServiceNode,ServiceNodeValue> mappingMap = new HashMap<ServiceNode, ServiceNodeValue>();
		mappingMap.put(rootNode, rootNodeValue);
		mapping.setNodeMappingMap(mappingMap);
		
//		tree.setTreeId(Integer.parseInt(rootMatcher.group(2)));
//		tree.setClientRequestId(rootMatcher.group(3).intern());
		tree.setCallerId(callerId);
//		tree.setCertificateID(rootMatcher.group(5).intern());
		tree.setRequestId(uuid);
		tree.setEntityName(entityName);
		tree.setIdfNumber((entityName + " " + criteria).intern());
//		tree.setThreadName(rootMatcher.group(7).intern());
		tree.setStartTime(startTime.getTime());
		tree.setEndTime(endTime.getTime());
		tree.setRootNode(rootNode);
		tree.setNodeMapping(mapping);
		tree.setCriteria(criteria);
		
		Map<String,FunctionStatistics> functionStatisticMap = new HashMap<String, FunctionStatistics>();
		FunctionStatistics fs = new FunctionStatistics();
		fs.setAvgTime(rootNodeValue.getExecutionTime());
		fs.setMaxTime(rootNodeValue.getExecutionTime());
		fs.setMinTime(rootNodeValue.getExecutionTime());
		fs.setRatio(1);
		fs.setCount(1);
		functionStatisticMap.put((rootNodeValue.getFunctionName() + " - " + rootNodeValue.getFuncationDescription()).intern(), fs);
		tree.setFunctionStatistics(functionStatisticMap);
		
		return rootNode;
	}
	
	
	private static int parseLevel(String s){
		int result = 0;
		int i = 0, max = s.length();
		int radix=10;
		int digit;
		if (max>0){
			digit = Character.digit(s.charAt(i++),radix);
			result = -digit;
		}
		
		while (i < max) {
			digit = Character.digit(s.charAt(i++),radix);
			result *= radix;
			result -= digit;
		}
		return -result;
	}
	
}

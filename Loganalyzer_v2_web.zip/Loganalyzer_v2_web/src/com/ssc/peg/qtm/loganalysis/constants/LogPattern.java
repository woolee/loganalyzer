package com.ssc.peg.qtm.loganalysis.constants;

import java.util.regex.Pattern;

public class LogPattern {
	/**
	 * parser root node, matcher parameters:
	 * Index    parameter name
	 * 1.		End time
	 * 2.		Thread number,
	 * 3.		client request id,
	 * 4.		CallerID,
	 * 5.		CertificateID,
	 * 6.		Request ID,
	 * 7.		Thread Name,
	 * 8.		Function Name,
	 * 9.		Function description,
	 * 10.		Time takes
	 */
	public static final Pattern rootPattern = Pattern.compile("DEBUG\\>([0-9]{4}\\-[0-9]{2}\\-[0-9]{2}\\s+[0-9]{2}:[0-9]{2}:[0-9]{2}\\,[0-9]{3})\\s+PerformanceLogger" +
			"\\[\\w+-([0-9]+)\\]" +
			"-\\[ClientRequestID:([\\s\\S]*)\\]" +
			"-\\[CallerID:([0-9a-zA-Z]+)\\]" +
			"-\\[CertificateID:([\\w\\W]+)\\]" +
			"-\\[Request ID:([0-9a-zA-Z-]+)\\]" +
			":\\s+\\[Thread Name:([0-9a-zA-Z-]+)\\]" +
			"\\s+\\[Record Sequence ID:\\s+[0-9]+\\]" +
			"\\s+\\[Work Name:Call\\s+([\\S]*)" +
			"\\s+-\\s([\\s\\w\\W]+)\\]\\s+" +
			"Takes\\(nano Sec\\):(\\d+)");
	
	
	/**
	 * parser branch node, matcher parameter:
	 * Index    parameter name
	 * 1.		Branch level,
	 * 2.		Function name,
	 * 3.		Function description,
	 * 4.		Time takes
	 */
	public static final Pattern branchPattern = Pattern.compile("\\[Work Name:\\s*([\\d\\.]+)\\s*Call\\s+([\\S]*)\\s+-\\s([\\s\\w\\W]+)\\]\\s+Takes\\(nano Sec\\):(\\d+)");
	
	/**
	 * matcher parameters:
	 * Index    parameter name
	 * 1.  		Branch level;
	 * 2. 	    Function name,
	 * 3.  		Function description,
	 * 4.		IDF number;
	 * 5.		entity name;
	 * 6.		CRITERIA;
	 * 7.		Time takes.
	 * 
	 */
	public static final Pattern idPattern = Pattern.compile("\\[Work Name:\\s*([\\d\\.]+)\\s*Call\\s+([\\S]*)\\s+-\\s([\\s\\w\\W]+)\\s*--IDF\\sNUMBER\\((\\d+)\\)\\sENTITY_NAME\\((\\w+)\\)\\sCRITERIA:\\[([\\w\\W]+)\\]\\]\\s+Takes\\(nano Sec\\):(\\d+)");
	
	public static final Pattern idfPattern = Pattern.compile("IDF\\sNUMBER\\((\\d+)\\)");
	//public static final Pattern idfPattern = Pattern.compile("IDF\\sNUMBER\\((\\d+)\\)\\sENTITY_NAME\\((\\w+)\\)\\sCRITERIA:\\[([\\w\\W]+)\\]");
}

package com.ssc.peg.qtm.loganalysis.dao;

import java.util.List;

public interface MergeNodeValueDao<T> {
	public boolean addNodeStatistics(T entity);
	public T getNodeStatisticsByStatisticsId(int statisticsId);
	public T getNodeStatisticsByNodeUUID(String nodeUUID);
	public boolean addNodeValueList(List<T> list);
}

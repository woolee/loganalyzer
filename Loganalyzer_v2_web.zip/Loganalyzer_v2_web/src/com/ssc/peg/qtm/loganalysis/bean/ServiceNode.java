package com.ssc.peg.qtm.loganalysis.bean;

import java.util.List;

public class ServiceNode {
	private ServiceNode parentNode;
	private List<ServiceNode> childrenNode;
	public ServiceNode getParentNode() {
		return parentNode;
	}
	public void setParentNode(ServiceNode parentNode) {
		this.parentNode = parentNode;
	}
	public List<ServiceNode> getChildrenNode() {
		return childrenNode;
	}
	public void setChildrenNode(List<ServiceNode> childrenNode) {
		this.childrenNode = childrenNode;
	}
	
	@Override
	public String toString() {
		return "Node [parentNode=" + parentNode + ", childrenNode=" + childrenNode + "]";
	}
}

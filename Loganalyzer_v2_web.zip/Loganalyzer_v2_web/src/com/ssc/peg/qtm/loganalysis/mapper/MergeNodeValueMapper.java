package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

public interface MergeNodeValueMapper<T> extends SqlMapper{
	public void addNodeStatistics(T entity);
	public T getNodeStatisticsByStatisticsId(int statisticsId);
	public T getNodeStatisticsByNodeUUID(String nodeUUID);
	public void addNodeValueList(List<T> list);
}

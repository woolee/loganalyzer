package com.ssc.peg.qtm.loganalysis.db.bean;

import java.io.Serializable;

public class FuncRatioTopN implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1452183505095284068L;
	private int id;
	private int functionId;
	private int serviceId;
//	private int treeId;
	private String treeUUID;
	private int analysisId;
	private float ratio;
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFunctionId() {
		return functionId;
	}
	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
//	public int getTreeId() {
//		return treeId;
//	}
//	public void setTreeId(int treeId) {
//		this.treeId = treeId;
//	}
	public String getTreeUUID() {
		return treeUUID;
	}
	public void setTreeUUID(String treeUUID) {
		this.treeUUID = treeUUID;
	}
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	
}

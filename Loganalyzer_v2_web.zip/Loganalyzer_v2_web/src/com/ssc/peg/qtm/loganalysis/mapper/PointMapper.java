package com.ssc.peg.qtm.loganalysis.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface PointMapper<T> extends SqlMapper{
	public void addTPSRespTime(T entity);
	public T getTPSRespTimePoint(int pointId);
	public List<T> getTPSRespTimeByAnalysisId(int analysisId);
	public void addPointList(List<T> list);
	public List<T> getTPSRespTimeByAnalysisServiceId(@Param("analysisId")int analysisId,@Param("serviceId")int serviceId);
	
}

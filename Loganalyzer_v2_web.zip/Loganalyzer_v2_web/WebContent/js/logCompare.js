$(function(){
		/* $('table').trigger('refreshColumnSelector'); */
		
		 /*** custom css only button popup ***/
		  $("#functionTableImprove").tablesorter({
		    theme: 'blue',
		    headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
		      widthFixed: true,
		    widgets: ['zebra','filter', 'columnSelector', 'stickyHeaders'],
		    widgetOptions : {
		    	
		      // target the column selector markup
		      columnSelector_container : $('#columnSelector1'),
		      // column status, true = display, false = hide
		      // disable = do not display on list
		      columnSelector_columns : {
		        0: 'disable'// set to disabled; not allowed to unselect it 
		      },
		      // remember selected columns (requires $.tablesorter.storage)
		      columnSelector_saveColumns: false,

		      // container layout
		      columnSelector_layout : '<label><input type="checkbox">{name}</label>',
		      // data attribute containing column name to use in the selector container
		      columnSelector_name  : 'data-selector-name',

		      //Responsive Media Query settings 
		      // enable/disable mediaquery breakpoints
		      columnSelector_mediaquery: true,
		      // toggle checkbox name
		      columnSelector_mediaqueryName: 'All: ',
		      // breakpoints checkbox initial setting
		      columnSelector_mediaqueryState: true,
		      // responsive table hides columns with priority 1-6 at these breakpoints
		      // see http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/#Applyingapresetbreakpoint
		      // *** set to false to disable ***
		      columnSelector_breakpoints : [ '20em', '30em', '40em', '50em', '60em', '70em' ],
		      // data attribute containing column priority
		      // duplicates how jQuery mobile uses priorities:
		      // http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/
		      columnSelector_priority : 'data-priority',

		      // class name added to checked checkboxes - this fixes an issue with Chrome not updating FontAwesome
		      // applied icons; use this class name (input.checked) instead of input:checked
		      columnSelector_cssChecked : 'checked'
		    }
		  });


		
		  $("#idftableImprove").tablesorter({
			  theme: 'blue',
		      headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
		      widthFixed: true,
			    widgets: ['zebra', 'filter','columnSelector', 'stickyHeaders'],
			    widgetOptions : {
			      // target the column selector markup
			      columnSelector_container : $('#columnSelector2'),
			      // column status, true = display, false = hide
			      // disable = do not display on list
			      columnSelector_columns : {
			        0: 'disable'
			        // set to disabled; not allowed to unselect it 
			      },
			      // remember selected columns (requires $.tablesorter.storage)
			      columnSelector_saveColumns: false,

			      // container layout
			      columnSelector_layout : '<label><input type="checkbox">{name}</label>',
			      // data attribute containing column name to use in the selector container
			      columnSelector_name  : 'data-selector-name',

			      //Responsive Media Query settings 
			      // enable/disable mediaquery breakpoints
			      columnSelector_mediaquery: true,
			      // toggle checkbox name
			      columnSelector_mediaqueryName: 'All: ',
			      // breakpoints checkbox initial setting
			      columnSelector_mediaqueryState: true,
			      // responsive table hides columns with priority 1-6 at these breakpoints
			      // see http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/#Applyingapresetbreakpoint
			      // *** set to false to disable ***
			      columnSelector_breakpoints : [ '20em', '30em', '40em', '50em', '60em', '70em' ],
			      // data attribute containing column priority
			      // duplicates how jQuery mobile uses priorities:
			      // http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/
			      columnSelector_priority : 'data-priority',

			      // class name added to checked checkboxes - this fixes an issue with Chrome not updating FontAwesome
			      // applied icons; use this class name (input.checked) instead of input:checked
			      columnSelector_cssChecked : 'checked'
			    }
			  });
		  

		  $("#functionTableWeaken").tablesorter({
			    theme: 'blue',
			    headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
			      widthFixed: true,
			    widgets: ['zebra','filter', 'columnSelector', 'stickyHeaders'],
			    widgetOptions : {
			      // target the column selector markup
			      columnSelector_container : $('#columnSelector3'),
			      // column status, true = display, false = hide
			      // disable = do not display on list
			      columnSelector_columns : {
			        0: 'disable'// set to disabled; not allowed to unselect it 
			      },
			      // remember selected columns (requires $.tablesorter.storage)
			      columnSelector_saveColumns: false,

			      // container layout
			      columnSelector_layout : '<label><input type="checkbox">{name}</label>',
			      // data attribute containing column name to use in the selector container
			      columnSelector_name  : 'data-selector-name',

			      //Responsive Media Query settings 
			      // enable/disable mediaquery breakpoints
			      columnSelector_mediaquery: true,
			      // toggle checkbox name
			      columnSelector_mediaqueryName: 'All: ',
			      // breakpoints checkbox initial setting
			      columnSelector_mediaqueryState: true,
			      // responsive table hides columns with priority 1-6 at these breakpoints
			      // see http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/#Applyingapresetbreakpoint
			      // *** set to false to disable ***
			      columnSelector_breakpoints : [ '20em', '30em', '40em', '50em', '60em', '70em' ],
			      // data attribute containing column priority
			      // duplicates how jQuery mobile uses priorities:
			      // http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/
			      columnSelector_priority : 'data-priority',

			      // class name added to checked checkboxes - this fixes an issue with Chrome not updating FontAwesome
			      // applied icons; use this class name (input.checked) instead of input:checked
			      columnSelector_cssChecked : 'checked'
			    }
			  });
		  

		  $("#idftable").tablesorter({
			  theme: 'blue',
		      headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
		      widthFixed: true,
			    widgets: ['zebra', 'filter','columnSelector', 'stickyHeaders'],
			    widgetOptions : {
			      // target the column selector markup
			      columnSelector_container : $('#columnSelector4'),
			      // column status, true = display, false = hide
			      // disable = do not display on list
			      columnSelector_columns : {
			        0: 'disable'
			        // set to disabled; not allowed to unselect it 
			      },
			      // remember selected columns (requires $.tablesorter.storage)
			      columnSelector_saveColumns: false,

			      // container layout
			      columnSelector_layout : '<label><input type="checkbox">{name}</label>',
			      // data attribute containing column name to use in the selector container
			      columnSelector_name  : 'data-selector-name',

			      //Responsive Media Query settings 
			      // enable/disable mediaquery breakpoints
			      columnSelector_mediaquery: true,
			      // toggle checkbox name
			      columnSelector_mediaqueryName: 'All: ',
			      // breakpoints checkbox initial setting
			      columnSelector_mediaqueryState: true,
			      // responsive table hides columns with priority 1-6 at these breakpoints
			      // see http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/#Applyingapresetbreakpoint
			      // *** set to false to disable ***
			      columnSelector_breakpoints : [ '20em', '30em', '40em', '50em', '60em', '70em' ],
			      // data attribute containing column priority
			      // duplicates how jQuery mobile uses priorities:
			      // http://view.jquerymobile.com/1.3.2/dist/demos/widgets/table-column-toggle/
			      columnSelector_priority : 'data-priority',

			      // class name added to checked checkboxes - this fixes an issue with Chrome not updating FontAwesome
			      // applied icons; use this class name (input.checked) instead of input:checked
			      columnSelector_cssChecked : 'checked'
			    }
			  });
		  /*** Bootstrap popover demo ***/
		  /*$('#popover')
		    .popover({
		      placement: 'right',
		      html: true, // required if content has HTML
		      content: '<div id="popover-target"></div>'
		    })
		    // bootstrap popover event triggered when the popover opens
		    .on('shown.bs.popover', function () {
		      // call this function to copy the column selection code into the popover
		      $.tablesorter.columnSelector.attachTo( $('.bootstrap-popup'), '#popover-target');
		    });

		  // initialize column selector using default settings
		  // note: no container is defined!
		  $(".bootstrap-popup").tablesorter({
		    theme: 'blue',
		    widgets: ['zebra', 'columnSelector', 'stickyHeaders']
		  });*/

		  // define pager options
		  var pagerOptions1 = {
		    // target the pager markup - see the HTML block below
		    container: $("#pager1"),
		    // output string - default is '{page}/{totalPages}'; possible variables: {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
		    output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
		    // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
		    // table row set to a height to compensate; default is false
		    fixedHeight: true,
		    // remove rows from the table to speed up the sort of large tables.
		    // setting this to false, only hides the non-visible rows; needed if you plan to add/remove rows with the pager enabled.
		    removeRows: false,
		    // go to page selector - select dropdown that sets the current page
		    cssGoto: '.gotoPage'
		  };

		  var pagerOptions2 = {
				    // target the pager markup - see the HTML block below
				    container: $("#pager2"),
				    // output string - default is '{page}/{totalPages}'; possible variables: {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
				    output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
				    // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
				    // table row set to a height to compensate; default is false
				    fixedHeight: true,
				    // remove rows from the table to speed up the sort of large tables.
				    // setting this to false, only hides the non-visible rows; needed if you plan to add/remove rows with the pager enabled.
				    removeRows: false,
				    // go to page selector - select dropdown that sets the current page
				    cssGoto: '.gotoPage'
				  };
		  
		  var pagerOptions3 = {
				    // target the pager markup - see the HTML block below
				    container: $("#pager3"),
				    // output string - default is '{page}/{totalPages}'; possible variables: {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
				    output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
				    // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
				    // table row set to a height to compensate; default is false
				    fixedHeight: true,
				    // remove rows from the table to speed up the sort of large tables.
				    // setting this to false, only hides the non-visible rows; needed if you plan to add/remove rows with the pager enabled.
				    removeRows: false,
				    // go to page selector - select dropdown that sets the current page
				    cssGoto: '.gotoPage'
				  };
		  
		  var pagerOptions4 = {
				    // target the pager markup - see the HTML block below
				    container: $("#pager4"),
				    // output string - default is '{page}/{totalPages}'; possible variables: {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
				    output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
				    // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
				    // table row set to a height to compensate; default is false
				    fixedHeight: true,
				    // remove rows from the table to speed up the sort of large tables.
				    // setting this to false, only hides the non-visible rows; needed if you plan to add/remove rows with the pager enabled.
				    removeRows: false,
				    // go to page selector - select dropdown that sets the current page
				    cssGoto: '.gotoPage'
				  };
		  // Initialize tablesorter
		  // ***********************

 
		  $("#functionTableImprove")
		    .tablesorter({
		      theme: 'blue',
		      headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
		      widthFixed: true,
		      widgets: ['zebra', 'filter']
		    })

		    // initialize the pager plugin
		    // ****************************
		    .tablesorterPager(pagerOptions3);
		  

		$("#idftableImprove")
		.tablesorter({
		  theme: 'blue',
		  headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
		  widthFixed: true,
		  widgets: ['zebra', 'filter']
		})
		
		// initialize the pager plugin
		// ****************************
		.tablesorterPager(pagerOptions4);
		
		
		$("#functionTableWeaken")
		.tablesorter({
			theme: 'blue',
			headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
			widthFixed: true,
			widgets: ['zebra', 'filter']
		})
		
		// initialize the pager plugin
		// ****************************
		.tablesorterPager(pagerOptions1);
		
		$("#idftable")
		.tablesorter({
			theme: 'blue',
			headerTemplate : '{content} {icon}', // new in v2.7. Needed to add the bootstrap icon!
			widthFixed: true,
			widgets: ['zebra', 'filter']
		})
		// initialize the pager plugin
		// ****************************
		.tablesorterPager(pagerOptions2);
		});


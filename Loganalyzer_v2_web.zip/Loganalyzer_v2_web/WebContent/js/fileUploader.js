var xhr=createXHR();
function Checkfiles(){
	loading();
	var fup = document.getElementById('sampleFile');
    performAjaxSubmit();
    fup.focus();
    return false; 
}
function performAjaxSubmit() {
	//alert(4.2);
	//console.log(document.getElementById("sampleFile"));
   var sampleFile = document.getElementById("sampleFile").files[0];
//	var sampleFile = document.getElementById("sampleFile");
//    console.log(sampleFile);
    //alert(4.1);
   console.log("sampleFile: "+sampleFile);
    var formdata = new FormData();
    formdata.append("uploadFile", sampleFile);  
    xhr.open("POST","../file/fileUpload.do", true);
    xhr.onreadystatechange = processResponse;
    xhr.send(formdata);
 }
function processResponse() {
	if (xhr.readyState == 4) { 
    	if (xhr.status == 200) { 
    		displayUpload();
        } else {
        	document.getElementById("uploadBtn1").innerHTML="<span style=\"color: red;\">Upload File Failed</span>";
           hiding();
        }
    }
}
function displayUpload() {
	
	var name=xhr.responseText;
	if(name == null || name == "")
		{
		$("#tabledate").html(name);
		document.getElementById("uploadBtn1").innerHTML="<span style=\"color: red;\">Invaild Script File</span>";
		
		}
	else{
		$("#tabledate").html(name);
		document.getElementById("uploadBtn1").innerHTML="<span style=\"color: green;\">Upload File Success</span>";
		
	}
	hiding();
}
    
 function createXHR(){
    if(typeof XMLHttpRequest != "undefined"){
		return new XMLHttpRequest();
	}else if(typeof ActiveObject != "undefined"){
		if(typeof arguments.callee.activeXString != "string"){
			var versions = ["MSXML2.XMLHttp.6.0","MSXML2.XMLHttp.3.0","MSXML2.XMLHttp"];
			for(var i=0,len=versions.length;i<len;i++){
				try{
					var xhr = new ActiveXObject(version[i]);
					arguments.callee.activeXString = versions[i];
					return xhr;
				}catch(ex){
					
				}
			}
		}
		return new ActiveXObject(arguments.callee.activeXString);
	}else{
		throw new Error("NO XHR object available.");
	}
}